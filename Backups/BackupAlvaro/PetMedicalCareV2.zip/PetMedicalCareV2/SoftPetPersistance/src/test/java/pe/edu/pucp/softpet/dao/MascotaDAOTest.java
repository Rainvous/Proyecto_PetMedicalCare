package pe.edu.pucp.softpet.dao;

import java.util.ArrayList;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import pe.edu.pucp.softpet.daoImpl.MascotaDAOImpl;
import pe.edu.pucp.softpet.daoImpl.PersonaDAOImpl;
import pe.edu.pucp.softpet.model.actoresdto.MascotasDTO;
import pe.edu.pucp.softpet.model.actoresdto.PersonasDTO;
import pe.edu.pucp.softpet.model.TipoSexo;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MascotaDAOTest {

    private final MascotaDAO mascotaDAO = new MascotaDAOImpl();
    private final PersonaDAO personaDAO = new PersonaDAOImpl();
    private PersonasDTO duenioBase;

    @BeforeAll
    public void setUpFK() {
        // Crear persona base solo una vez
        PersonasDTO p = new PersonasDTO();
        p.setNombre("Dueño Base");
        p.setDireccion("Base 123");
        p.setCorreo("base@example.com");
        p.setTelefono("900000000");
        p.setSexo(TipoSexo.MASCULINO);
        p.setTipoPersona("CLIENTE");
        p.setTipoDocumento("DNI");
        p.setNroDocumento("99999999");
        Integer id = personaDAO.insertar(p);
        assertNotNull(id);
        p.setPersonaId(id);
        duenioBase = p;
    }

    @AfterAll
    public void tearDownFK() {
        // Intenta eliminar al dueño base al final
        // (si hay registros huérfanos con FK puede fallar; adapta si fuese necesario)
        Integer r = personaDAO.eliminar(duenioBase);
        assertNotEquals(0, r);
    }

    @Test
    public void testInsertar() {
        System.out.println("MascotaDAO.insertar");
        ArrayList<Integer> ids = new ArrayList<>();
        insertarMascotas(ids);
        eliminarTodo();
    }

    private void insertarMascotas(ArrayList<Integer> ids) {
        PersonasDTO duenio = personaDAO.obtenerPorId(duenioBase.getPersonaId()); // usar obtenerPorId para FK
        MascotasDTO m = new MascotasDTO();
        m.setPersona(duenio);
        m.setNombre("Fido");
        m.setRaza("Labrador");
        m.setColor("Negro");
        Integer id = mascotaDAO.insertar(m);
        assertTrue(id != 0);
        ids.add(id);

        duenio = personaDAO.obtenerPorId(duenioBase.getPersonaId());
        m = new MascotasDTO();
        m.setPersona(duenio);
        m.setNombre("Michi");
        m.setRaza("Siames");
        m.setColor("Blanco");
        id = mascotaDAO.insertar(m);
        assertTrue(id != 0);
        ids.add(id);
    }

    @Test
    public void testObtenerPorId() {
        System.out.println("MascotaDAO.obtenerPorId");
        ArrayList<Integer> ids = new ArrayList<>();
        insertarMascotas(ids);
        MascotasDTO a = mascotaDAO.obtenerPorId(ids.get(0));
        assertEquals(ids.get(0), a.getMascotaId());
        MascotasDTO b = mascotaDAO.obtenerPorId(ids.get(1));
        assertEquals(ids.get(1), b.getMascotaId());
        eliminarTodo();
    }

    @Test
    public void testListarTodos() {
        System.out.println("MascotaDAO.listarTodos");
        ArrayList<Integer> ids = new ArrayList<>();
        insertarMascotas(ids);
        ArrayList<MascotasDTO> lista = mascotaDAO.listarTodos();
        assertTrue(lista.size() >= ids.size());
        eliminarTodo();
    }

    @Test
    public void testModificar() {
        System.out.println("MascotaDAO.modificar");
        ArrayList<Integer> ids = new ArrayList<>();
        insertarMascotas(ids);
        for (Integer id : ids) {
            MascotasDTO m = mascotaDAO.obtenerPorId(id);
            m.setNombre("Editado_" + id);
            Integer r = mascotaDAO.modificar(m);
            assertNotEquals(0, r);
        }
        for (Integer id : ids) {
            MascotasDTO m = mascotaDAO.obtenerPorId(id);
            assertTrue(m.getNombre().startsWith("Editado_"));
        }
        eliminarTodo();
    }

    @Test
    public void testEliminar() {
        System.out.println("MascotaDAO.eliminar");
        ArrayList<Integer> ids = new ArrayList<>();
        insertarMascotas(ids);
        eliminarTodo();
    }

    private void eliminarTodo() {
        ArrayList<MascotasDTO> lista = mascotaDAO.listarTodos();
        for (MascotasDTO m : lista) {
            Integer r = mascotaDAO.eliminar(m);
            assertNotEquals(0, r);
            MascotasDTO again = mascotaDAO.obtenerPorId(m.getMascotaId());
            assertNull(again);
        }
    }
}
