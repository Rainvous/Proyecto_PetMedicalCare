﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
using SoftPetBussiness.CitaAtencionClient;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.RecetaMedicaClient;
using SoftPetBussiness.PersonaClient;
using SoftPetBussiness.VeterinarioClient;
using mascotaDto = SoftPetBussiness.MascotaClient.mascotaDto;
using citaAtencionDto = SoftPetBussiness.CitaAtencionClient.citaAtencionDto;

namespace SoftPetWA
{
    public partial class Secretaria_ExpedienteDetalle : System.Web.UI.Page
    {
        private MascotaBO boMascota = new MascotaBO();
        private PersonaBO boPersona = new PersonaBO();
        private CitaAtencionBO boCita = new CitaAtencionBO();
        private RecetaMedicaBO boReceta = new RecetaMedicaBO();
        private ServicioBO boServicio = new ServicioBO();
        private VeterinarioBO boVet = new VeterinarioBO();

        // ViewModel para mostrar datos limpios en el Repeater de Consultas
        public class HistorialViewModel
        {
            public int CitaId { get; set; }
            public string Fecha { get; set; }
            public string Estado { get; set; }
            public string NombreVeterinario { get; set; } // Nombre real, no ID
            public string Observacion { get; set; }
            public double Peso { get; set; }
            public double Monto { get; set; }

            // Datos auxiliares de receta para mostrar resumen
            public bool TieneReceta { get; set; }
            public string Diagnostico { get; set; }
            public string Indicaciones { get; set; }
        }

        // ViewModel para Recetas
        public class RecetaViewModel
        {
            public int RecetaId { get; set; }
            public string Fecha { get; set; }
            public string Diagnostico { get; set; }
            public string Indicaciones { get; set; }
            public string Vigencia { get; set; }
            public string NombreVeterinario { get; set; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null)
                {
                    Response.Redirect("Secretaria_Expedientes.aspx");
                    return;
                }

                int mascotaID = Convert.ToInt32(Request.QueryString["id"]);
                hdMascotaID.Value = mascotaID.ToString();

                CargarDatosMascota(mascotaID);

                // Carga inicial: Pestaña Consultas
                CargarHistorialMedico(mascotaID);
                mvHistorial.ActiveViewIndex = 0; // Vista 0 = Consultas
            }
        }

        #region "Carga de Datos"

        private void CargarDatosMascota(int mascotaID)
        {
            mascotaDto mascota = boMascota.ObtenerPorId(mascotaID);
            if (mascota != null && mascota.mascotaId != 0)
            {
                var duenio = boPersona.ObtenerPorId(mascota.persona.personaId);

                lblMascotaNombre.Text = mascota.nombre;
                litNombreMascotaTitulo.Text = mascota.nombre;
                lblMascotaRaza.Text = $"{mascota.especie} - {mascota.raza}";

                string especie = mascota.especie != null ? mascota.especie.ToLower() : "";
                imgAvatarMascota.ImageUrl = (especie == "perro") ? "Images/Avatars/dog-avatar.png" : "Images/Avatars/cat-avatar.png";

                lblCodigo.Text = $"M-{mascota.mascotaId:D6}";
                lblSexo.Text = mascota.sexo;
                lblColor.Text = mascota.color;

                if (duenio != null)
                {
                    lblPropietarioNombre.Text = duenio.nombre;
                    lblPropietarioDNI.Text = $"Doc: {duenio.nroDocumento}";
                    lblPropietarioTelefono.Text = duenio.telefono;
                    lblPropietarioEmail.Text = "-";
                }

                lblEstado.Text = mascota.activo ? "Activo" : "Inactivo";
                lblEstado.CssClass = mascota.activo ? "badge bg-success" : "badge bg-secondary";
                lblPesoActual.Text = "-- kg";
                lblEdad.Text = "--";
            }
        }

        private void CargarHistorialMedico(int mascotaID)
        {
            // 1. Obtener Citas
            List<citaAtencionDto> listaCitas = boCita.ListarCitasPorMascota(mascotaID);
            if (listaCitas == null) listaCitas = new List<citaAtencionDto>();

            // 2. Obtener Veterinarios (Para mapear nombres)
            var listaVets = boVet.ListarTodos();
            var vetsDict = listaVets.ToDictionary(v => v.veterinarioId, v => (v.persona != null) ? v.persona.nombre : "Dr. Desconocido");

            // 3. Convertir a ViewModel
            // CORRECCIÓN: Ordenamos PRIMERO usando la fecha original, LUEGO convertimos a texto
            var historial = listaCitas
                .OrderByDescending(c => ParseFechaSafe(c.fechaRegistroStr)) // Ordenar aquí
                .Select(c =>
                {
                    string nombreVet = "Sin Asignar";
                    if (c.veterinario != null && vetsDict.ContainsKey(c.veterinario.veterinarioId))
                    {
                        nombreVet = vetsDict[c.veterinario.veterinarioId];
                    }

                    var receta = boReceta.ObtenerPorIdCita(c.citaId);
                    bool tieneReceta = (receta != null && receta.recetaMedicaId != 0);

                    return new HistorialViewModel
                    {
                        CitaId = c.citaId,
                        // Aquí ya solo formateamos para mostrar, no para ordenar
                        Fecha = ParseFechaSafe(c.fechaRegistroStr).ToString("dd 'de' MMMM, yyyy - hh:mm tt", new CultureInfo("es-ES")),
                        Estado = c.estado.ToString(),
                        NombreVeterinario = nombreVet,
                        Observacion = c.observacion,
                        Peso = c.pesoMascota,
                        Monto = c.monto,
                        TieneReceta = tieneReceta,
                        Diagnostico = tieneReceta ? receta.diagnostico : "",
                        Indicaciones = tieneReceta ? receta.observaciones : ""
                    };
                }).ToList(); // Ya no hacemos OrderBy aquí abajo

            rptHistorialMedico.DataSource = historial;
            rptHistorialMedico.DataBind();
        }

        private void CargarHistorialRecetas(int mascotaID)
        {
            // Lógica: Obtener todas las citas de la mascota -> Obtener IDs -> Filtrar recetas que coincidan
            List<citaAtencionDto> listaCitas = boCita.ListarCitasPorMascota(mascotaID);
            if (listaCitas == null || listaCitas.Count == 0)
            {
                rptRecetasLista.DataSource = null;
                rptRecetasLista.DataBind();
                return;
            }

            // Diccionario CitaID -> Nombre Veterinario
            var listaVets = boVet.ListarTodos();
            var vetsDict = listaVets.ToDictionary(v => v.veterinarioId, v => v.persona != null ? v.persona.nombre : "Dr.");

            var mapCitaVet = new Dictionary<int, string>();
            foreach (var c in listaCitas)
            {
                string nom = "Dr.";
                if (c.veterinario != null && vetsDict.ContainsKey(c.veterinario.veterinarioId)) nom = vetsDict[c.veterinario.veterinarioId];
                if (!mapCitaVet.ContainsKey(c.citaId)) mapCitaVet.Add(c.citaId, nom);
            }

            List<int> citasIds = listaCitas.Select(c => c.citaId).ToList();

            // Traer todas las recetas (Idealmente habría un método ListarPorMascota en el backend)
            List<recetaMedicaDto> todasLasRecetas = boReceta.ListarTodos();

            var recetasMascota = todasLasRecetas
                .Where(r => r.cita != null && citasIds.Contains(r.cita.citaId))
                .Select(r => new RecetaViewModel
                {
                    RecetaId = r.recetaMedicaId,
                    Fecha = ParseFechaSafe(r.fechaEmisionstr).ToString("dd/MM/yyyy"),
                    Vigencia = ParseFechaSafe(r.vigenciaHastastr).ToString("dd/MM/yyyy"),
                    Diagnostico = r.diagnostico,
                    Indicaciones = r.observaciones,
                    NombreVeterinario = mapCitaVet.ContainsKey(r.cita.citaId) ? mapCitaVet[r.cita.citaId] : "Dr."
                })
                .OrderByDescending(r => DateTime.Parse(r.Fecha))
                .ToList();

            rptRecetasLista.DataSource = recetasMascota;
            rptRecetasLista.DataBind();
        }

        private DateTime ParseFechaSafe(string fechaStr)
        {
            if (DateTime.TryParse(fechaStr, out DateTime dt)) return dt;
            return DateTime.Now;
        }

        #endregion

        #region "Pestañas"
        protected void btnTabConsultas_Click(object sender, EventArgs e)
        {
            btnTabConsultas.CssClass = "nav-link active";
            btnTabRecetas.CssClass = "nav-link";
            mvHistorial.ActiveViewIndex = 0;
            CargarHistorialMedico(Convert.ToInt32(hdMascotaID.Value));
        }

        protected void btnTabRecetas_Click(object sender, EventArgs e)
        {
            btnTabConsultas.CssClass = "nav-link";
            btnTabRecetas.CssClass = "nav-link active";
            mvHistorial.ActiveViewIndex = 1;
            CargarHistorialRecetas(Convert.ToInt32(hdMascotaID.Value));
        }
        #endregion

        #region "Eventos del Repeater"

        // Repeater Consultas
        protected void rptHistorialMedico_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            // Ya no necesitamos mucha lógica aquí porque usamos ViewModel, 
            // pero mantenemos el panel de receta visible/invisible según ViewModel
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var vm = (HistorialViewModel)e.Item.DataItem;
                Panel pnlReceta = (Panel)e.Item.FindControl("pnlReceta");
                pnlReceta.Visible = vm.TieneReceta;
            }
        }

        protected void rptHistorialMedico_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int citaId = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "Ver" || e.CommandName == "Editar")
            {
                CargarCombosModal();
                citaAtencionDto cita = boCita.ObtenerPorId(citaId);
                if (cita != null)
                {
                    hdHistorialID.Value = cita.citaId.ToString();
                    try { ddlModalVerVet.SelectedValue = cita.veterinario.veterinarioId.ToString(); } catch { }

                    txtModalVerMotivo.Text = cita.observacion;
                    recetaMedicaDto receta = boReceta.ObtenerPorIdCita(citaId);
                    txtModalVerDiagnostico.Text = (receta != null) ? receta.diagnostico : "";
                    txtModalVerPeso.Text = cita.pesoMascota.ToString();

                    bool esSoloLectura = (e.CommandName == "Ver");
                    ConfigurarModalVer(esSoloLectura);

                    updModalVerConsulta.Update();
                    ScriptManager.RegisterStartupScript(this, GetType(), "ShowVer", "$('#modalVerConsulta').modal('show');", true);
                }
            }
        }

        private void ConfigurarModalVer(bool readOnly)
        {
            ddlModalVerVet.Enabled = !readOnly;
            ddlModalVerServicio.Enabled = !readOnly;
            txtModalVerMotivo.ReadOnly = readOnly;
            txtModalVerDiagnostico.ReadOnly = readOnly;
            txtModalVerPeso.ReadOnly = readOnly;
            txtModalVerTemp.ReadOnly = readOnly;
            txtModalVerFrec.ReadOnly = readOnly;
            btnGuardarEdicionConsulta.Visible = !readOnly;
        }

        private void CargarCombosModal()
        {
            // Veterinarios con nombre mapeado
            var listaVetsRaw = boVet.ListarActivos();
            var listaVetsDisplay = listaVetsRaw.Select(v => new
            {
                Id = v.veterinarioId,
                NombreCompleto = (v.persona != null) ? v.persona.nombre : "Vet " + v.veterinarioId
            }).ToList();

            ddlModalVerVet.DataSource = listaVetsDisplay;
            ddlModalVerVet.DataTextField = "NombreCompleto";
            ddlModalVerVet.DataValueField = "Id";
            ddlModalVerVet.DataBind();

            // Servicios
            ddlModalVerServicio.DataSource = boServicio.listarServicioActivos();
            ddlModalVerServicio.DataTextField = "nombre";
            ddlModalVerServicio.DataValueField = "servicioId";
            ddlModalVerServicio.DataBind();
        }

        #endregion

        #region "Lógica Nueva Consulta"
        protected void btnNuevaConsulta_Click(object sender, EventArgs e)
        {
            // Cargar combos (reutilizando lógica)
            var listaVetsRaw = boVet.ListarActivos();
            var listaVetsDisplay = listaVetsRaw.Select(v => new { Id = v.veterinarioId, NombreCompleto = (v.persona != null) ? v.persona.nombre : "Vet" }).ToList();
            ddlModalConsultaVet.DataSource = listaVetsDisplay;
            ddlModalConsultaVet.DataTextField = "NombreCompleto";
            ddlModalConsultaVet.DataValueField = "Id";
            ddlModalConsultaVet.DataBind();

            ddlModalConsultaServicio.DataSource = boServicio.listarServicioActivos();
            ddlModalConsultaServicio.DataTextField = "nombre";
            ddlModalConsultaServicio.DataValueField = "servicioId";
            ddlModalConsultaServicio.DataBind();

            txtModalConsultaMotivo.Text = "";
            txtModalConsultaPeso.Text = "";
            updModalNuevaConsulta.Update();
            ScriptManager.RegisterStartupScript(this, GetType(), "ShowNew", "$('#modalNuevaConsulta').modal('show');", true);
        }

        protected void btnGuardarConsulta_Click(object sender, EventArgs e)
        {
            try
            {
                int mascotaId = Convert.ToInt32(hdMascotaID.Value);
                int vetId = Convert.ToInt32(ddlModalConsultaVet.SelectedValue);
                // Lógica insertar... (boCita.Insertar...)
                CargarHistorialMedico(mascotaId);
                updPanelDetalle.Update();
                ScriptManager.RegisterStartupScript(this, GetType(), "HideNew", "$('#modalNuevaConsulta').modal('hide');", true);
            }
            catch { }
        }
        #endregion

        protected void btnGuardarEdicionConsulta_Click(object sender, EventArgs e)
        {
            try
            {
                int citaId = Convert.ToInt32(hdHistorialID.Value);
                citaAtencionDto cita = boCita.ObtenerPorId(citaId);
                cita.observacion = txtModalVerMotivo.Text;
                if (double.TryParse(txtModalVerPeso.Text, out double peso)) cita.pesoMascota = peso;
                boCita.Modificar(cita);

                CargarHistorialMedico(Convert.ToInt32(hdMascotaID.Value));
                updPanelDetalle.Update();
                ScriptManager.RegisterStartupScript(this, GetType(), "HideEdit", "$('#modalVerConsulta').modal('hide');", true);
            }
            catch (Exception ex) { System.Diagnostics.Debug.WriteLine(ex.Message); }
        }
    }
}