﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading; // Para el efecto de carga
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient;
using SoftPetBussiness.CitaAtencionClient;
using SoftPetBussiness.VeterinarioClient;

// Alias
using mascotaDto = SoftPetBussiness.MascotaClient.mascotaDto;
using personaDto = SoftPetBussiness.PersonaClient.personaDto;
using citaAtencionDto = SoftPetBussiness.CitaAtencionClient.citaAtencionDto;
using veterinarioDto = SoftPetBussiness.VeterinarioClient.veterinarioDto;

namespace SoftPetWA
{
    public partial class Veterinario_Consulta : System.Web.UI.Page
    {
        private MascotaBO boMascota = new MascotaBO();
        private PersonaBO boPersona = new PersonaBO();
        private CitaAtencionBO boCita = new CitaAtencionBO();
        private VeterinarioBO boVet = new VeterinarioBO();

        // Guardamos ID Cita en ViewState para persistencia entre postbacks
        private int CitaIdActual
        {
            get { return ViewState["CitaIdActual"] != null ? (int)ViewState["CitaIdActual"] : 0; }
            set { ViewState["CitaIdActual"] = value; }
        }

        private int MascotaIdActual
        {
            get { return ViewState["ConsMascotaId"] != null ? (int)ViewState["ConsMascotaId"] : 0; }
            set { ViewState["ConsMascotaId"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string idStr = Request.QueryString["idMascota"];

                // Intentamos recuperar datos de sesión si venimos de la agenda
                // Pero idealmente necesitamos el ID de la CITA específica, no solo la mascota.
                // Por ahora, asumiremos que buscamos la cita pendiente de hoy para esa mascota.

                if (int.TryParse(idStr, out int id) && id > 0)
                {
                    MascotaIdActual = id;
                    CargarDatosReal(id);
                }
                else
                {
                    Response.Redirect("Veterinario_Agenda.aspx");
                }

                litFechaResumen.Text = DateTime.Now.ToString("dd/MM/yyyy hh:mm tt");
                if (Session["UsuarioNombre"] != null)
                    litVetResumen.Text = "Dr. " + Session["UsuarioNombre"].ToString();
            }
        }

        private void CargarDatosReal(int mascotaId)
        {
            try
            {
                // 1. Mascota y Dueño
                mascotaDto mascota = boMascota.ObtenerPorId(mascotaId);
                if (mascota == null) return;

                litNombrePacienteConsulta.Text = mascota.nombre;
                litRazaPacienteConsulta.Text = $"{mascota.especie} • {mascota.raza}";
                litSexoConsulta.Text = mascota.sexo == "M" ? "Macho" : "Hembra";
                litEdadConsulta.Text = "-"; // Calculada si hubiera fecha nac.

                string icono = "fas fa-paw";
                string colorAvatar = "avatar-lg-gray";
                if (mascota.especie != null)
                {
                    if (mascota.especie.ToLower().Contains("perro")) { icono = "fas fa-dog"; colorAvatar = "avatar-lg-blue"; }
                    else if (mascota.especie.ToLower().Contains("gato")) { icono = "fas fa-cat"; colorAvatar = "avatar-lg-orange"; }
                }
                litAvatarIconConsulta.Text = $"<i class='{icono}'></i>";
                if (pacienteAvatarLgDiv != null) pacienteAvatarLgDiv.Attributes["class"] = $"paciente-avatar-lg {colorAvatar} mb-3";

                if (mascota.persona != null)
                {
                    var duenio = boPersona.ObtenerPorId(mascota.persona.personaId);
                    if (duenio != null)
                    {
                        litPropietarioConsulta.Text = duenio.nombre;
                        litContactoConsulta.Text = duenio.telefono;
                    }
                }

                // 2. Buscar Cita PENDIENTE de HOY
                string hoyStr = DateTime.Today.ToString("yyyy-MM-dd");
                // Listamos citas de la mascota
                List<citaAtencionDto> historial = boCita.ListarCitasPorMascota(mascotaId);

                // Buscamos la cita PROGRAMADA más reciente (asumimos que es la que estamos atendiendo)
                var citaHoy = historial.Where(c => c.estado.ToString() == "PROGRAMADA")
                                       .OrderByDescending(c => c.citaId)
                                       .FirstOrDefault();

                // C. Buscar Cita de HOY (PROGRAMADA)
                // ... (código de búsqueda de citaHoy) ...

                if (citaHoy != null)
                {
                    CitaIdActual = citaHoy.citaId;

                    // --- CORRECCIÓN PARA MOSTRAR LA FECHA ---
                    try
                    {
                        dynamic ts = citaHoy.fechaHoraInicio;
                        long millis = (long)ts.time;
                        DateTime dt = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(millis).ToLocalTime();

                        // Asignamos la fecha formateada
                        litFechaHoraCitaConsulta.Text = dt.ToString("dd/MM/yyyy hh:mm tt");
                    }
                    catch
                    {
                        // Fallback si algo sale mal
                        litFechaHoraCitaConsulta.Text = DateTime.Now.ToString("dd/MM/yyyy hh:mm tt");
                    }

                    litTipoCitaConsulta.Text = "Consulta Programada";
                    txtMotivoConsulta.Text = citaHoy.observacion;
                }
                // Peso anterior
                var ultimaAtendida = historial.Where(c => c.estado.ToString() == "ATENDIDA")
                                              .OrderByDescending(c => c.citaId).FirstOrDefault();
                if (ultimaAtendida != null) litPesoAntConsulta.Text = $"{ultimaAtendida.pesoMascota} kg";

            }
            catch (Exception) { }
        }

        protected void btnCompletarConsulta_Click(object sender, EventArgs e)
        {
            // 1. Efecto visual
            System.Threading.Thread.Sleep(1500);

            try
            {
                if (CitaIdActual == 0)
                {
                    lblError.Text = "Error: No se encontró una cita activa.";
                    lblError.Visible = true;
                    return;
                }

                // 2. Recuperar objeto original
                citaAtencionDto cita = boCita.ObtenerPorId(CitaIdActual);
                if (cita == null) return;

                // 3. Datos del Formulario
                string obsFinal = $"[DIAGNÓSTICO]: {txtDiagnosticoClinico.Text} | [OBSERVACIONES]: {txtObservacionesClinicas.Text} | [TRATAMIENTO]: {txtPlanTratamiento.Text}";
                if (obsFinal.Length > 250) obsFinal = obsFinal.Substring(0, 250);

                double peso = 0;
                double.TryParse(txtPesoActual.Text, out peso);

                double monto = 0;
                double.TryParse(hfMontoTotal.Value, out monto);

                // 4. PREPARAR FECHAS (CORRECCIÓN DE FORMATO AQUÍ)
                string fechaInicioStr = "";
                string fechaFinStr = "";

                try
                {
                    // Leemos los milisegundos del timestamp de Java
                    dynamic tsIni = cita.fechaHoraInicio;
                    dynamic tsFin = cita.fechaHoraFin;

                    // Obtenemos el tiempo en milisegundos
                    long mIni = (long)tsIni.time;
                    long mFin = (long)tsFin.time;

                    // Convertimos a DateTime C#
                    DateTime dtIni = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(mIni).ToLocalTime();
                    DateTime dtFin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc).AddMilliseconds(mFin).ToLocalTime();

                    // ===========================================================================
                    // ¡AQUÍ ESTÁ EL CAMBIO! Usamos el formato con guiones y dos puntos
                    // ===========================================================================
                    fechaInicioStr = dtIni.ToString("yyyy-MM-dd HH:mm:ss");
                    fechaFinStr = dtFin.ToString("yyyy-MM-dd HH:mm:ss");
                }
                catch
                {
                    // Si falla la lectura, usamos la fecha actual con el mismo formato correcto
                    fechaInicioStr = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    fechaFinStr = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-dd HH:mm:ss");
                }

                // 5. LLAMAR AL BO
                int resultado = boCita.Modificar(
                    cita.citaId,
                    cita.veterinario.veterinarioId,
                    cita.mascota.mascotaId,
                    fechaInicioStr, // Enviamos formato: "2025-11-19 01:30:00"
                    fechaFinStr,    // Enviamos formato: "2025-11-19 02:00:00"
                    peso,
                    monto,
                    "ATENDIDA",
                    obsFinal,
                    true
                );

                if (resultado > 0)
                {
                    string script = "$('#modalExito').modal('show');";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ShowSuccess", script, true);
                }
                else
                {
                    lblError.Text = "No se pudo guardar. Verifique los datos.";
                    lblError.Visible = true;
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Error al convertir fechas: " + ex.Message;
                lblError.Visible = true;
            }
        }
        protected void btnVolverAgenda_Click(object sender, EventArgs e) { Response.Redirect("~/Veterinario_Agenda.aspx"); }
        protected void btnVerHistorialCompleto_Click(object sender, EventArgs e) { /* Redirigir */ }
        protected void btnGenerarReceta_Click(object sender, EventArgs e) { /* Generar PDF */ }
        protected void btnCancelarConsulta_Click(object sender, EventArgs e) { Response.Redirect("~/Veterinario_Agenda.aspx"); }
        protected void btnGuardarBorrador_Click(object sender, EventArgs e) { /* Guardar sin finalizar */ }
    }
}