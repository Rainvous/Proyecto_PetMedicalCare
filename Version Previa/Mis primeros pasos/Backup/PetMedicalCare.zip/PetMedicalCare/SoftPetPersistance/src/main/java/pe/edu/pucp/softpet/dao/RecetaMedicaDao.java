package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.recetas.RecetaMedicaDto;

/**
 *
 * @author marti
 */
public interface RecetaMedicaDao extends DaoBase<RecetaMedicaDto> {
    
}
