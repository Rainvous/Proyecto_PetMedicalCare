package pe.edu.pucp.softpet.dto.util.enums;

public enum EstadoLaboral {
    DISPONIBLE,
    NO_DISPONIBLE
}
