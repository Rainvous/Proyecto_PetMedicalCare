package pe.edu.pucp.softpet.daoImpl.util;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR
}
