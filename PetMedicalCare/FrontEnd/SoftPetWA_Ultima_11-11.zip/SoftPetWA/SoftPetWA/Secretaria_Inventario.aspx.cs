﻿// Nombre del archivo: Secretaria_Inventario.aspx.cs (Actualizado)
using System;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftPetWA
{
    public partial class Secretaria_Inventario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Almacenamos los datos de prueba en la Sesión
                Session["InventarioData"] = ObtenerInventarioEjemplo();

                CargarFiltros();
                CargarInventario();
            }
        }

        private void CargarFiltros()
        {
            // Cargar DropDownList de Estado de Stock
            DataTable dtEstado = new DataTable();
            dtEstado.Columns.Add("EstadoID", typeof(string));
            dtEstado.Columns.Add("Nombre", typeof(string));
            dtEstado.Rows.Add("TODOS", "Todos");
            dtEstado.Rows.Add("Activo", "Activo");
            dtEstado.Rows.Add("Inactivo", "Inactivo"); // Añadido
            dtEstado.Rows.Add("Agotado", "Agotado");

            ddlEstadoStock.DataSource = dtEstado;
            ddlEstadoStock.DataTextField = "Nombre";
            ddlEstadoStock.DataValueField = "EstadoID";
            ddlEstadoStock.DataBind();

            // Cargar Pestañas de Filtro (ejemplo)
            DataTable dtTipos = new DataTable();
            dtTipos.Columns.Add("Tipo", typeof(string));
            dtTipos.Columns.Add("Cantidad", typeof(int));
            dtTipos.Rows.Add("Todos", 45);
            dtTipos.Rows.Add("Medicamento", 15);
            dtTipos.Rows.Add("Alimento", 12);
            dtTipos.Rows.Add("Accesorio", 8);
            dtTipos.Rows.Add("Higiene", 6);
            dtTipos.Rows.Add("Juguetes", 4);

            rptFiltroTipo.DataSource = dtTipos;
            rptFiltroTipo.DataBind();

            // Cargar DropDownList del Modal (Tipos de producto)
            // Excluimos "Todos" de la lista de tipos para el modal
            var tiposParaModal = dtTipos.AsEnumerable()
                                        .Where(row => row.Field<string>("Tipo") != "Todos")
                                        .CopyToDataTable();

            ddlModalTipo.DataSource = tiposParaModal;
            ddlModalTipo.DataTextField = "Tipo";
            ddlModalTipo.DataValueField = "Tipo";
            ddlModalTipo.DataBind();
        }

        private void CargarInventario()
        {
            // Leemos los datos desde la Sesión
            DataTable dt = Session["InventarioData"] as DataTable;

            if (dt != null)
            {
                // Lógica de Filtro (Ejemplo simple)
                var query = dt.AsEnumerable();

                if (!string.IsNullOrWhiteSpace(txtNombreProducto.Text))
                {
                    query = query.Where(r => r.Field<string>("Nombre").ToLower().Contains(txtNombreProducto.Text.ToLower()));
                }
                if (!string.IsNullOrWhiteSpace(txtPresentacion.Text))
                {
                    query = query.Where(r => r.Field<string>("Presentacion").ToLower().Contains(txtPresentacion.Text.ToLower()));
                }
                if (ddlEstadoStock.SelectedValue != "TODOS")
                {
                    query = query.Where(r => r.Field<string>("Estado") == ddlEstadoStock.SelectedValue);
                }

                DataTable dtFiltrado = dt.Clone(); // Clona la estructura
                if (query.Any())
                {
                    dtFiltrado = query.CopyToDataTable();
                }

                rptInventario.DataSource = dtFiltrado;
                rptInventario.DataBind();

                // Actualizar contadores
                litRegistrosTotales.Text = dt.Rows.Count.ToString();
                litRegistrosActuales.Text = $"1-{dtFiltrado.Rows.Count}";
            }
        }

        private DataTable ObtenerInventarioEjemplo()
        {
            DataTable dt = new DataTable();
            // Columnas de datos "crudos"
            dt.Columns.Add("ProductoID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Columns.Add("Descripcion", typeof(string));
            dt.Columns.Add("Tipo", typeof(string));
            dt.Columns.Add("Presentacion", typeof(string));
            dt.Columns.Add("Precio", typeof(double));
            dt.Columns.Add("Stock", typeof(int));
            dt.Columns.Add("Estado", typeof(string));
            // Columnas de formato (visuales)
            dt.Columns.Add("TipoClaseCss", typeof(string));
            dt.Columns.Add("PrecioFormateado", typeof(string));
            dt.Columns.Add("StockTexto", typeof(string));
            dt.Columns.Add("StockCss", typeof(string));
            dt.Columns.Add("EstadoClaseCss", typeof(string));
            dt.Columns.Add("IconoCss", typeof(string));
            dt.Columns.Add("IconoColorCss", typeof(string));

            // Datos de ejemplo
            dt.Rows.Add(1, "AMOXICILINA 500MG", "Antibiótico de amplio espectro", "Medicamento", "Caja x 10 tabletas", 35.00, 85, "Activo", "type-medicamento", "S/ 35.00", "85 unidades", "", "status-activo", "fas fa-pills", "icon-bg-medicamento");
            dt.Rows.Add(2, "VACUNA ANTIRRÁBICA", "Inmunización contra rabia canina", "Medicamento", "Dosis única 1ml", 45.00, 5, "Activo", "type-medicamento", "S/ 45.00", "5 unidades", "stock-warning", "status-activo", "fas fa-syringe", "icon-bg-medicamento");
            dt.Rows.Add(3, "ALIMENTO PREMIUM ADULTO", "Concentrado para perros adultos", "Alimento", "Bolsa 15Kg", 180.00, 32, "Activo", "type-alimento", "S/ 180.00", "32 unidades", "", "status-activo", "fas fa-bone", "icon-bg-alimento");
            dt.Rows.Add(4, "ALIMENTO PARA GATOS", "Nutrición balanceada para felinos", "Alimento", "Bolsa 8Kg", 120.00, 58, "Activo", "type-alimento", "S/ 120.00", "58 unidades", "", "status-activo", "fas fa-cat", "icon-bg-alimento");
            dt.Rows.Add(5, "COLLAR ANTIPULGAS", "Protección por 8 meses", "Accesorio", "Unidad", 55.00, 24, "Activo", "type-accesorio", "S/ 55.00", "24 unidades", "", "status-activo", "fas fa-tag", "icon-bg-accesorio");
            dt.Rows.Add(6, "SHAMPOO MEDICADO", "Para pieles sensibles", "Higiene", "Frasco 500ml", 68.00, 0, "Agotado", "type-higiene", "S/ 68.00", "0 unidades", "stock-warning", "status-agotado", "fas fa-pump-soap", "icon-bg-higiene");

            return dt;
        }

        // --- Eventos de Botones (Filtros) ---

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarInventario();
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombreProducto.Text = "";
            txtPresentacion.Text = "";
            ddlEstadoStock.SelectedIndex = 0;
            CargarInventario();
            // Limpiar también los filtros de pestañas
            rptFiltroTipo.DataBind();
        }

        protected void rptFiltroTipo_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            // Lógica para filtrar por tipo al hacer clic en las pestañas
        }

        // --- Eventos de los Modals (Producto) ---

        protected void btnGuardarProducto_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["InventarioData"] as DataTable;
            if (dt == null) return;

            try
            {
                int productoID = Convert.ToInt32(hdProductoID.Value);

                // Recolectar datos del modal
                string nombre = txtModalNombre.Text;
                string tipo = ddlModalTipo.SelectedValue;
                string descripcion = txtModalDescripcion.Text;
                string presentacion = txtModalPresentacion.Text;
                double precio = double.Parse(txtModalPrecio.Text, CultureInfo.InvariantCulture);
                int stock = int.Parse(txtModalStock.Text);
                string estado = ddlModalEstado.SelectedValue;

                // Generar datos visuales (helpers)
                string tipoClaseCss = GetTipoClasePorTipo(tipo);
                string precioFormateado = string.Format("S/ {0:N2}", precio);
                string stockTexto = $"{stock} unidades";
                string stockCss = stock < 10 ? "stock-warning" : "";
                string estadoClaseCss = estado == "Activo" ? "status-activo" : (estado == "Agotado" ? "status-agotado" : "status-inactivo");
                string iconoCss = GetIconoPorTipo(tipo);
                string iconoColorCss = GetColorPorTipo(tipo);


                if (productoID == 0)
                {
                    // --- CREAR NUEVO PRODUCTO ---
                    int newID = dt.Rows.Count > 0 ? dt.AsEnumerable().Max(row => row.Field<int>("ProductoID")) + 1 : 1;

                    dt.Rows.Add(
                        newID,
                        nombre,
                        descripcion,
                        tipo,
                        presentacion,
                        precio,
                        stock,
                        estado,
                        tipoClaseCss,
                        precioFormateado,
                        stockTexto,
                        stockCss,
                        estadoClaseCss,
                        iconoCss,
                        iconoColorCss
                    );
                }
                else
                {
                    // --- EDITAR PRODUCTO EXISTENTE ---
                    DataRow row = dt.AsEnumerable().FirstOrDefault(r => r.Field<int>("ProductoID") == productoID);
                    if (row != null)
                    {
                        row["Nombre"] = nombre;
                        row["Descripcion"] = descripcion;
                        row["Tipo"] = tipo;
                        row["Presentacion"] = presentacion;
                        row["Precio"] = precio;
                        row["Stock"] = stock;
                        row["Estado"] = estado;
                        row["TipoClaseCss"] = tipoClaseCss;
                        row["PrecioFormateado"] = precioFormateado;
                        row["StockTexto"] = stockTexto;
                        row["StockCss"] = stockCss;
                        row["EstadoClaseCss"] = estadoClaseCss;
                        row["IconoCss"] = iconoCss;
                        row["IconoColorCss"] = iconoColorCss;
                    }
                }

                Session["InventarioData"] = dt;
                CargarInventario();
                updPanelInventario.Update();
            }
            catch (Exception ex)
            {
                // Manejo básico de errores (se podría mostrar en un label)
                Console.Write(ex.Message);
            }
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["InventarioData"] as DataTable;
            if (dt == null) return;

            try
            {
                int productoID = Convert.ToInt32(hdProductoIDEliminar.Value);
                DataRow row = dt.AsEnumerable().FirstOrDefault(r => r.Field<int>("ProductoID") == productoID);

                if (row != null)
                {
                    dt.Rows.Remove(row);
                }

                Session["InventarioData"] = dt;
                CargarInventario();
                updPanelInventario.Update();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        // --- Funciones Helper para la UI ---

        private string GetTipoClasePorTipo(string tipo)
        {
            switch (tipo.ToLower())
            {
                case "medicamento": return "type-medicamento";
                case "alimento": return "type-alimento";
                case "accesorio": return "type-accesorio";
                case "higiene": return "type-higiene";
                case "juguetes": return "type-juguete"; // Asumiendo
                default: return "type-default";
            }
        }

        private string GetIconoPorTipo(string tipo)
        {
            switch (tipo.ToLower())
            {
                case "medicamento": return "fas fa-pills";
                case "alimento": return "fas fa-bone";
                case "accesorio": return "fas fa-tag";
                case "higiene": return "fas fa-pump-soap";
                case "juguetes": return "fas fa-baseball-ball"; // Asumiendo
                default: return "fas fa-box";
            }
        }

        private string GetColorPorTipo(string tipo)
        {
            switch (tipo.ToLower())
            {
                case "medicamento": return "icon-bg-medicamento";
                case "alimento": return "icon-bg-alimento";
                case "accesorio": return "icon-bg-accesorio";
                case "higiene": return "icon-bg-higiene";
                case "juguetes": return "icon-bg-juguete"; // Asumiendo
                default: return "icon-bg-default";
            }
        }

    }
}