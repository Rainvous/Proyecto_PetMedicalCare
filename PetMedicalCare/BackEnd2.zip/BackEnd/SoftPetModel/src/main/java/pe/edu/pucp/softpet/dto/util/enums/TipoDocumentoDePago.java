package pe.edu.pucp.softpet.dto.util.enums;

public enum TipoDocumentoDePago {
    BOLETA,
    FACTURA
}
