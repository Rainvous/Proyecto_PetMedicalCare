﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient;

namespace SoftPetWA
{
    public partial class Secretaria_Expedientes : System.Web.UI.Page
    {
        private MascotaBO boMascota = new MascotaBO();
        private PersonaBO boPersona = new PersonaBO();

        public class ExpedienteViewModel
        {
            public int MascotaID { get; set; }
            public string MascotaNombre { get; set; }
            public string EspecieRaza { get; set; }
            public string AvatarIcon { get; set; } // Aquí guardamos la clase del ícono (fas fa-dog)
            public string PropietarioNombre { get; set; }
            public string Documento { get; set; }
            public DateTime? UltimaVisita { get; set; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarFiltros();
                CargarExpedientes();
            }
        }

        private void CargarFiltros()
        {
            DataTable dtTipo = new DataTable();
            dtTipo.Columns.Add("Nombre", typeof(string));
            dtTipo.Rows.Add("Todos");
            dtTipo.Rows.Add("Perro");
            dtTipo.Rows.Add("Gato");

            ddlTipo.DataSource = dtTipo;
            ddlTipo.DataTextField = "Nombre";
            ddlTipo.DataValueField = "Nombre";
            ddlTipo.DataBind();
        }

        private void CargarExpedientes()
        {
            string nombreMascota = txtNombre.Text.Trim();
            List<mascotaDto> listaMascotas;

            if (!string.IsNullOrWhiteSpace(nombreMascota) || ddlTipo.SelectedValue != "Todos")
            {
                string especie = ddlTipo.SelectedValue == "Todos" ? "" : ddlTipo.SelectedValue;
                listaMascotas = boMascota.ListarPorNombreRazaEspecieNombrepersona(nombreMascota, "", especie, nombreMascota);
            }
            else
            {
                listaMascotas = boMascota.ListarTodos();
            }

            if (listaMascotas == null) listaMascotas = new List<mascotaDto>();

            List<SoftPetBussiness.PersonaClient.personaDto> listaPersonas = boPersona.ListarTodos();
            var personasDict = listaPersonas.ToDictionary(p => p.personaId);

            var listaView = listaMascotas.Select(m =>
            {
                string nombreDuenio = "Sin Asignar";
                string docDuenio = "-";

                if (m.persona != null && personasDict.ContainsKey(m.persona.personaId))
                {
                    var p = personasDict[m.persona.personaId];
                    nombreDuenio = p.nombre;
                    docDuenio = p.nroDocumento.ToString();
                }

                return new ExpedienteViewModel
                {
                    MascotaID = m.mascotaId,
                    MascotaNombre = m.nombre,
                    EspecieRaza = $"{m.especie} - {m.raza}",
                    // Lógica de Ícono
                    AvatarIcon = GetIconoEspecie(m.especie),
                    PropietarioNombre = nombreDuenio,
                    Documento = docDuenio,
                    UltimaVisita = null
                };
            }).ToList();

            if (!string.IsNullOrWhiteSpace(txtDocumento.Text))
                listaView = listaView.Where(x => x.Documento.Contains(txtDocumento.Text)).ToList();

            rptExpedientesLista.DataSource = listaView;
            rptExpedientesLista.DataBind();

            litRegistrosTotales.Text = listaView.Count.ToString();
            litRegistrosActuales.Text = listaView.Count > 0 ? $"1-{listaView.Count}" : "0-0";
        }

        protected void btnBuscar_Click(object sender, EventArgs e) { CargarExpedientes(); }
        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Text = ""; txtDocumento.Text = ""; txtTelefono.Text = ""; ddlTipo.SelectedIndex = 0;
            CargarExpedientes();
        }

        // Helper para el ícono (Igual que en Mascotas)
        protected string GetIconoEspecie(string especie)
        {
            if (string.IsNullOrEmpty(especie)) return "fas fa-paw";
            string e = especie.Trim().ToLower();
            if (e == "perro") return "fas fa-dog";
            if (e == "gato") return "fas fa-cat";
            return "fas fa-paw";
        }
    }
}