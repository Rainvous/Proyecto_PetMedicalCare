﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient;

// Alias para DTOs
using mascotaDto = SoftPetBussiness.MascotaClient.mascotaDto;
using personaDto = SoftPetBussiness.PersonaClient.personaDto;

namespace SoftPetWA
{
    public partial class Cliente_Mascotas : System.Web.UI.Page
    {
        private MascotaBO boMascota = new MascotaBO();
        private PersonaBO boPersona = new PersonaBO();

        protected void Page_Load(object sender, EventArgs e)
        {
            // 1. Seguridad de Sesión
            if (Session["UsuarioId"] == null)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            // 2. Autocorrección de PersonaId (Por si el login falló en guardarlo)
            if (Session["PersonaId"] == null)
            {
                try
                {
                    int uid = Convert.ToInt32(Session["UsuarioId"]);
                    var todas = boPersona.ListarSoloClientes(); // O el método de búsqueda optimizado si existe
                    var p = todas.FirstOrDefault(x => x.usuario != null && x.usuario.usuarioId == uid);
                    if (p != null) Session["PersonaId"] = p.personaId;
                }
                catch { }
            }

            if (!IsPostBack)
            {
                CargarMascotasCliente();
            }
        }

        private void CargarMascotasCliente()
        {
            try
            {
                // Validamos que tengamos un cliente identificado
                if (Session["PersonaId"] != null)
                {
                    int clienteId = Convert.ToInt32(Session["PersonaId"]);

                    // LLAMADA AL SERVICIO SOAP REAL
                    List<mascotaDto> mascotas = boMascota.ListarPorIdPersona(clienteId);

                    // Transformamos los datos para que se vean bonitos en la tarjeta
                    var mascotasVM = mascotas.Select(m => new
                    {
                        MascotaID = m.mascotaId,
                        Nombre = m.nombre,
                        EspecieRaza = $"{m.especie} - {m.raza}",
                        Color = m.color,
                        Sexo = m.sexo,

                        // Asignar avatar según especie (Asegúrate de tener las imágenes en esa ruta)
                        AvatarURL = (m.especie != null && (m.especie.ToLower().Contains("perro") || m.especie.ToLower().Contains("canino")))
                                    ? "~/Images/Avatars/dog-avatar.png"
                                    : (m.especie != null && (m.especie.ToLower().Contains("gato") || m.especie.ToLower().Contains("felino")))
                                        ? "~/Images/Avatars/cat-avatar.png"
                                        : ""
                    }).ToList();

                    rptMascotasCliente.DataSource = mascotasVM;
                    rptMascotasCliente.DataBind();
                }
                else
                {
                    rptMascotasCliente.DataSource = null;
                    rptMascotasCliente.DataBind();
                }
            }
            catch (Exception)
            {
                rptMascotasCliente.DataSource = null;
                rptMascotasCliente.DataBind();
            }
        }

        protected void rptMascotasCliente_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            string mascotaID = e.CommandArgument.ToString();

            if (e.CommandName == "VerHistorial")
            {
                // Redirigir a la pantalla de historial médico
                Response.Redirect($"Cliente_HistorialMedico.aspx?mascotaId={mascotaID}");
            }
        }
    }
}