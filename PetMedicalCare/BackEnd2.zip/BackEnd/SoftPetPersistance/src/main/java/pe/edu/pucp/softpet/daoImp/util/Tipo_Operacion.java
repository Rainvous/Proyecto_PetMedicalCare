package pe.edu.pucp.softpet.daoImp.util;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR
}
