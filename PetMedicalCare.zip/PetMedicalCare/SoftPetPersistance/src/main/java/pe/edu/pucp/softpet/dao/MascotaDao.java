package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.mascotas.MascotaDto;

public interface MascotaDao extends DaoBase<MascotaDto> {
    
}
