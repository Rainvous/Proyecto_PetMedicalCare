﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
// Alias importantes
using SvcWS = SoftPetBussiness.ServicioClient;
using TipoWS = SoftPetBussiness.TipoServicioClient;

namespace SoftPetWA
{
    public partial class Secretaria_Servicios : System.Web.UI.Page
    {
        private ServicioBO boServicio = new ServicioBO();
        private TipoServicioBO boTipoServicio = new TipoServicioBO();

        private const int PageSize = 8;

        public int CurrentPage
        {
            get { return (int)(ViewState["CurrentPage"] ?? 1); }
            set { ViewState["CurrentPage"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewState["FiltroTipoID"] = 0;
                CurrentPage = 1;
                CargarFiltrosDropDowns();
                CargarPaginaDatos();
            }
        }

        // =================================================================
        // MÉTODO AUXILIAR DE HIDRATACIÓN (Nuevo)
        // =================================================================
        // Este método cruza cualquier lista de servicios con los Tipos para obtener los nombres.
        private void HidratarListaServicios(List<SvcWS.servicioDto> listaServicios)
        {
            // Obtenemos tipos para el cruce
            List<TipoWS.tipoServicioDto> listaTipos = boTipoServicio.ListarTodos();
            if (listaTipos == null) listaTipos = new List<TipoWS.tipoServicioDto>();

            var tiposDict = listaTipos.ToDictionary(t => t.tipoServicioId);

            foreach (var svc in listaServicios)
            {
                if (svc.tipoServicio != null && tiposDict.ContainsKey(svc.tipoServicio.tipoServicioId))
                {
                    var tipoReal = tiposDict[svc.tipoServicio.tipoServicioId];
                    svc.tipoServicio = new SvcWS.tipoServicioDto
                    {
                        tipoServicioId = tipoReal.tipoServicioId,
                        nombre = tipoReal.nombre,
                        descripcion = tipoReal.descripcion,
                        activo = tipoReal.activo
                    };
                }
                else
                {
                    svc.tipoServicio = new SvcWS.tipoServicioDto { nombre = "Sin Tipo", descripcion = "" };
                }
            }
        }

        private void CargarPaginaDatos()
        {
            // Carga inicial: Listar todo
            List<SvcWS.servicioDto> listaServicios = boServicio.ListarTodos();
            if (listaServicios == null) listaServicios = new List<SvcWS.servicioDto>();

            // Usamos el método auxiliar para llenar los nombres de los tipos
            HidratarListaServicios(listaServicios);

            // Guardamos en ViewState y cargamos pestañas
            ViewState["ListaMaestraServicios"] = listaServicios;
            CargarFiltrosPestanas(listaServicios);

            EnlazarDatos();
        }

        private void CargarFiltrosDropDowns()
        {
            // Rango Costo (Values mapeados según tu BO/SP)
            DataTable dtRango = new DataTable();
            dtRango.Columns.Add("ID", typeof(string)); dtRango.Columns.Add("Txt", typeof(string));
            dtRango.Rows.Add("", "Todos"); // Vacío para el SP
            dtRango.Rows.Add("1", "S/ 0 - S/ 50");
            dtRango.Rows.Add("2", "S/ 51 - S/ 150");
            dtRango.Rows.Add("3", "S/ 151 a más");

            ddlRangoCosto.DataSource = dtRango;
            ddlRangoCosto.DataTextField = "Txt"; ddlRangoCosto.DataValueField = "ID"; ddlRangoCosto.DataBind();

            // Estado
            DataTable dtEstado = new DataTable();
            dtEstado.Columns.Add("ID", typeof(string)); dtEstado.Columns.Add("Txt", typeof(string));
            dtEstado.Rows.Add("", "Todos"); // Vacío para el SP
            dtEstado.Rows.Add("1", "Activo");
            dtEstado.Rows.Add("0", "Inactivo");

            ddlEstado.DataSource = dtEstado;
            ddlEstado.DataTextField = "Txt"; ddlEstado.DataValueField = "ID"; ddlEstado.DataBind();

            // Modal Tipos
            List<TipoWS.tipoServicioDto> tipos = boTipoServicio.ListarTodos();
            ddlModalTipo.DataSource = tipos.Where(t => t.activo == true).ToList();
            ddlModalTipo.DataTextField = "nombre";
            ddlModalTipo.DataValueField = "tipoServicioId";
            ddlModalTipo.DataBind();
            ddlModalTipo.Items.Insert(0, new ListItem("Seleccione...", "0"));
        }

        private void CargarFiltrosPestanas(List<SvcWS.servicioDto> servicios)
        {
            var grupos = servicios
                .GroupBy(s => new { s.tipoServicio.tipoServicioId, s.tipoServicio.nombre })
                .Select(g => new { TipoID = g.Key.tipoServicioId, Tipo = g.Key.nombre, Cantidad = g.Count() })
                .OrderBy(x => x.Tipo).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("Tipo", typeof(string)); dt.Columns.Add("TipoID", typeof(int)); dt.Columns.Add("Cantidad", typeof(int));
            dt.Rows.Add("Todos", 0, servicios.Count);
            foreach (var g in grupos) dt.Rows.Add(g.Tipo, g.TipoID, g.Cantidad);

            rptFiltroTipo.DataSource = dt; rptFiltroTipo.DataBind();
        }

        // =================================================================
        // LÓGICA DE BÚSQUEDA AVANZADA CON EL BO
        // =================================================================
        private List<SvcWS.servicioDto> ObtenerListaFiltrada()
        {
            // 1. Obtener parámetros de la UI
            string nombre = txtNombreServicio.Text.Trim();
            string rango = ddlRangoCosto.SelectedValue; // "1", "2", "3" o ""
            string activo = ddlEstado.SelectedValue;    // "1", "0" o ""

            // 2. LLAMAR AL MÉTODO DEL BO ESPECÍFICO PARA BÚSQUEDA
            //    Nota: Si no hay filtros, esto actuará como un listar todos o filtrado base
            List<SvcWS.servicioDto> listaResultado = boServicio.listarPorNombreRangoActivo(nombre, rango, activo);

            if (listaResultado == null) listaResultado = new List<SvcWS.servicioDto>();

            // 3. HIDRATAR LA LISTA RESULTANTE (Importante para ver íconos y nombres de tipo)
            HidratarListaServicios(listaResultado);

            // 4. Aplicar filtro de Pestaña (Tipo) en memoria
            //    (El SP de búsqueda avanzada no parece filtrar por Tipo ID específico, 
            //     así que mantenemos esta parte lógica aquí para que funcionen las tabs)
            int tipoId = (int)(ViewState["FiltroTipoID"] ?? 0);
            if (tipoId > 0)
            {
                listaResultado = listaResultado.Where(s => s.tipoServicio.tipoServicioId == tipoId).ToList();
            }

            return listaResultado;
        }

        private void EnlazarDatos()
        {
            // Ahora llamamos a la lógica que usa el BO de búsqueda
            var lista = ObtenerListaFiltrada();

            litRegistrosTotales.Text = lista.Count.ToString();
            int inicio = (CurrentPage - 1) * PageSize + 1;
            int fin = Math.Min(CurrentPage * PageSize, lista.Count);
            if (fin == 0) inicio = 0;
            litRegistrosActuales.Text = $"{inicio}-{fin}";

            rptServicios.DataSource = lista.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();
            rptServicios.DataBind();
            GenerarPaginado(lista.Count);
        }

        private void GenerarPaginado(int total)
        {
            int totalPages = (int)Math.Ceiling((double)total / PageSize);
            lnkAnterior.Enabled = CurrentPage > 1;
            lnkSiguiente.Enabled = CurrentPage < totalPages;
            var paginas = new List<object>();
            if (total > 0) for (int i = 1; i <= totalPages; i++) paginas.Add(new { Pagina = i, EsPaginaActual = (i == CurrentPage) });
            rptPaginador.DataSource = paginas; rptPaginador.DataBind();
        }

        // --- Eventos UI ---
        protected void btnBuscar_Click(object sender, EventArgs e) { CurrentPage = 1; EnlazarDatos(); }
        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombreServicio.Text = ""; ddlRangoCosto.SelectedIndex = 0; ddlEstado.SelectedIndex = 0;
            ViewState["FiltroTipoID"] = 0; CurrentPage = 1;
            CargarPaginaDatos(); // Recarga limpia
        }
        protected void rptFiltroTipo_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            ViewState["FiltroTipoID"] = Convert.ToInt32(e.CommandArgument);
            CurrentPage = 1; EnlazarDatos();
            // Nota: Aquí podríamos actualizar las pestañas si quisiéramos que reflejen el conteo de la búsqueda actual
        }
        protected void lnkPaginado_Click(object sender, EventArgs e)
        {
            string cmd = ((LinkButton)sender).CommandName;
            if (cmd == "Anterior" && CurrentPage > 1) CurrentPage--;
            else if (cmd == "Siguiente") CurrentPage++;
            EnlazarDatos();
        }
        protected void rptPaginador_ItemCommand(object source, RepeaterCommandEventArgs e) { CurrentPage = Convert.ToInt32(e.CommandArgument); EnlazarDatos(); }

        // --- CRUD ---

        protected void btnNuevoServicio_Click(object sender, EventArgs e)
        {
            hdServicioID.Value = "0";
            txtModalNombre.Text = "";
            ddlModalTipo.SelectedIndex = 0;
            txtModalDescripcion.Text = "";
            txtModalPrecio.Text = "";
            ddlModalEstado.SelectedValue = "true";

            SetModalReadOnly(false);
            updModalServicio.Update();

            ScriptManager.RegisterStartupScript(this, GetType(), "ShowNew", "$('#modalServicioLabel').text('Registrar Nuevo Servicio'); $('#modalServicio').modal('show');", true);
        }

        protected void rptServicios_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "Eliminar")
            {
                var s = boServicio.ObtenerPorId(id);
                if (s != null)
                {
                    hdServicioIDEliminar.Value = id.ToString();
                    ScriptManager.RegisterStartupScript(this, GetType(), "ShowDel",
                        $"$('#lblNombreServicioEliminar').text('{s.nombre}'); $('#modalConfirmarEliminar').modal('show');", true);
                }
            }
            else if (e.CommandName == "Ver" || e.CommandName == "Editar")
            {
                var s = boServicio.ObtenerPorId(id);
                if (s != null)
                {
                    hdServicioID.Value = s.servicioId.ToString();
                    txtModalNombre.Text = s.nombre;

                    if (s.tipoServicio != null && ddlModalTipo.Items.FindByValue(s.tipoServicio.tipoServicioId.ToString()) != null)
                        ddlModalTipo.SelectedValue = s.tipoServicio.tipoServicioId.ToString();
                    else
                        ddlModalTipo.SelectedIndex = 0;

                    txtModalDescripcion.Text = s.descripcion;
                    txtModalPrecio.Text = s.costo.ToString("0.00", CultureInfo.InvariantCulture);
                    ddlModalEstado.SelectedValue = s.activo.ToString().ToLower();

                    bool esVer = e.CommandName == "Ver";
                    SetModalReadOnly(esVer);

                    updModalServicio.Update();
                    string titulo = esVer ? "Detalles del Servicio" : "Modificar Servicio";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ShowModal",
                        $"$('#modalServicioLabel').text('{titulo}'); $('#modalServicio').modal('show');", true);
                }
            }
        }

        protected void btnGuardarServicio_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(hdServicioID.Value);
                int tipoId = Convert.ToInt32(ddlModalTipo.SelectedValue);
                if (tipoId == 0) return;

                string nom = txtModalNombre.Text;
                string desc = txtModalDescripcion.Text;
                double costo = double.Parse(txtModalPrecio.Text, CultureInfo.InvariantCulture);
                bool act = bool.Parse(ddlModalEstado.SelectedValue);
                string estadoStr = act ? "Activo" : "Inactivo";

                if (id == 0) boServicio.Insertar(tipoId, nom, desc, costo, estadoStr, act);
                else boServicio.Modificar(id, tipoId, nom, desc, costo, estadoStr, act);

                CargarPaginaDatos();
                updPanelServicios.Update();
                ScriptManager.RegisterStartupScript(this, GetType(), "HideM", "$('#modalServicio').modal('hide');", true);
            }
            catch (Exception ex) { }
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                boServicio.Eliminar(Convert.ToInt32(hdServicioIDEliminar.Value));
                CargarPaginaDatos();
                updPanelServicios.Update();
                ScriptManager.RegisterStartupScript(this, GetType(), "HideDel", "$('#modalConfirmarEliminar').modal('hide');", true);
            }
            catch (Exception) { }
        }

        private void SetModalReadOnly(bool readOnly)
        {
            txtModalNombre.ReadOnly = readOnly;
            ddlModalTipo.Enabled = !readOnly;
            txtModalDescripcion.ReadOnly = readOnly;
            txtModalPrecio.ReadOnly = readOnly;
            ddlModalEstado.Enabled = !readOnly;
            btnGuardarServicio.Visible = !readOnly;
        }

        protected string GetIconoPorTipo(string tipo)
        {
            if (string.IsNullOrEmpty(tipo)) return "fas fa-briefcase-medical";
            tipo = tipo.ToLower();
            if (tipo.Contains("consulta") || tipo.Contains("médico")) return "fas fa-stethoscope";
            if (tipo.Contains("baño") || tipo.Contains("grooming")) return "fas fa-bath";
            if (tipo.Contains("cirugía") || tipo.Contains("operación")) return "fas fa-cut";
            return "fas fa-briefcase-medical";
        }
        protected string GetColorPorTipo(string tipo)
        {
            if (string.IsNullOrEmpty(tipo)) return "icon-bg-default";
            tipo = tipo.ToLower();
            if (tipo.Contains("consulta") || tipo.Contains("médico")) return "icon-bg-consulta";
            if (tipo.Contains("baño") || tipo.Contains("grooming")) return "icon-bg-bano";
            if (tipo.Contains("cirugía") || tipo.Contains("operación")) return "icon-bg-cirugia";
            return "icon-bg-default";
        }

        protected void rptServicios_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var servicio = (SvcWS.servicioDto)e.Item.DataItem;
                LinkButton btnVer = (LinkButton)e.Item.FindControl("btnVer");
                LinkButton btnEditar = (LinkButton)e.Item.FindControl("btnEditar");
                LinkButton btnEliminar = (LinkButton)e.Item.FindControl("btnEliminar");

                if (btnVer != null) btnVer.CommandArgument = servicio.servicioId.ToString();
                if (btnEditar != null) btnEditar.CommandArgument = servicio.servicioId.ToString();
                if (btnEliminar != null) btnEliminar.CommandArgument = servicio.servicioId.ToString();
            }
        }
    }
}