﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
using ProductoWS = SoftPetBussiness.ProductoClient;
using TipoWS = SoftPetBussiness.TipoProductoClient;

namespace SoftPetWA
{
    public partial class Secretaria_Inventario : System.Web.UI.Page
    {
        private ProductoBO boProducto = new ProductoBO();
        private TipoProductoBO boTipoProducto = new TipoProductoBO();

        private const int PageSize = 7;

        public int CurrentPage
        {
            get { return (int)(ViewState["CurrentPage"] ?? 1); }
            set { ViewState["CurrentPage"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewState["FiltroTipoID"] = 0;
                CurrentPage = 1;
                CargarFiltrosDropDowns();
                CargarPaginaDatos();
            }
        }

        // =================================================================
        // MÉTODO DE HIDRATACIÓN (CRUCIAL PARA BÚSQUEDAS)
        // =================================================================
        private void HidratarListaProductos(List<ProductoWS.productoDto> listaProductos)
        {
            // 1. Obtener todos los tipos
            List<TipoWS.tipoProductoDto> listaTipos = boTipoProducto.ListarTodos();
            if (listaTipos == null) listaTipos = new List<TipoWS.tipoProductoDto>();

            // 2. Crear diccionario para cruce rápido
            var tiposDict = listaTipos.ToDictionary(t => t.tipoProductoId);

            // 3. Asignar objetos completos
            foreach (var prod in listaProductos)
            {
                if (prod.tipoProducto != null && tiposDict.ContainsKey(prod.tipoProducto.tipoProductoId))
                {
                    var tipoReal = tiposDict[prod.tipoProducto.tipoProductoId];

                    // Mapeo manual por diferencia de namespaces en Proxies
                    prod.tipoProducto = new ProductoWS.tipoProductoDto
                    {
                        tipoProductoId = tipoReal.tipoProductoId,
                        nombre = tipoReal.nombre,
                        descripcion = tipoReal.descripcion,
                        activo = tipoReal.activo
                    };
                }
                else
                {
                    prod.tipoProducto = new ProductoWS.tipoProductoDto { nombre = "Sin Tipo", descripcion = "" };
                }
            }
        }

        private void CargarPaginaDatos()
        {
            // Carga inicial: Todos
            List<ProductoWS.productoDto> listaMaestra = boProducto.ListarTodos();
            if (listaMaestra == null) listaMaestra = new List<ProductoWS.productoDto>();

            // Hidratar nombres de tipos
            HidratarListaProductos(listaMaestra);

            // Guardar en ViewState (para las pestañas de conteo principalmente)
            ViewState["ListaMaestraProductos"] = listaMaestra;

            // Actualizar contadores de pestañas
            CargarFiltrosPestanas(listaMaestra);

            // Renderizar
            EnlazarDatos();
        }

        private void CargarFiltrosDropDowns()
        {
            // Rango de Precios (Valores para el SP)
            DataTable dtRango = new DataTable();
            dtRango.Columns.Add("ID", typeof(string)); dtRango.Columns.Add("Txt", typeof(string));
            dtRango.Rows.Add("", "Todos");
            dtRango.Rows.Add("1", "S/ 0 - S/ 50");
            dtRango.Rows.Add("2", "S/ 51 - S/ 150");
            dtRango.Rows.Add("3", "S/ 151 a más");
            ddlRangoPrecio.DataSource = dtRango;
            ddlRangoPrecio.DataTextField = "Txt"; ddlRangoPrecio.DataValueField = "ID"; ddlRangoPrecio.DataBind();

            // Estado
            DataTable dtEstado = new DataTable();
            dtEstado.Columns.Add("Val", typeof(string)); dtEstado.Columns.Add("Txt", typeof(string));
            dtEstado.Rows.Add("", "Todos"); // Vacío para el SP
            dtEstado.Rows.Add("1", "Activo");
            dtEstado.Rows.Add("0", "Inactivo");
            ddlEstadoStock.DataSource = dtEstado;
            ddlEstadoStock.DataTextField = "Txt"; ddlEstadoStock.DataValueField = "Val"; ddlEstadoStock.DataBind();

            // Modal Tipos
            List<TipoWS.tipoProductoDto> tipos = boTipoProducto.ListarTodos();
            ddlModalTipo.DataSource = tipos.Where(t => t.activo == true).ToList();
            ddlModalTipo.DataTextField = "nombre"; ddlModalTipo.DataValueField = "tipoProductoId"; ddlModalTipo.DataBind();
            ddlModalTipo.Items.Insert(0, new ListItem("Seleccione...", "0"));
        }

        private void CargarFiltrosPestanas(List<ProductoWS.productoDto> productos)
        {
            var grupos = productos
                .GroupBy(p => new { p.tipoProducto.tipoProductoId, p.tipoProducto.nombre })
                .Select(g => new { TipoID = g.Key.tipoProductoId, Tipo = g.Key.nombre, Cantidad = g.Count() })
                .OrderBy(x => x.Tipo).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("Tipo", typeof(string)); dt.Columns.Add("TipoID", typeof(int)); dt.Columns.Add("Cantidad", typeof(int));
            dt.Rows.Add("Todos", 0, productos.Count);
            foreach (var g in grupos) dt.Rows.Add(g.Tipo, g.TipoID, g.Cantidad);

            rptFiltroTipo.DataSource = dt; rptFiltroTipo.DataBind();
        }

        // =================================================================
        // LÓGICA DE BÚSQUEDA AVANZADA CON EL BO
        // =================================================================
        private List<ProductoWS.productoDto> ObtenerListaFiltrada()
        {
            // 1. Obtener parámetros UI
            string nombre = txtNombreProducto.Text.Trim();
            string rango = ddlRangoPrecio.SelectedValue;
            string activo = ddlEstadoStock.SelectedValue;

            // 2. Llamar al Backend (Search en BD)
            List<ProductoWS.productoDto> lista = boProducto.ListarBusquedaAvanzada(nombre, rango, activo);
            if (lista == null) lista = new List<ProductoWS.productoDto>();

            // 3. Hidratar resultados (Poner nombres de tipos)
            HidratarListaProductos(lista);

            // 4. Filtrar por Pestaña (Tipo) en Memoria
            // Esto es necesario para que al dar clic en "Medicamentos", filtre sobre los resultados de la búsqueda
            int tipoIdFiltro = (int)(ViewState["FiltroTipoID"] ?? 0);
            if (tipoIdFiltro > 0)
            {
                lista = lista.Where(p => p.tipoProducto.tipoProductoId == tipoIdFiltro).ToList();
            }

            return lista;
        }

        private void EnlazarDatos()
        {
            var listaFiltrada = ObtenerListaFiltrada();

            litRegistrosTotales.Text = listaFiltrada.Count.ToString();
            int inicio = (CurrentPage - 1) * PageSize + 1;
            int fin = Math.Min(CurrentPage * PageSize, listaFiltrada.Count);
            if (fin == 0) inicio = 0;

            litRegistrosActuales.Text = $"{inicio}-{fin}";
            Literal1.Text = litRegistrosActuales.Text;
            Literal2.Text = litRegistrosTotales.Text;

            rptInventario.DataSource = listaFiltrada.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();
            rptInventario.DataBind();

            GenerarPaginado(listaFiltrada.Count);
        }

        private void GenerarPaginado(int totalRegistros)
        {
            int totalPages = (int)Math.Ceiling((double)totalRegistros / PageSize);
            lnkAnterior.Enabled = (CurrentPage > 1);
            lnkSiguiente.Enabled = (CurrentPage < totalPages);
            var paginas = new List<object>();
            if (totalRegistros > 0) for (int i = 1; i <= totalPages; i++) paginas.Add(new { Pagina = i, EsPaginaActual = (i == CurrentPage) });
            rptPaginador.DataSource = paginas; rptPaginador.DataBind();
        }

        // --- Eventos UI ---
        protected void btnBuscar_Click(object sender, EventArgs e) { CurrentPage = 1; EnlazarDatos(); }
        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombreProducto.Text = ""; ddlRangoPrecio.SelectedIndex = 0; ddlEstadoStock.SelectedIndex = 0;
            ViewState["FiltroTipoID"] = 0; CurrentPage = 1; CargarPaginaDatos(); // Reset total
        }
        protected void rptFiltroTipo_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            ViewState["FiltroTipoID"] = Convert.ToInt32(e.CommandArgument);
            CurrentPage = 1; EnlazarDatos();
        }
        protected void lnkPaginado_Click(object sender, EventArgs e) { string cmd = ((LinkButton)sender).CommandName; if (cmd == "Anterior" && CurrentPage > 1) CurrentPage--; else if (cmd == "Siguiente") CurrentPage++; EnlazarDatos(); }
        protected void rptPaginador_ItemCommand(object source, RepeaterCommandEventArgs e) { CurrentPage = Convert.ToInt32(e.CommandArgument); EnlazarDatos(); }

        // --- CRUD (Sin cambios lógicos, solo asegurando nombres correctos) ---
        protected void btnNuevoProducto_Click(object sender, EventArgs e)
        {
            hdProductoID.Value = "0"; txtModalNombre.Text = ""; ddlModalTipo.SelectedIndex = 0;
            txtModalPresentacion.Text = ""; txtModalPrecio.Text = ""; txtModalStock.Text = ""; ddlModalEstado.SelectedValue = "true";
            SetModalReadOnly(false); updModalProducto.Update();
            ScriptManager.RegisterStartupScript(this, GetType(), "ShowNew", "$('#modalProductoLabel').text('Registrar Nuevo Producto'); $('#modalProducto').modal('show');", true);
        }

        protected void rptInventario_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "Eliminar")
            {
                var p = boProducto.ObtenerPorId(id);
                if (p != null) { hdProductoIDEliminar.Value = id.ToString(); ScriptManager.RegisterStartupScript(this, GetType(), "ShowDel", $"$('#lblNombreProductoEliminar').text('{p.nombre}'); $('#modalConfirmarEliminar').modal('show');", true); }
            }
            else if (e.CommandName == "Ver" || e.CommandName == "Editar")
            {
                var p = boProducto.ObtenerPorId(id);
                if (p != null)
                {
                    hdProductoID.Value = p.productoId.ToString();
                    txtModalNombre.Text = p.nombre;
                    if (p.tipoProducto != null && ddlModalTipo.Items.FindByValue(p.tipoProducto.tipoProductoId.ToString()) != null) ddlModalTipo.SelectedValue = p.tipoProducto.tipoProductoId.ToString();
                    txtModalPresentacion.Text = p.presentacion; txtModalPrecio.Text = p.precioUnitario.ToString("0.00", CultureInfo.InvariantCulture); txtModalStock.Text = p.stock.ToString();
                    ddlModalEstado.SelectedValue = p.activo.ToString().ToLower();
                    bool esVer = e.CommandName == "Ver"; SetModalReadOnly(esVer); updModalProducto.Update();
                    string t = esVer ? "Detalles del Producto" : "Modificar Producto";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ShowModal", $"$('#modalProductoLabel').text('{t}'); $('#modalProducto').modal('show');", true);
                }
            }
        }

        protected void btnGuardarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(hdProductoID.Value); int tipoId = Convert.ToInt32(ddlModalTipo.SelectedValue); if (tipoId == 0) return;
                string nom = txtModalNombre.Text; string pres = txtModalPresentacion.Text;
                double precio = double.Parse(txtModalPrecio.Text, CultureInfo.InvariantCulture); int stock = int.Parse(txtModalStock.Text);
                bool act = bool.Parse(ddlModalEstado.SelectedValue);
                if (id == 0) boProducto.Insertar(tipoId, nom, pres, precio, stock, act); else boProducto.Modificar(id, tipoId, nom, pres, precio, stock, act);
                CargarPaginaDatos(); updPanelInventario.Update(); ScriptManager.RegisterStartupScript(this, GetType(), "HideM", "$('#modalProducto').modal('hide');", true);
            }
            catch { }
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            try { boProducto.Eliminar(Convert.ToInt32(hdProductoIDEliminar.Value)); CargarPaginaDatos(); updPanelInventario.Update(); ScriptManager.RegisterStartupScript(this, GetType(), "HideDel", "$('#modalConfirmarEliminar').modal('hide');", true); } catch { }
        }

        private void SetModalReadOnly(bool readOnly)
        {
            txtModalNombre.ReadOnly = readOnly; ddlModalTipo.Enabled = !readOnly; txtModalPresentacion.ReadOnly = readOnly;
            txtModalPrecio.ReadOnly = readOnly; txtModalStock.ReadOnly = readOnly; ddlModalEstado.Enabled = !readOnly;
            btnGuardarProducto.Visible = !readOnly;
        }

        // Helpers Visuales
        protected string GetTipoClasePorTipo(string tipo)
        {
            if (string.IsNullOrEmpty(tipo)) return "type-default";
            tipo = tipo.ToLower();
            if (tipo.Contains("medicamento")) return "type-medicamento";
            if (tipo.Contains("alimento")) return "type-alimento";
            if (tipo.Contains("accesorio")) return "type-accesorio";
            return "type-default";
        }
        protected string GetIconoPorTipo(string tipo)
        {
            if (string.IsNullOrEmpty(tipo)) return "fas fa-box";
            tipo = tipo.ToLower();
            if (tipo.Contains("medicamento")) return "fas fa-pills";
            if (tipo.Contains("alimento")) return "fas fa-bone";
            if (tipo.Contains("accesorio")) return "fas fa-tag";
            return "fas fa-box";
        }
        protected string GetColorPorTipo(string tipo)
        {
            if (string.IsNullOrEmpty(tipo)) return "icon-bg-default";
            tipo = tipo.ToLower();
            if (tipo.Contains("medicamento")) return "icon-bg-medicamento";
            if (tipo.Contains("alimento")) return "icon-bg-alimento";
            if (tipo.Contains("accesorio")) return "icon-bg-accesorio";
            return "icon-bg-default";
        }
    }
}