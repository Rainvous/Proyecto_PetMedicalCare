package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.servicios.DetalleServicioDto;

/**
 *
 * @author marti
 */
public interface DetalleServicioDao extends DaoBase<DetalleServicioDto> {
    
}
