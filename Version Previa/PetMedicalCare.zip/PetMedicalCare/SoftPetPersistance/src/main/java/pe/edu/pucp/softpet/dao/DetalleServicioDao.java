package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.servicios.DetalleServicioDto;

public interface DetalleServicioDao extends DaoBase<DetalleServicioDto> {
    
}
