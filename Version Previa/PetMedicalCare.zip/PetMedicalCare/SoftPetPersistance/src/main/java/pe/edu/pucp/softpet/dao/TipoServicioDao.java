package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.servicios.TipoServicioDto;

public interface TipoServicioDao extends DaoBase<TipoServicioDto> {
    
}
