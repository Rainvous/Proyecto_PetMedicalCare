package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.facturacion.DocumentoPagoDto;

/**
 *
 * @author marti
 */
public interface DocumentoDePagoDao extends DaoBase<DocumentoPagoDto> {

}
