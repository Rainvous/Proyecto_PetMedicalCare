package pe.edu.pucp.softpet.daoImp.util;

public enum MotorDeBaseDeDatos {
    MYSQL, MSSQL
}
