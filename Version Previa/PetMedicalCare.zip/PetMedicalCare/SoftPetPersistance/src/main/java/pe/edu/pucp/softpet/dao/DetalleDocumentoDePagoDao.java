package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.facturacion.DetalleDocumentoPagoDto;

public interface DetalleDocumentoDePagoDao extends DaoBase<DetalleDocumentoPagoDto> {
    
}
