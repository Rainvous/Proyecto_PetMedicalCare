package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.personas.VeterinarioDto;

public interface VeterinarioDao extends DaoBase<VeterinarioDto> {

}
