﻿// Nombre del archivo: Secretaria_AgendaCitas.aspx.cs (Actualizado)
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftPetWA
{
    public partial class Secretaria_AgendaCitas : System.Web.UI.Page
    {
        // Almacenará la fecha que se está visualizando
        private DateTime fechaSeleccionada
        {
            get
            {
                if (Session["AgendaFecha"] == null)
                {
                    Session["AgendaFecha"] = DateTime.Today;
                }
                return (DateTime)Session["AgendaFecha"];
            }
            set
            {
                Session["AgendaFecha"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // --- Carga de datos de prueba a la Sesión (Simula la BD) ---
                if (Session["CitasData"] == null)
                {
                    Session["CitasData"] = ObtenerCitasEjemplo();
                }
                if (Session["ClientesData"] == null)
                {
                    Session["ClientesData"] = ObtenerClientesParaDropdown();
                }
                if (Session["MascotasData"] == null)
                {
                    Session["MascotasData"] = ObtenerMascotasParaDropdown();
                }
                if (Session["VeterinariosData"] == null)
                {
                    Session["VeterinariosData"] = ObtenerVeterinariosParaDropdown();
                }
                if (Session["ServiciosData"] == null)
                {
                    Session["ServiciosData"] = ObtenerServiciosParaDropdown();
                }
                // --- Fin de carga de datos ---

                fechaSeleccionada = DateTime.Today; // Aseguramos que la fecha sea hoy

                CargarResumen();
                CargarFiltros();
                CargarAgenda(); // Carga la agenda (lista)
                ActualizarLabelsFecha();

                // Sincronizar el calendario
                calAgenda.SelectedDate = fechaSeleccionada;
                calAgenda.VisibleDate = fechaSeleccionada;

                // Sincronizar el TextBox de filtro
                txtFecha.Text = fechaSeleccionada.ToString("yyyy-MM-dd");
            }
        }

        #region "Carga de Datos y Filtros"

        private void CargarResumen()
        {
            DataTable dtCitas = Session["CitasData"] as DataTable;
            if (dtCitas == null) return;

            var citasHoy = dtCitas.AsEnumerable()
                           .Where(r => r.Field<DateTime>("Fecha").Date == DateTime.Today);

            lblCitasHoy.Text = citasHoy.Count().ToString();
            lblConfirmadas.Text = citasHoy.Count(r => r.Field<string>("Status") == "Confirmada").ToString();
            lblPendientes.Text = citasHoy.Count(r => r.Field<string>("Status") == "Pendiente").ToString();
            lblCanceladas.Text = citasHoy.Count(r => r.Field<string>("Status") == "Cancelada").ToString();
        }

        private void CargarFiltros()
        {
            // Cargar Veterinarios (del dropdown)
            ddlVeterinario.DataSource = Session["VeterinariosData"];
            ddlVeterinario.DataTextField = "Nombre";
            ddlVeterinario.DataValueField = "VeterinarioID";
            ddlVeterinario.DataBind();
            ddlVeterinario.Items.Insert(0, new ListItem("Todos", "0"));


            // Cargar Estados
            DataTable dtEstados = new DataTable();
            dtEstados.Columns.Add("EstadoID", typeof(string));
            dtEstados.Columns.Add("Nombre", typeof(string));
            dtEstados.Rows.Add("TODOS", "Todos");
            dtEstados.Rows.Add("Confirmada", "Confirmada");
            dtEstados.Rows.Add("Pendiente", "Pendiente");
            dtEstados.Rows.Add("Cancelada", "Cancelada");

            ddlEstado.DataSource = dtEstados;
            ddlEstado.DataTextField = "Nombre";
            ddlEstado.DataValueField = "EstadoID";
            ddlEstado.DataBind();
        }

        private void CargarAgenda()
        {
            DataTable dtTimeline = new DataTable();
            dtTimeline.Columns.Add("HoraLabel", typeof(string));
            dtTimeline.Columns.Add("HoraCita", typeof(string));
            dtTimeline.Columns.Add("Cliente", typeof(string));
            dtTimeline.Columns.Add("MascotaServicio", typeof(string));
            dtTimeline.Columns.Add("Status", typeof(string));
            dtTimeline.Columns.Add("CssClass", typeof(string));

            DataTable dtCitas = Session["CitasData"] as DataTable;
            if (dtCitas == null) return;

            // Filtrar citas por la fecha seleccionada
            var citasDelDia = dtCitas.AsEnumerable()
                                .Where(r => r.Field<DateTime>("Fecha").Date == fechaSeleccionada.Date)
                                .OrderBy(r => r.Field<TimeSpan>("Hora"))
                                .ToList();

            // Generar la línea de tiempo (slots de 1 hora de 8 AM a 6 PM)
            for (int hora = 8; hora <= 18; hora++)
            {
                string horaLabel = $"{hora:00}:00";

                // Buscar si hay una cita en esta franja horaria
                var citaEnHora = citasDelDia.FirstOrDefault(c => c.Field<TimeSpan>("Hora").Hours == hora);

                if (citaEnHora != null)
                {
                    string horaCita = citaEnHora.Field<TimeSpan>("Hora").ToString(@"hh\:mm") + " - " + citaEnHora.Field<TimeSpan>("Hora").Add(TimeSpan.FromMinutes(30)).ToString(@"hh\:mm");
                    string cssClass = "status-" + citaEnHora.Field<string>("Status").ToLower();

                    dtTimeline.Rows.Add(
                        horaLabel,
                        horaCita,
                        citaEnHora.Field<string>("ClienteNombre"),
                        $"{citaEnHora.Field<string>("MascotaNombre")} | {citaEnHora.Field<string>("ServicioNombre")}",
                        citaEnHora.Field<string>("Status"),
                        cssClass
                    );
                }
                else
                {
                    // Slot vacío
                    dtTimeline.Rows.Add(horaLabel, "", "", "", "", "");
                }
            }

            rptAgendaTimeline.DataSource = dtTimeline;
            rptAgendaTimeline.DataBind();
        }

        private void ActualizarLabelsFecha()
        {
            // Formatear la fecha, ej: "Martes, 11 de Noviembre 2025"
            CultureInfo ci = new CultureInfo("es-ES");
            lblFechaActual.Text = fechaSeleccionada.ToString("dddd, dd 'de' MMMM yyyy", ci);

            // Sincronizar controles
            txtFecha.Text = fechaSeleccionada.ToString("yyyy-MM-dd");
            calAgenda.SelectedDate = fechaSeleccionada;
            calAgenda.VisibleDate = fechaSeleccionada;
        }

        #endregion

        #region "Datos de Prueba (Simulación BD)"

        private DataTable ObtenerCitasEjemplo()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("CitaID", typeof(int));
            dt.Columns.Add("Fecha", typeof(DateTime));
            dt.Columns.Add("Hora", typeof(TimeSpan));
            dt.Columns.Add("ClienteID", typeof(int));
            dt.Columns.Add("ClienteNombre", typeof(string));
            dt.Columns.Add("MascotaID", typeof(int));
            dt.Columns.Add("MascotaNombre", typeof(string));
            dt.Columns.Add("VeterinarioID", typeof(int));
            dt.Columns.Add("VeterinarioNombre", typeof(string));
            dt.Columns.Add("ServicioID", typeof(int));
            dt.Columns.Add("ServicioNombre", typeof(string));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("Notas", typeof(string));

            // Citas para Hoy
            DateTime fechaHoy = DateTime.Today;

            dt.Rows.Add(1, fechaHoy, new TimeSpan(8, 0, 0), 1, "María González Pérez", 1, "Max (Golden)", 1, "Dr. García", 1, "Consulta General", "Confirmada", "");
            dt.Rows.Add(2, fechaHoy, new TimeSpan(9, 0, 0), 2, "Carlos Pérez Torres", 2, "Luna (Siames)", 1, "Dr. García", 2, "Vacunación", "Confirmada", "");
            dt.Rows.Add(3, fechaHoy, new TimeSpan(10, 0, 0), 3, "Ana Martínez López", 3, "Rocky (Labrador)", 2, "Dra. Martínez", 3, "Limpieza Dental", "Pendiente", "");
            dt.Rows.Add(4, fechaHoy, new TimeSpan(12, 0, 0), 4, "Juan Torres Ramírez", 4, "Toby (Beagle)", 1, "Dr. García", 4, "Control Postoperatorio", "Confirmada", "");
            dt.Rows.Add(5, fechaHoy, new TimeSpan(14, 0, 0), 5, "Laura Sánchez Díaz", 5, "Mia (Danes)", 2, "Dra. Martínez", 5, "Herida Leve", "Cancelada", "");

            // Citas para Mañana
            dt.Rows.Add(6, fechaHoy.AddDays(1), new TimeSpan(10, 0, 0), 1, "María González Pérez", 1, "Max (Golden)", 1, "Dr. García", 1, "Consulta General", "Pendiente", "");

            // Cita para ayer
            dt.Rows.Add(7, fechaHoy.AddDays(-1), new TimeSpan(11, 0, 0), 2, "Carlos Pérez Torres", 2, "Luna (Siames)", 1, "Dr. García", 2, "Vacunación", "Confirmada", "");


            return dt;
        }

        private DataTable ObtenerClientesParaDropdown()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ClienteID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Rows.Add(1, "María González Pérez");
            dt.Rows.Add(2, "Carlos Pérez Torres");
            dt.Rows.Add(3, "Ana Martínez López");
            dt.Rows.Add(4, "Juan Torres Ramírez");
            dt.Rows.Add(5, "Laura Sánchez Díaz");
            return dt;
        }

        private DataTable ObtenerMascotasParaDropdown()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MascotaID", typeof(int));
            dt.Columns.Add("ClienteID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Rows.Add(1, 1, "Max (Golden)");
            dt.Rows.Add(2, 2, "Luna (Siames)");
            dt.Rows.Add(3, 3, "Rocky (Labrador)");
            dt.Rows.Add(4, 4, "Toby (Beagle)");
            dt.Rows.Add(5, 5, "Mia (Danes)");
            return dt;
        }

        private DataTable ObtenerVeterinariosParaDropdown()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("VeterinarioID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Rows.Add(1, "Dr. García López");
            dt.Rows.Add(2, "Dra. Martínez Ruiz");
            return dt;
        }

        private DataTable ObtenerServiciosParaDropdown()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ServicioID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Rows.Add(1, "Consulta General");
            dt.Rows.Add(2, "Vacunación");
            dt.Rows.Add(3, "Limpieza Dental");
            dt.Rows.Add(4, "Control Postoperatorio");
            dt.Rows.Add(5, "Herida Leve");
            return dt;
        }

        #endregion

        #region "Eventos de Botones"

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            // Lógica de búsqueda iría aquí
            // Por ahora, solo recargamos la agenda con la fecha seleccionada
            if (!string.IsNullOrEmpty(txtFecha.Text))
            {
                fechaSeleccionada = DateTime.Parse(txtFecha.Text);
            }
            CargarAgenda();
            ActualizarLabelsFecha();
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtClienteMascota.Text = "";
            ddlVeterinario.SelectedIndex = 0;
            ddlEstado.SelectedIndex = 0;
            fechaSeleccionada = DateTime.Today;

            CargarAgenda();
            ActualizarLabelsFecha();
        }

        // --- Eventos de Cambio de Vista ---
        protected void btnVistaCalendario_Click(object sender, EventArgs e)
        {
            pnlVistaLista.Visible = false;
            pnlVistaCalendario.Visible = true;
            btnVistaCalendario.CssClass = "btn btn-secondary me-2";
            btnVistaLista.CssClass = "btn btn-outline-secondary";
        }

        protected void btnVistaLista_Click(object sender, EventArgs e)
        {
            pnlVistaLista.Visible = true;
            pnlVistaCalendario.Visible = false;
            btnVistaCalendario.CssClass = "btn btn-outline-secondary me-2";
            btnVistaLista.CssClass = "btn btn-secondary";
        }

        // --- Eventos de Navegación de Fecha ---
        protected void lnkAnterior_Click(object sender, EventArgs e)
        {
            fechaSeleccionada = fechaSeleccionada.AddDays(-1);
            CargarAgenda();
            ActualizarLabelsFecha();
        }

        protected void lnkSiguiente_Click(object sender, EventArgs e)
        {
            fechaSeleccionada = fechaSeleccionada.AddDays(1);
            CargarAgenda();
            ActualizarLabelsFecha();
        }

        protected void btnHoy_Click(object sender, EventArgs e)
        {
            fechaSeleccionada = DateTime.Today;
            CargarAgenda();
            ActualizarLabelsFecha();
        }

        protected void txtFecha_TextChanged(object sender, EventArgs e)
        {
            try
            {
                fechaSeleccionada = DateTime.Parse(txtFecha.Text);
                CargarAgenda();
                ActualizarLabelsFecha();
            }
            catch (Exception)
            {
                // Si la fecha es inválida, volver a hoy
                fechaSeleccionada = DateTime.Today;
                ActualizarLabelsFecha();
            }
        }

        // --- Eventos del Calendario ---
        protected void calAgenda_SelectionChanged(object sender, EventArgs e)
        {
            fechaSeleccionada = calAgenda.SelectedDate;
            CargarAgenda();
            ActualizarLabelsFecha();

            // Opcional: cambiar a la vista de lista al seleccionar un día
            btnVistaLista_Click(sender, e);
        }

        protected void calAgenda_DayRender(object sender, DayRenderEventArgs e)
        {
            // Marcar días con citas (ejemplo)
            DataTable dtCitas = Session["CitasData"] as DataTable;
            if (dtCitas == null) return;

            var citasEnFecha = dtCitas.AsEnumerable()
                                .Count(r => r.Field<DateTime>("Fecha").Date == e.Day.Date);

            if (citasEnFecha > 0)
            {
                // Añadimos el "punto" (dot) con el número de citas
                e.Cell.Controls.Add(new LiteralControl($"<span class='cal-dot'>{citasEnFecha}</span>"));
            }
        }

        // --- Eventos del Modal de Nueva Cita ---
        protected void btnNuevaCita_Click(object sender, EventArgs e)
        {
            // 1. Cargar los DropDownLists del Modal
            ddlModalCliente.DataSource = Session["ClientesData"];
            ddlModalCliente.DataTextField = "Nombre";
            ddlModalCliente.DataValueField = "ClienteID";
            ddlModalCliente.DataBind();
            ddlModalCliente.Items.Insert(0, new ListItem("-- Seleccione Cliente --", "0"));

            ddlModalMascota.DataSource = Session["MascotasData"]; // (Idealmente filtrar por cliente)
            ddlModalMascota.DataTextField = "Nombre";
            ddlModalMascota.DataValueField = "MascotaID";
            ddlModalMascota.DataBind();
            ddlModalMascota.Items.Insert(0, new ListItem("-- Seleccione Mascota --", "0"));

            ddlModalVeterinario.DataSource = Session["VeterinariosData"];
            ddlModalVeterinario.DataTextField = "Nombre";
            ddlModalVeterinario.DataValueField = "VeterinarioID";
            ddlModalVeterinario.DataBind();
            ddlModalVeterinario.Items.Insert(0, new ListItem("-- Seleccione Veterinario --", "0"));

            ddlModalServicio.DataSource = Session["ServiciosData"];
            ddlModalServicio.DataTextField = "Nombre";
            ddlModalServicio.DataValueField = "ServicioID";
            ddlModalServicio.DataBind();
            ddlModalServicio.Items.Insert(0, new ListItem("-- Seleccione Servicio --", "0"));

            // 2. Poner la fecha y hora por defecto
            txtModalFecha.Text = fechaSeleccionada.ToString("yyyy-MM-dd");
            txtModalHora.Text = DateTime.Now.ToString("HH:mm");
            ddlModalEstado.SelectedValue = "Pendiente";
            txtModalNotas.Text = "";
            hdCitaID.Value = "0"; // Asegurar que es "nuevo"

            // 3. Actualizar el contenido del modal y abrirlo
            updModalCita.Update();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showModalNuevaCita", "$('#modalNuevaCita').modal('show');", true);
        }

        protected void btnGuardarCita_Click(object sender, EventArgs e)
        {
            DataTable dtCitas = Session["CitasData"] as DataTable;
            if (dtCitas == null) return;

            try
            {
                int citaID = Convert.ToInt32(hdCitaID.Value);

                // Recolectar datos del modal
                DateTime fecha = DateTime.Parse(txtModalFecha.Text);
                TimeSpan hora = TimeSpan.Parse(txtModalHora.Text);
                string estado = ddlModalEstado.SelectedValue;
                string notas = txtModalNotas.Text;

                // Obtener datos de los dropdowns
                int clienteID = int.Parse(ddlModalCliente.SelectedValue);
                string clienteNombre = ddlModalCliente.SelectedItem.Text;
                int mascotaID = int.Parse(ddlModalMascota.SelectedValue);
                string mascotaNombre = ddlModalMascota.SelectedItem.Text;
                int vetID = int.Parse(ddlModalVeterinario.SelectedValue);
                string vetNombre = ddlModalVeterinario.SelectedItem.Text;
                int servicioID = int.Parse(ddlModalServicio.SelectedValue);
                string servicioNombre = ddlModalServicio.SelectedItem.Text;

                if (citaID == 0)
                {
                    // --- CREAR NUEVA CITA ---
                    int newID = dtCitas.Rows.Count > 0 ? dtCitas.AsEnumerable().Max(row => row.Field<int>("CitaID")) + 1 : 1;

                    dtCitas.Rows.Add(
                        newID, fecha, hora,
                        clienteID, clienteNombre,
                        mascotaID, mascotaNombre,
                        vetID, vetNombre,
                        servicioID, servicioNombre,
                        estado, notas
                    );
                }
                else
                {
                    // --- EDITAR CITA EXISTENTE (Lógica no implementada aún, pero preparada) ---
                    DataRow row = dtCitas.AsEnumerable().FirstOrDefault(r => r.Field<int>("CitaID") == citaID);
                    if (row != null)
                    {
                        // ... actualizar campos ...
                    }
                }

                Session["CitasData"] = dtCitas;

                // Si la cita guardada es para la fecha que se está viendo, actualizar la agenda
                if (fecha.Date == fechaSeleccionada.Date)
                {
                    CargarAgenda();
                }

                CargarResumen(); // Actualizar contadores superiores
                updAgenda.Update(); // Actualiza la agenda principal
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.Write(ex.Message);
            }
        }

        #endregion
    }
}