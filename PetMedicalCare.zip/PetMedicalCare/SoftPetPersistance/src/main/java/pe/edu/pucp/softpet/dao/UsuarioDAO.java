package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.usuarios.UsuarioDto;

/**
 *
 * @author marti
 */
public interface UsuarioDAO extends DaoBase<UsuarioDto> {

}
