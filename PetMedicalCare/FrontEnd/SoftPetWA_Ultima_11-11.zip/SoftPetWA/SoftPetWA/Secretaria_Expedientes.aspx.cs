﻿// Nombre del archivo: Secretaria_Expedientes.aspx.cs (Reestructurado como LISTA)
using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftPetWA
{
    public partial class Secretaria_Expedientes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Cargar datos de prueba a la Sesión (Simula la BD)
                if (Session["ExpedientesListaData"] == null)
                {
                    Session["ExpedientesListaData"] = ObtenerExpedientesListaEjemplo();
                }

                CargarFiltros();
                CargarExpedientesLista();
            }
        }

        #region "Carga de Lista Principal y Filtros"

        private void CargarFiltros()
        {
            // Cargar Tipos (Especie)
            DataTable dtTipo = new DataTable();
            dtTipo.Columns.Add("TipoID", typeof(int));
            dtTipo.Columns.Add("Nombre", typeof(string));
            dtTipo.Rows.Add(0, "Todos");
            dtTipo.Rows.Add(1, "Perro");
            dtTipo.Rows.Add(2, "Gato");

            ddlTipo.DataSource = dtTipo;
            ddlTipo.DataTextField = "Nombre";
            ddlTipo.DataValueField = "TipoID";
            ddlTipo.DataBind();
        }

        private void CargarExpedientesLista()
        {
            DataTable dt = Session["ExpedientesListaData"] as DataTable;
            if (dt == null) return;

            // Lógica de Filtro (ejemplo)
            var query = dt.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                string filtroNombre = txtNombre.Text.ToLower();
                query = query.Where(r => r.Field<string>("MascotaNombre").ToLower().Contains(filtroNombre) ||
                                         r.Field<string>("PropietarioNombre").ToLower().Contains(filtroNombre));
            }
            if (!string.IsNullOrWhiteSpace(txtDocumento.Text))
            {
                query = query.Where(r => r.Field<string>("Documento").Contains(txtDocumento.Text));
            }

            DataTable dtFiltrada = dt.Clone();
            if (query.Any())
            {
                dtFiltrada = query.CopyToDataTable();
            }

            rptExpedientesLista.DataSource = dtFiltrada;
            rptExpedientesLista.DataBind();

            litRegistrosTotales.Text = dt.Rows.Count.ToString();
            litRegistrosActuales.Text = $"1-{dtFiltrada.Rows.Count}";
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarExpedientesLista();
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtDocumento.Text = "";
            txtTelefono.Text = "";
            ddlTipo.SelectedIndex = 0;
            CargarExpedientesLista();
        }

        #endregion

        #region "Datos de Prueba (Simulación BD)"

        private DataTable ObtenerExpedientesListaEjemplo()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MascotaID", typeof(int));
            dt.Columns.Add("MascotaNombre", typeof(string));
            dt.Columns.Add("Especie", typeof(string));
            dt.Columns.Add("EspecieRaza", typeof(string));
            dt.Columns.Add("AvatarCss", typeof(string));
            dt.Columns.Add("AvatarIcon", typeof(string));
            dt.Columns.Add("PropietarioNombre", typeof(string));
            dt.Columns.Add("Documento", typeof(string));
            dt.Columns.Add("Telefono", typeof(string));
            dt.Columns.Add("Email", typeof(string));
            dt.Columns.Add("UltimaVisita", typeof(DateTime));
            // Info de Mascota para el modal
            dt.Columns.Add("Edad", typeof(string));
            dt.Columns.Add("Sexo", typeof(string));
            dt.Columns.Add("Color", typeof(string));
            dt.Columns.Add("Peso", typeof(string));
            dt.Columns.Add("Estado", typeof(string));


            dt.Rows.Add(1, "Max", "Perro", "Golden Retriever", "avatar-perro", "fas fa-dog", "María González Pérez", "72458963", "987 654 321", "maria.gonzalez@email.com", new DateTime(2024, 10, 6), "3 años", "Macho", "Dorado", "32.5 kg", "Activo");
            dt.Rows.Add(2, "Luna", "Gato", "Siamés", "avatar-gato", "fas fa-cat", "Carlos Pérez Torres", "45789632", "956 321 478", "carlos.perez@email.com", new DateTime(2024, 9, 15), "2 años", "Hembra", "Blanco", "4.5 kg", "Activo");
            dt.Rows.Add(3, "Rocky", "Perro", "Bulldog", "avatar-perro", "fas fa-dog", "Ana Martínez López", "65478932", "912 345 678", "ana.martinez@email.com", new DateTime(2024, 10, 1), "5 años", "Macho", "Marrón", "28.0 kg", "Activo");

            return dt;
        }

        #endregion
    }
}