package pe.edu.pucp.softpet.util;

public enum MotorDeBaseDeDatos {
    MYSQL, MSSQL
}
