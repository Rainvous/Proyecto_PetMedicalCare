package pe.edu.pucp.softpet.dto.util.enums;

public enum Sexo {
    M,
    F,
    O
}
