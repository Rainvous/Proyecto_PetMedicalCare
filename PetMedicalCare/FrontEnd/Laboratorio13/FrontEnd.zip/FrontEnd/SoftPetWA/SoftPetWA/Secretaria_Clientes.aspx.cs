﻿using SoftPetBusiness;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient;
using SoftPetBussiness.UsuarioClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
// Alias para evitar conflictos de nombres
using usuarioDto = SoftPetBussiness.UsuarioClient.usuarioDto;

namespace SoftPetWA
{
    public partial class Secretaria_Clientes : System.Web.UI.Page
    {
        private PersonaBO personaBo;
        private UsuarioBO usuarioBo;
        private MascotaBO mascotaBo;
        private RolUsuarioBO rolUsuarioBo; // BO para asignar roles

        // Constante del ID de Rol CLIENTE según tu BD
        private const int ID_ROL_CLIENTE = 4;

        // Configuración de Paginación
        private const int PageSize = 7;
        public int CurrentPage
        {
            get { return (int)(ViewState["CurrentPage"] ?? 1); }
            set { ViewState["CurrentPage"] = value; }
        }

        // ViewModel
        private class ClienteViewModel
        {
            public int PersonaID { get; set; }
            public string Nombre { get; set; }
            public string Email { get; set; }
            public string Iniciales { get; set; }
            public string AvatarColor { get; set; }
            public string TipoDocumento { get; set; }
            public string NumDocumento { get; set; }
            public string RUC { get; set; }
            public string Telefono { get; set; }
            public int NumMascotas { get; set; }
            public string TextoMascotas { get; set; }
            public string Estado { get; set; }
            public string Direccion { get; set; }
            public string Sexo { get; set; }
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            this.personaBo = new PersonaBO();
            this.usuarioBo = new UsuarioBO();
            this.mascotaBo = new MascotaBO();
            this.rolUsuarioBo = new RolUsuarioBO(); // Inicializar
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CurrentPage = 1;
                CargarFiltros();
                CargarClientes(null, null, null, null);
            }
        }

        private void CargarFiltros()
        {
            DataTable dtDoc = new DataTable();
            dtDoc.Columns.Add("Tipo", typeof(string));
            dtDoc.Rows.Add("DNI"); dtDoc.Rows.Add("CE"); dtDoc.Rows.Add("RUC");

            ddlDocumento.DataSource = dtDoc; ddlDocumento.DataTextField = "Tipo"; ddlDocumento.DataValueField = "Tipo"; ddlDocumento.DataBind();
            ddlModalTipoDoc.DataSource = dtDoc; ddlModalTipoDoc.DataTextField = "Tipo"; ddlModalTipoDoc.DataValueField = "Tipo"; ddlModalTipoDoc.DataBind();
        }

        private void CargarClientes(string nombre, string numDoc, string ruc, string telefono)
        {
            IList<SoftPetBussiness.PersonaClient.personaDto> listaPersonas;
            bool esBusqueda = !string.IsNullOrWhiteSpace(nombre) || !string.IsNullOrWhiteSpace(numDoc) || !string.IsNullOrWhiteSpace(ruc) || !string.IsNullOrWhiteSpace(telefono);

            nombre = nombre == null ? "" : nombre.Trim();
            numDoc = numDoc == null ? "" : numDoc.Trim();
            ruc = ruc == null ? "" : ruc.Trim();
            telefono = telefono == null ? "" : telefono.Trim();

            // El SP del backend 'sp_listar_solo_clientes' filtra por rol automáticamente
            // por lo que ya no necesitamos filtrar manualmente en C# si asignamos bien el rol.
            if (!esBusqueda) listaPersonas = personaBo.ListarSoloClientes();
            else listaPersonas = this.personaBo.ListarPorNombreNroDocumentoRucTelefono(nombre, numDoc, ruc, telefono, true);

            if (listaPersonas == null) listaPersonas = new List<SoftPetBussiness.PersonaClient.personaDto>();

            IList<mascotaDto> listaMascotas = mascotaBo.ListarTodos();
            IList<usuarioDto> listaUsuarios = usuarioBo.ListarTodos();
            if (listaMascotas == null) listaMascotas = new List<mascotaDto>();
            if (listaUsuarios == null) listaUsuarios = new List<usuarioDto>();

            var bindingList = listaPersonas.Select(p =>
            {
                int count = listaMascotas.Count(m => m.persona.personaId == p.personaId && m.activo);
                var usuarioReal = listaUsuarios.FirstOrDefault(u => u.usuarioId == p.usuario.usuarioId);
                string correoMostrar = (usuarioReal != null) ? usuarioReal.correo : "Sin Email";

                return new ClienteViewModel
                {
                    PersonaID = p.personaId,
                    Nombre = p.nombre,
                    Email = correoMostrar,
                    Iniciales = ObternerIniciales(p.nombre),
                    AvatarColor = GetAvatarColor(p.personaId),
                    TipoDocumento = p.tipoDocumento,
                    NumDocumento = p.nroDocumento.ToString(),
                    RUC = (p.ruc == 0 || p.ruc == null) ? "RUC: -" : $"RUC: {p.ruc}",
                    Telefono = p.telefono,
                    NumMascotas = count,
                    TextoMascotas = count == 1 ? "1 mascota" : $"{count} mascotas",
                    Estado = p.activo ? "Activo" : "Inactivo",
                    Direccion = p.direccion,
                    Sexo = p.sexo.ToString()
                };
            }).ToList();

            var query = bindingList.AsEnumerable();
            if (!string.IsNullOrWhiteSpace(nombre)) query = query.Where(v => v.Nombre.ToLower().Contains(nombre.ToLower()));
            if (!string.IsNullOrWhiteSpace(numDoc)) query = query.Where(v => v.NumDocumento.Contains(numDoc));
            if (!string.IsNullOrWhiteSpace(ruc))
            {
                string rucLimpio = ruc.Replace("RUC: ", "").Trim();
                if (!string.IsNullOrEmpty(rucLimpio)) query = query.Where(v => v.RUC.Contains(rucLimpio));
            }
            if (!string.IsNullOrWhiteSpace(telefono)) query = query.Where(v => v.Telefono.Contains(telefono));

            var filteredList = query.ToList();
            int totalRegistros = filteredList.Count;
            int inicio = (CurrentPage - 1) * PageSize + 1;
            int fin = Math.Min(CurrentPage * PageSize, totalRegistros);
            if (fin == 0) inicio = 0;

            litRegistrosTotales.Text = totalRegistros.ToString();
            litRegistrosActuales.Text = $"{inicio}-{fin}";

            rptClientes.DataSource = filteredList.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();
            rptClientes.DataBind();
            GenerarPaginado(totalRegistros);
        }

        private void GenerarPaginado(int totalRegistros)
        {
            int totalPages = (int)Math.Ceiling((double)totalRegistros / PageSize);
            lnkAnterior.Enabled = (CurrentPage > 1);
            lnkSiguiente.Enabled = (CurrentPage < totalPages);
            lnkAnterior.CssClass = lnkAnterior.Enabled ? "page-link" : "page-link disabled";
            lnkSiguiente.CssClass = lnkSiguiente.Enabled ? "page-link" : "page-link disabled";

            var paginas = new List<object>();
            if (totalPages > 1) for (int i = 1; i <= totalPages; i++) paginas.Add(new { Pagina = i, EsPaginaActual = (i == CurrentPage) });
            rptPaginador.DataSource = paginas; rptPaginador.DataBind();
        }

        // Eventos UI
        protected void lnkPaginado_Click(object sender, EventArgs e) { string cmd = ((LinkButton)sender).CommandName; if (cmd == "Anterior" && CurrentPage > 1) CurrentPage--; else if (cmd == "Siguiente") CurrentPage++; CargarClientes(txtNombre.Text, txtDocumento.Text, txtRUC.Text, txtTelefono.Text); }
        protected void rptPaginador_ItemCommand(object source, RepeaterCommandEventArgs e) { if (e.CommandName == "IrPagina") { CurrentPage = Convert.ToInt32(e.CommandArgument); CargarClientes(txtNombre.Text, txtDocumento.Text, txtRUC.Text, txtTelefono.Text); } }
        protected void btnBuscar_Click(object sender, EventArgs e) { CurrentPage = 1; CargarClientes(txtNombre.Text, txtDocumento.Text, txtRUC.Text, txtTelefono.Text); }
        protected void btnLimpiar_Click(object sender, EventArgs e) { txtNombre.Text = ""; txtDocumento.Text = ""; txtTelefono.Text = ""; txtRUC.Text = ""; ddlDocumento.SelectedIndex = 0; CurrentPage = 1; CargarClientes(null, null, null, null); }

        // Helpers
        private string ObternerIniciales(string nombre) { if (string.IsNullOrEmpty(nombre)) return "??"; var partes = nombre.Trim().Split(' '); if (partes.Length == 1 && partes[0].Length > 0) return partes[0].Substring(0, Math.Min(2, partes[0].Length)).ToUpper(); if (partes.Length > 1) return (partes[0][0].ToString() + partes.Last()[0].ToString()).ToUpper(); return "??"; }
        private string GetAvatarColor(int id) { string[] colors = { "#007bff", "#28a745", "#ffc107", "#dc3545", "#17a2b8", "#6c757d" }; return colors[Math.Abs(id) % colors.Length]; }

        protected void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            hdClienteID.Value = "0";
            txtModalNombre.Text = ""; txtModalEmail.Text = ""; txtModalUsario.Text = "";
            txtModalPassword.Text = ""; txtModalPassword.Attributes.Remove("value");
            txtModalRol.Text = "Cliente";
            txtModalTelefono.Text = ""; ddlModalTipoDoc.SelectedValue = "DNI";
            txtModalNumDoc.Text = ""; txtModalRUC.Text = ""; txtModalDireccion.Text = "";
            ddlModalSexo.SelectedValue = "O"; ddlModalEstado.SelectedValue = "Activo";
            litModalError.Text = "";
            SetModalReadOnly(false);
            updModalCliente.Update();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowNew", "$('#modalClienteLabel').text('Registrar Nuevo Cliente'); $('#modalCliente').modal('show');", true);
        }

        protected void btnGuardarCliente_Click(object sender, EventArgs e)
        {
            litModalError.Text = "";
            // Variables para rollback
            int idUsuarioCreado = 0;
            int idRolUsuarioCreado = 0;
            int idPersonaCreada = 0;

            try
            {
                // Validaciones...
                if (string.IsNullOrWhiteSpace(txtModalNombre.Text) || string.IsNullOrWhiteSpace(txtModalEmail.Text) || string.IsNullOrWhiteSpace(txtModalNumDoc.Text))
                { litModalError.Text = "<div class='alert alert-danger'>Campos obligatorios vacíos.</div>"; updModalCliente.Update(); return; }
                int nroDocumento; if (!int.TryParse(txtModalNumDoc.Text, out nroDocumento)) { litModalError.Text = "<div class='alert alert-danger'>DNI numérico inválido.</div>"; updModalCliente.Update(); return; }
                int ruc = 0; if (!string.IsNullOrWhiteSpace(txtModalRUC.Text)) int.TryParse(txtModalRUC.Text, out ruc);

                int personaID = Convert.ToInt32(hdClienteID.Value);
                string nombre = txtModalNombre.Text; string usuario = txtModalUsario.Text; string email = txtModalEmail.Text;
                string telefono = txtModalTelefono.Text; string tipoDoc = ddlModalTipoDoc.SelectedValue;
                string direccion = txtModalDireccion.Text; string sexo = ddlModalSexo.SelectedValue;
                bool esActivo = ddlModalEstado.SelectedValue == "Activo"; string passwordInput = txtModalPassword.Text;

                if (personaID == 0)
                {   // INSERTAR
                    if (string.IsNullOrWhiteSpace(passwordInput)) { litModalError.Text = "<div class='alert alert-danger'>Contraseña obligatoria.</div>"; updModalCliente.Update(); return; }

                    // 1. Crear Usuario
                    idUsuarioCreado = usuarioBo.Insertar(usuario, passwordInput, email, esActivo);
                    if (idUsuarioCreado <= 0) { litModalError.Text = "<div class='alert alert-danger'>Error al crear el Usuario.</div>"; updModalCliente.Update(); return; }

                    // 2. ASIGNAR ROL (Cliente = 4)
                    // Esto es crucial para que el SP de listar clientes lo incluya y el de filtrar empleados lo excluya
                    idRolUsuarioCreado = rolUsuarioBo.Insertar(ID_ROL_CLIENTE, idUsuarioCreado, true);
                    if (idRolUsuarioCreado <= 0)
                    {
                        usuarioBo.Eliminar(idUsuarioCreado); // Rollback Usuario
                        litModalError.Text = "<div class='alert alert-danger'>Error al asignar Rol.</div>"; updModalCliente.Update(); return;
                    }

                    // 3. Crear Persona
                    idPersonaCreada = personaBo.Insertar(idUsuarioCreado, nombre, direccion, telefono, sexo, nroDocumento, ruc, tipoDoc, esActivo);

                    if (idPersonaCreada > 0)
                    {
                        litModalError.Text = "<div class='alert alert-success'>Cliente creado.</div>";
                        Response.Redirect("Secretaria_Clientes.aspx");
                    }
                    else
                    {
                        // Rollback Completo
                        rolUsuarioBo.Eliminar(idRolUsuarioCreado);
                        usuarioBo.Eliminar(idUsuarioCreado);
                        litModalError.Text = "<div class='alert alert-danger'>Error al crear la Persona.</div>";
                    }
                }
                else
                {   // MODIFICAR
                    SoftPetBussiness.PersonaClient.personaDto persona = personaBo.ObtenerPorId(personaID);
                    int usuarioID = persona.usuario.usuarioId;
                    usuarioDto usuarioActual = usuarioBo.ObtenerPorId(usuarioID);
                    string passwordFinal = usuarioActual.password;
                    if (!string.IsNullOrEmpty(passwordInput) && passwordInput != "**********") passwordFinal = passwordInput;

                    usuarioBo.Modificar(usuarioID, usuario, passwordFinal, email, esActivo);
                    personaBo.Modificar(personaID, usuarioID, nombre, direccion, telefono, sexo, nroDocumento, ruc, tipoDoc, esActivo);

                    litModalError.Text = "<div class='alert alert-success'>Modificado exitosamente.</div>";
                    Response.Redirect("Secretaria_Clientes.aspx");
                }
            }
            catch (Exception ex)
            {
                // Rollback de emergencia
                if (idRolUsuarioCreado > 0) rolUsuarioBo.Eliminar(idRolUsuarioCreado);
                if (idUsuarioCreado > 0) usuarioBo.Eliminar(idUsuarioCreado);
                litModalError.Text = $"<div class='alert alert-danger'>Error: {ex.Message}</div>";
            }
            updModalCliente.Update();
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                int personaID = Convert.ToInt32(hdClienteIDEliminar.Value);
                SoftPetBussiness.PersonaClient.personaDto persona = personaBo.ObtenerPorId(personaID);
                if (persona != null)
                {
                    int usuarioID = persona.usuario.usuarioId;
                    personaBo.Eliminar(personaID);
                    usuarioBo.Eliminar(usuarioID); // Desactivar usuario bloquea acceso
                    CargarClientes(null, null, null, null); updPanelClientes.Update();
                }
            }
            catch (Exception ex) { ScriptManager.RegisterStartupScript(this, this.GetType(), "Error", $"alert('{ex.Message}');", true); }
        }

        protected void rptClientes_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int personaID = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "VerMascotas") { ScriptManager.RegisterStartupScript(this, this.GetType(), "showM", "$('#modalMascotas').modal('show');", true); }
            else if (e.CommandName == "Ver" || e.CommandName == "Editar")
            {
                try
                {
                    SoftPetBussiness.PersonaClient.personaDto p = personaBo.ObtenerPorId(personaID);
                    usuarioDto u = usuarioBo.ObtenerPorId(p.usuario.usuarioId);
                    if (p != null)
                    {
                        hdClienteID.Value = p.personaId.ToString();
                        txtModalNombre.Text = p.nombre; txtModalEmail.Text = (u != null) ? u.correo : "";
                        txtModalUsario.Text = (u != null) ? u.username : "";
                        txtModalPassword.Attributes.Add("value", "**********"); txtModalPassword.Text = "**********";
                        txtModalRol.Text = "Cliente"; txtModalTelefono.Text = p.telefono;
                        ddlModalTipoDoc.SelectedValue = p.tipoDocumento; txtModalNumDoc.Text = p.nroDocumento.ToString();
                        txtModalRUC.Text = (p.ruc == 0) ? "" : p.ruc.ToString(); txtModalDireccion.Text = p.direccion;
                        ddlModalSexo.SelectedValue = p.sexo.ToString(); ddlModalEstado.SelectedValue = p.activo ? "Activo" : "Inactivo";
                        litModalError.Text = "";
                        bool esSoloLectura = (e.CommandName == "Ver");
                        SetModalReadOnly(esSoloLectura);
                        updModalCliente.Update();
                        string t = esSoloLectura ? "Ver Detalles" : "Modificar Cliente";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowModal", $"$('#modalClienteLabel').text('{t}'); $('#modalCliente').modal('show');", true);
                    }
                }
                catch { }
            }
        }

        private void SetModalReadOnly(bool readOnly)
        {
            txtModalNombre.ReadOnly = readOnly; txtModalEmail.ReadOnly = readOnly; txtModalUsario.ReadOnly = readOnly;
            txtModalPassword.ReadOnly = readOnly; txtModalRol.ReadOnly = true; // Rol siempre readonly
            txtModalTelefono.ReadOnly = readOnly; ddlModalTipoDoc.Enabled = !readOnly; txtModalNumDoc.ReadOnly = readOnly;
            txtModalRUC.ReadOnly = readOnly; txtModalDireccion.ReadOnly = readOnly; ddlModalSexo.Enabled = !readOnly;
            ddlModalEstado.Enabled = !readOnly; btnGuardarCliente.Visible = !readOnly;
        }
    }
}