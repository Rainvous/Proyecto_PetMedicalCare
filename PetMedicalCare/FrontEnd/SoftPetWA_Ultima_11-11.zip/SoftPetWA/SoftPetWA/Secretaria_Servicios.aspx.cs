﻿// Nombre del archivo: Secretaria_Servicios.aspx.cs (Actualizado)
using System;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftPetWA
{
    public partial class Secretaria_Servicios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Almacenamos los datos de prueba en la Sesión
                Session["ServiciosData"] = ObtenerServiciosEjemplo();

                CargarFiltros();
                CargarServicios();
            }
        }

        private void CargarFiltros()
        {
            // Cargar Pestañas de Filtro (ejemplo)
            DataTable dtTipos = new DataTable();
            dtTipos.Columns.Add("Tipo", typeof(string));
            dtTipos.Columns.Add("Cantidad", typeof(int));
            dtTipos.Rows.Add("Todos", 18);
            dtTipos.Rows.Add("Servicios Médicos", 12);
            dtTipos.Rows.Add("Servicios No Médicos", 6);

            rptFiltroTipo.DataSource = dtTipos;
            rptFiltroTipo.DataBind();

            // Cargar DropDownList de Rango de Costo
            DataTable dtRango = new DataTable();
            dtRango.Columns.Add("RangoID", typeof(string));
            dtRango.Columns.Add("Nombre", typeof(string));
            dtRango.Rows.Add("TODOS", "Todos");
            dtRango.Rows.Add("0-50", "S/ 0 - S/ 50");
            dtRango.Rows.Add("51-150", "S/ 51 - S/ 150");
            dtRango.Rows.Add("151-MAS", "S/ 151 a más");

            ddlRangoCosto.DataSource = dtRango;
            ddlRangoCosto.DataTextField = "Nombre";
            ddlRangoCosto.DataValueField = "RangoID";
            ddlRangoCosto.DataBind();

            // Cargar DropDownList de Estado
            DataTable dtEstado = new DataTable();
            dtEstado.Columns.Add("EstadoID", typeof(string));
            dtEstado.Columns.Add("Nombre", typeof(string));
            dtEstado.Rows.Add("TODOS", "Todos");
            dtEstado.Rows.Add("Activo", "Activo");
            dtEstado.Rows.Add("Inactivo", "Inactivo");

            ddlEstado.DataSource = dtEstado;
            ddlEstado.DataTextField = "Nombre";
            ddlEstado.DataValueField = "EstadoID";
            ddlEstado.DataBind();

            // Cargar DropDownList del Modal (Tipos de servicio)
            var tiposParaModal = dtTipos.AsEnumerable()
                                        .Where(row => row.Field<string>("Tipo") != "Todos")
                                        .CopyToDataTable();

            ddlModalTipo.DataSource = tiposParaModal;
            ddlModalTipo.DataTextField = "Tipo";
            ddlModalTipo.DataValueField = "Tipo";
            ddlModalTipo.DataBind();
        }

        private void CargarServicios()
        {
            // Leemos los datos desde la Sesión
            DataTable dt = Session["ServiciosData"] as DataTable;

            if (dt != null)
            {
                // Lógica de Filtro (Ejemplo simple)
                var query = dt.AsEnumerable();

                if (!string.IsNullOrWhiteSpace(txtNombreServicio.Text))
                {
                    query = query.Where(r => r.Field<string>("Nombre").ToLower().Contains(txtNombreServicio.Text.ToLower()));
                }
                if (ddlEstado.SelectedValue != "TODOS")
                {
                    query = query.Where(r => r.Field<string>("Estado") == ddlEstado.SelectedValue);
                }
                // Aquí iría el filtro por Rango de Costo (más complejo, requiere parsear)

                DataTable dtFiltrado = dt.Clone(); // Clona la estructura
                if (query.Any())
                {
                    dtFiltrado = query.CopyToDataTable();
                }

                rptServicios.DataSource = dtFiltrado;
                rptServicios.DataBind();

                // Actualizar contadores
                litRegistrosTotales.Text = dt.Rows.Count.ToString();
                litRegistrosActuales.Text = $"1-{dtFiltrado.Rows.Count}";
            }
        }

        private DataTable ObtenerServiciosEjemplo()
        {
            DataTable dt = new DataTable();
            // Columnas de datos "crudos"
            dt.Columns.Add("ServicioID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Columns.Add("Descripcion", typeof(string));
            dt.Columns.Add("Tipo", typeof(string));
            dt.Columns.Add("Precio", typeof(double));
            dt.Columns.Add("Estado", typeof(string));
            // Columnas de formato (visuales)
            dt.Columns.Add("IconoCss", typeof(string));
            dt.Columns.Add("IconoColorCss", typeof(string));
            dt.Columns.Add("PrecioFormateado", typeof(string));
            dt.Columns.Add("EstadoClaseCss", typeof(string));

            // Datos de ejemplo con Tipo y Precio
            dt.Rows.Add(1, "CONSULTA GENERAL", "Examen clínico completo...", "Servicios Médicos", 50.00, "Activo", "fas fa-stethoscope", "icon-bg-consulta", "S/ 50.00", "status-activo");
            dt.Rows.Add(2, "RADIOGRAFÍA", "Estudio radiológico...", "Servicios Médicos", 120.00, "Activo", "fas fa-x-ray", "icon-bg-radiografia", "S/ 120.00", "status-activo");
            dt.Rows.Add(3, "ANÁLISIS DE SANGRE", "Hemograma completo...", "Servicios Médicos", 180.00, "Activo", "fas fa-flask", "icon-bg-analisis", "S/ 180.00", "status-activo");
            dt.Rows.Add(4, "LIMPIEZA DENTAL", "Profilaxis dental completa...", "Servicios No Médicos", 250.00, "Activo", "fas fa-tooth", "icon-bg-limpieza", "S/ 250.00", "status-activo");
            dt.Rows.Add(5, "CIRUGÍA MENOR", "Procedimientos quirúrgicos...", "Servicios Médicos", 350.00, "Activo", "fas fa-cut", "icon-bg-cirugia", "S/ 350.00", "status-activo");
            dt.Rows.Add(6, "VACUNACIÓN", "Aplicación de vacunas...", "Servicios Médicos", 80.00, "Activo", "fas fa-syringe", "icon-bg-vacunacion", "S/ 80.00", "status-activo");
            dt.Rows.Add(7, "BAÑO MEDICADO", "Baño terapéutico...", "Servicios No Médicos", 60.00, "Inactivo", "fas fa-bath", "icon-bg-bano", "S/ 60.00", "status-inactivo");

            return dt;
        }

        // --- Eventos de Botones (Filtros) ---

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarServicios();
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombreServicio.Text = "";
            ddlRangoCosto.SelectedIndex = 0;
            ddlEstado.SelectedIndex = 0;
            CargarServicios();
        }

        protected void rptFiltroTipo_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            // Lógica para filtrar por tipo al hacer clic en las pestañas
        }

        // --- Eventos de los Modals (Servicio) ---

        protected void btnGuardarServicio_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["ServiciosData"] as DataTable;
            if (dt == null) return;

            try
            {
                int servicioID = Convert.ToInt32(hdServicioID.Value);

                // Recolectar datos del modal
                string nombre = txtModalNombre.Text;
                string tipo = ddlModalTipo.SelectedValue;
                string descripcion = txtModalDescripcion.Text;
                double precio = double.Parse(txtModalPrecio.Text, CultureInfo.InvariantCulture);
                string estado = ddlModalEstado.SelectedValue;

                // Generar datos visuales (helpers)
                string iconoCss = GetIconoPorTipo(tipo);
                string iconoColorCss = GetColorPorTipo(tipo);
                string precioFormateado = string.Format("S/ {0:N2}", precio);
                string estadoClaseCss = estado == "Activo" ? "status-activo" : "status-inactivo";

                if (servicioID == 0)
                {
                    // --- CREAR NUEVO SERVICIO ---
                    int newID = dt.Rows.Count > 0 ? dt.AsEnumerable().Max(row => row.Field<int>("ServicioID")) + 1 : 1;

                    dt.Rows.Add(
                        newID,
                        nombre,
                        descripcion,
                        tipo,
                        precio,
                        estado,
                        iconoCss,
                        iconoColorCss,
                        precioFormateado,
                        estadoClaseCss
                    );
                }
                else
                {
                    // --- EDITAR SERVICIO EXISTENTE ---
                    DataRow row = dt.AsEnumerable().FirstOrDefault(r => r.Field<int>("ServicioID") == servicioID);
                    if (row != null)
                    {
                        row["Nombre"] = nombre;
                        row["Descripcion"] = descripcion;
                        row["Tipo"] = tipo;
                        row["Precio"] = precio;
                        row["Estado"] = estado;
                        row["IconoCss"] = iconoCss;
                        row["IconoColorCss"] = iconoColorCss;
                        row["PrecioFormateado"] = precioFormateado;
                        row["EstadoClaseCss"] = estadoClaseCss;
                    }
                }

                Session["ServiciosData"] = dt;
                CargarServicios();
                updPanelServicios.Update();
            }
            catch (Exception ex)
            {
                // Manejo básico de errores
                Console.Write(ex.Message);
            }
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["ServiciosData"] as DataTable;
            if (dt == null) return;

            try
            {
                int servicioID = Convert.ToInt32(hdServicioIDEliminar.Value);
                DataRow row = dt.AsEnumerable().FirstOrDefault(r => r.Field<int>("ServicioID") == servicioID);

                if (row != null)
                {
                    dt.Rows.Remove(row);
                }

                Session["ServiciosData"] = dt;
                CargarServicios();
                updPanelServicios.Update();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        // --- Funciones Helper para la UI ---

        private string GetIconoPorTipo(string tipo)
        {
            switch (tipo)
            {
                case "Servicios Médicos": return "fas fa-stethoscope"; // Icono genérico médico
                case "Servicios No Médicos": return "fas fa-cut"; // Icono genérico no médico (ej. peluquería)
                default: return "fas fa-briefcase-medical";
            }
        }

        private string GetColorPorTipo(string tipo)
        {
            switch (tipo)
            {
                case "Servicios Médicos": return "icon-bg-consulta"; // Asumiendo color azul
                case "Servicios No Médicos": return "icon-bg-bano"; // Asumiendo color naranja
                default: return "icon-bg-default";
            }
        }
    }
}