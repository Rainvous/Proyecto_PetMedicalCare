package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.facturacion.DocumentoPagoDto;

public interface DocumentoDePagoDao extends DaoBase<DocumentoPagoDto> {

}
