﻿// Nombre del archivo: Secretaria_PuntoVenta.aspx.cs (CON LOGICA DE COMPROBANTE DINAMICO)
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SoftPetBusiness;
using SoftPetBussiness.PersonaClient;
using SoftPetBussiness.ProductoClient;
using SoftPetBussiness.ServicioClient;
using SoftPetBussiness.MetodoDePagoClient;
using SoftPetBussiness.DocumentoDePagoClient;

namespace SoftPetWA
{
    public partial class Secretaria_PuntoVenta : System.Web.UI.Page
    {
        private PersonaBO boPersona = new PersonaBO();
        private ProductoBO boProducto = new ProductoBO();
        private ServicioBO boServicio = new ServicioBO();
        private MetodoDePagoBO boMetodoPago = new MetodoDePagoBO();
        private DocumentoDePagoBO boDocumento = new DocumentoDePagoBO();
        private DetalleDocumentoDePagoBO boDetalleDoc = new DetalleDocumentoDePagoBO();
        // Instancia del nuevo BO necesario
        private DetalleServicioBO boDetalleServicio = new DetalleServicioBO();
        private DataTable CarritoDT
        {
            get { return ViewState["CarritoDT"] as DataTable; }
            set { ViewState["CarritoDT"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                InicializarInterfaz();

                if (Session["Comprobante_CitaId"] != null && Session["Comprobante_PersonaId"] != null)
                {
                    int citaId = Convert.ToInt32(Session["Comprobante_CitaId"]);
                    int personaId = Convert.ToInt32(Session["Comprobante_PersonaId"]);
                    CargarDatosDeCita(citaId, personaId);
                }
                else
                {
                    CargarDatosClienteDefault();
                    InicializarCarritoVacio();
                }
            }
        }

        private void InicializarInterfaz()
        {
            CargarFiltrosVisuales();
            CargarMetodosDePago();
            CargarCatalogoCompleto();
            // Por defecto, cliente general = Solo Boleta
            ConfigurarTiposComprobante(false);
        }

        #region "Lógica de Cliente y Comprobantes"

        // *** NUEVO: Configura el combo según si tiene RUC ***
        private void ConfigurarTiposComprobante(bool tieneRuc)
        {
            ddlTipoComprobante.Items.Clear();
            ddlTipoComprobante.Items.Add(new ListItem("Boleta de Venta", "BOLETA"));

            if (tieneRuc)
            {
                ddlTipoComprobante.Items.Add(new ListItem("Factura", "FACTURA"));
            }

            // Reiniciar selección y visibilidad del panel RUC
            ddlTipoComprobante.SelectedIndex = 0;
            pnlDatosFactura.Visible = false;
        }

        // Abre el modal de búsqueda
        protected void btnCambiarCliente_Click(object sender, EventArgs e)
        {
            txtBuscarNombreCliente.Text = "";
            rptResultadosCliente.DataSource = null;
            rptResultadosCliente.DataBind();
            updModalCliente.Update();
            ScriptManager.RegisterStartupScript(this, GetType(), "showModalCliente", "$('#modalBuscarCliente').modal('show');", true);
        }

        // Busca clientes
        protected void btnBuscarClienteModal_Click(object sender, EventArgs e)
        {
            string nombre = txtBuscarNombreCliente.Text.Trim();
            try
            {
                // Busca activos
                var resultados = boPersona.ListarPorNombreNroDocumentoRucTelefono(nombre, "", "", "", true);
                rptResultadosCliente.DataSource = resultados;
                rptResultadosCliente.DataBind();
            }
            catch { }
            updModalCliente.Update();
        }

        // Selecciona cliente del modal
        protected void rptResultadosCliente_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Seleccionar")
            {
                string[] args = e.CommandArgument.ToString().Split('|');
                int personaId = Convert.ToInt32(args[0]);
                string ruc = args[1];
                string nombre = args[2];

                Session["Comprobante_PersonaId"] = personaId;
                lblClienteNombre.Text = nombre;

                bool tieneRuc = (ruc != "0" && !string.IsNullOrEmpty(ruc));

                if (tieneRuc)
                {
                    lblClienteInfo.Text = $"RUC: {ruc}";
                    txtRucCliente.Text = ruc;
                }
                else
                {
                    lblClienteInfo.Text = "Cliente sin RUC";
                    txtRucCliente.Text = "";
                }

                // *** LÓGICA CLAVE: Reconfigurar dropdown ***
                ConfigurarTiposComprobante(tieneRuc);

                updCarrito.Update();
            }
        }

        // Evento al cambiar el combo (Solo visible si tiene RUC y elige Factura)
        protected void ddlTipoComprobante_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlTipoComprobante.SelectedValue == "FACTURA")
            {
                pnlDatosFactura.Visible = true;
            }
            else
            {
                pnlDatosFactura.Visible = false;
            }
            updCarrito.Update();
        }

        // *** (MÉTODO ACTUALIZADO: Carga servicios reales de la cita) ***
        private void CargarDatosDeCita(int citaId, int personaId)
        {
            // 1. Cargar Cliente (Igual que antes)
            try
            {
                var p = boPersona.ObtenerPorId(personaId);
                if (p != null)
                {
                    lblClienteNombre.Text = p.nombre;
                    lblClienteInfo.Text = $"Doc: {p.nroDocumento}";
                    if (p.ruc != null && p.ruc > 0)
                    {
                        txtRucCliente.Text = p.ruc.ToString();
                        // Si tiene RUC, habilitar factura automáticamente
                        ConfigurarTiposComprobante(true);
                    }
                    else
                    {
                        ConfigurarTiposComprobante(false);
                    }
                }
            }
            catch { }

            // 2. Cargar Servicios de la Cita (USANDO EL BO)
            InicializarCarritoVacio(); // Limpia el carrito

            try
            {
                // A. Obtenemos TODOS los detalles (Temporal, hasta que tengas ListarPorCita)
                List<SoftPetBussiness.DetalleServicioClient.detalleServicioDto> todosDetalles = boDetalleServicio.ListarTodos();

                // B. Filtramos en memoria solo los de ESTA cita
                var detallesDeEstaCita = todosDetalles.Where(d => d.cita.citaId == citaId).ToList();

                // C. Agregamos cada servicio al carrito
                foreach (var detalle in detallesDeEstaCita)
                {
                    // Obtenemos el nombre del servicio (el detalle tiene descripcion, pero mejor el nombre original)
                    // Si detalle.servicio.nombre viene null, usamos la descripcion del detalle o buscamos el servicio
                    string nombreServicio = !string.IsNullOrEmpty(detalle.descripcion) ? detalle.descripcion : "Servicio de Cita";

                    // Intentamos obtener el nombre real del servicio si es posible
                    try
                    {
                        var s = boServicio.ObtenerPorId(detalle.servicio.servicioId);
                        if (s != null) nombreServicio = s.nombre;
                    }
                    catch { }

                    // Agregar al carrito (ID Servicio, Nombre, Costo)
                    AgregarItemAlCarrito(
                        0,                          // ProductoID = 0
                        detalle.servicio.servicioId, // ServicioID
                        nombreServicio,
                        (decimal)detalle.costo
                    );
                }
            }
            catch (Exception ex)
            {
                // Si falla algo, el carrito quedará vacío, no rompemos la página
            }
        }

        private void CargarDatosClienteDefault()
        {
            lblClienteNombre.Text = "Cliente General";
            lblClienteInfo.Text = "";
            ConfigurarTiposComprobante(false); // Cliente general solo boleta
        }

        #endregion

        #region "Carga de Datos Maestros y Catálogo"

        private void CargarFiltrosVisuales()
        {
            DataTable dtTipos = new DataTable();
            dtTipos.Columns.Add("Tipo", typeof(string));
            dtTipos.Columns.Add("IconoCss", typeof(string));
            dtTipos.Rows.Add("Todos", "fas fa-th-large");
            dtTipos.Rows.Add("Medicamentos", "fas fa-pills");
            dtTipos.Rows.Add("Alimentos", "fas fa-bone");
            dtTipos.Rows.Add("Servicios", "fas fa-briefcase-medical");
            rptFiltroTipo.DataSource = dtTipos;
            rptFiltroTipo.DataBind();
        }

        private void CargarMetodosDePago()
        {
            try
            {
                List<SoftPetBussiness.MetodoDePagoClient.metodoDePagoDto> metodos = boMetodoPago.ListarTodos();
                ddlMetodoPago.DataSource = metodos;
                ddlMetodoPago.DataTextField = "nombre";
                ddlMetodoPago.DataValueField = "metodoDePagoId";
                ddlMetodoPago.DataBind();
            }
            catch
            {
                ddlMetodoPago.Items.Add(new ListItem("Efectivo", "1"));
            }
        }

        private void CargarCatalogoCompleto(string filtroNombre = "")
        {
            DataTable dtCatalogo = new DataTable();
            dtCatalogo.Columns.Add("ID", typeof(int));
            dtCatalogo.Columns.Add("Tipo", typeof(string));
            dtCatalogo.Columns.Add("IconoCss", typeof(string));
            dtCatalogo.Columns.Add("Nombre", typeof(string));
            dtCatalogo.Columns.Add("Descripcion", typeof(string));
            dtCatalogo.Columns.Add("PrecioUnitario", typeof(decimal));
            dtCatalogo.Columns.Add("PrecioFormateado", typeof(string));
            dtCatalogo.Columns.Add("StockTexto", typeof(string));
            dtCatalogo.Columns.Add("ProductoID", typeof(int));
            dtCatalogo.Columns.Add("ServicioID", typeof(int));

            CultureInfo culture = CultureInfo.CreateSpecificCulture("es-PE");

            try
            {
                List<productoDto> productos;
                if (string.IsNullOrEmpty(filtroNombre)) productos = boProducto.ListarActivos();
                else productos = boProducto.ListarBusquedaAvanzada(filtroNombre, "", "1");

                foreach (var p in productos)
                {
                    dtCatalogo.Rows.Add(p.productoId, "P", "fas fa-box", p.nombre, p.presentacion,
                        (decimal)p.precioUnitario, ((decimal)p.precioUnitario).ToString("C", culture),
                        $"Stock: {p.stock}", p.productoId, 0);
                }

                List<servicioDto> servicios;
                if (string.IsNullOrEmpty(filtroNombre)) servicios = boServicio.listarServicioActivos();
                else servicios = boServicio.listarPorNombreRangoActivo(filtroNombre, "", "1");

                foreach (var s in servicios)
                {
                    dtCatalogo.Rows.Add(s.servicioId, "S", "fas fa-stethoscope", s.nombre, s.descripcion,
                        (decimal)s.costo, ((decimal)s.costo).ToString("C", culture),
                        "Servicio", 0, s.servicioId);
                }
            }
            catch { }

            ViewState["CatalogoDT"] = dtCatalogo;
            rptProductos.DataSource = dtCatalogo;
            rptProductos.DataBind();
        }
        #endregion

        #region "Gestión del Carrito"

        private void InicializarCarritoVacio()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ItemID", typeof(string));
            dt.Columns.Add("ProductoID", typeof(int));
            dt.Columns.Add("ServicioID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Columns.Add("Cantidad", typeof(int));
            dt.Columns.Add("PrecioUnitario", typeof(decimal));
            dt.Columns.Add("PrecioTotalFormateado", typeof(string));
            CarritoDT = dt;
            ActualizarVistaCarrito();
        }

        private void ActualizarVistaCarrito()
        {
            rptCarrito.DataSource = CarritoDT;
            rptCarrito.DataBind();
            CalcularTotales();
            updCarrito.Update();
        }

        private void CalcularTotales()
        {
            decimal total = 0;
            foreach (DataRow row in CarritoDT.Rows)
            {
                total += (Convert.ToDecimal(row["PrecioUnitario"]) * Convert.ToInt32(row["Cantidad"]));
            }
            decimal subtotal = total / 1.18m;
            decimal igv = total - subtotal;

            CultureInfo culture = CultureInfo.CreateSpecificCulture("es-PE");
            lblSubtotal.Text = subtotal.ToString("C", culture);
            lblIGV.Text = igv.ToString("C", culture);
            lblTotal.Text = total.ToString("C", culture);
        }

        protected void rptProductos_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Agregar")
            {
                int idSeleccionado = Convert.ToInt32(e.CommandArgument);
                DataTable dtCat = (DataTable)ViewState["CatalogoDT"];

                // Buscar en el catálogo guardado para saber si es Prod o Serv
                // Nota: Esta búsqueda asume IDs únicos en la columna ID visual del catálogo.
                // Si hay conflicto, es mejor usar el ID compuesto. 
                // Por simplicidad y dado que usamos ProductoID en el argumento, intentamos producto primero.

                productoDto prod = boProducto.ObtenerPorId(idSeleccionado);
                if (prod != null && prod.nombre != null)
                {
                    AgregarItemAlCarrito(prod.productoId, 0, prod.nombre, (decimal)prod.precioUnitario);
                }
                else
                {
                    servicioDto serv = boServicio.ObtenerPorId(idSeleccionado);
                    if (serv != null) AgregarItemAlCarrito(0, serv.servicioId, serv.nombre, (decimal)serv.costo);
                }
            }
        }

        private void AgregarItemAlCarrito(int prodId, int servId, string nombre, decimal precio)
        {
            string itemId = prodId > 0 ? $"P-{prodId}" : $"S-{servId}";
            DataRow row = CarritoDT.AsEnumerable().FirstOrDefault(r => r["ItemID"].ToString() == itemId);

            if (row != null)
            {
                row["Cantidad"] = Convert.ToInt32(row["Cantidad"]) + 1;
                row["PrecioTotalFormateado"] = ((Convert.ToInt32(row["Cantidad"])) * precio).ToString("C", CultureInfo.CreateSpecificCulture("es-PE"));
            }
            else
            {
                DataRow newRow = CarritoDT.NewRow();
                newRow["ItemID"] = itemId;
                newRow["ProductoID"] = prodId;
                newRow["ServicioID"] = servId;
                newRow["Nombre"] = nombre;
                newRow["Cantidad"] = 1;
                newRow["PrecioUnitario"] = precio;
                newRow["PrecioTotalFormateado"] = precio.ToString("C", CultureInfo.CreateSpecificCulture("es-PE"));
                CarritoDT.Rows.Add(newRow);
            }
            ActualizarVistaCarrito();
        }

        protected void rptCarrito_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            string itemId = e.CommandArgument.ToString();
            DataRow row = CarritoDT.AsEnumerable().FirstOrDefault(r => r["ItemID"].ToString() == itemId);

            if (row != null)
            {
                int cant = Convert.ToInt32(row["Cantidad"]);
                decimal precio = Convert.ToDecimal(row["PrecioUnitario"]);

                if (e.CommandName == "Sumar") cant++;
                else if (e.CommandName == "Restar") { if (cant > 1) cant--; }
                else if (e.CommandName == "Quitar") CarritoDT.Rows.Remove(row);

                if (e.CommandName != "Quitar")
                {
                    row["Cantidad"] = cant;
                    row["PrecioTotalFormateado"] = (cant * precio).ToString("C", CultureInfo.CreateSpecificCulture("es-PE"));
                }
                ActualizarVistaCarrito();
            }
        }

        protected void txtQuantity_TextChanged(object sender, EventArgs e) { }

        #endregion

        #region "Generación de Comprobante"

        protected void btnGenerarComprobante_Click(object sender, EventArgs e)
        {
            try
            {
                if (CarritoDT.Rows.Count == 0) return;

                int metodoPagoId = Convert.ToInt32(ddlMetodoPago.SelectedValue);
                int personaId = Session["Comprobante_PersonaId"] != null ? Convert.ToInt32(Session["Comprobante_PersonaId"]) : 0;
                string tipoDoc = ddlTipoComprobante.SelectedValue.ToUpper();
                string serie = "X008";
                string numero = DateTime.Now.Ticks.ToString().Substring(10);
                string fecha = DateTime.Now.ToString("yyyy-MM-dd");
                string estado = "PAGADO";

                string totalStr = lblTotal.Text.Replace("S/", "").Trim();
                double total = Convert.ToDouble(totalStr);
                double subtotal = total / 1.18;
                double igv = total - subtotal;

                int docId = boDocumento.Insertar(metodoPagoId, personaId, tipoDoc, serie, numero, fecha, estado, subtotal, igv, total, true);

                if (docId > 0)
                {
                    foreach (DataRow row in CarritoDT.Rows)
                    {
                        int prodId = Convert.ToInt32(row["ProductoID"]);
                        int servId = Convert.ToInt32(row["ServicioID"]);
                        string desc = row["Nombre"].ToString();
                        int cant = Convert.ToInt32(row["Cantidad"]);
                        double precUnit = Convert.ToDouble(row["PrecioUnitario"]);
                        double valorVenta = precUnit * cant;

                        boDetalleDoc.Insertar(docId, servId, prodId, 0, desc, cant, precUnit, valorVenta, true);
                    }

                    Session.Remove("Comprobante_CitaId");
                    Session.Remove("Comprobante_PersonaId");
                    //string script = "alert('Comprobante generado exitosamente. ID: " + docId + "'); window.location='Secretaria_AgendaCitas.aspx';";
                    //ScriptManager.RegisterStartupScript(this, GetType(), "ExitoCompra", script, true);
                }
            }
            catch (Exception ex) { }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Session.Remove("Comprobante_CitaId");
            Session.Remove("Comprobante_PersonaId");
            Response.Redirect("Secretaria_AgendaCitas.aspx");
        }

        protected void btnBuscar_Click(object sender, EventArgs e) { CargarCatalogoCompleto(txtBusquedaProducto.Text.Trim()); }
        protected void rptFiltroTipo_ItemCommand(object source, RepeaterCommandEventArgs e) { if (e.CommandName == "Filtrar") CargarCatalogoCompleto(); }

        #endregion
    }
}