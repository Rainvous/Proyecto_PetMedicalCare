﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using SoftPetBusiness; // Tu capa de negocio C# (UsuarioBO, RolBO)

// Importa los namespaces de tus DTOs (pueden variar)
using SoftPetBussiness.UsuarioClient;
using SoftPetBussiness.RolClient;

namespace SoftPetWA
{
    public partial class Login : System.Web.UI.Page
    {
        private UsuarioBO usuarioBO;
        private RolBO rolBO;

        public Login()
        {
            this.usuarioBO = new UsuarioBO();
            this.rolBO = new RolBO();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblError.Visible = false;
            }
        }

        protected void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            validar_datos_real();
        }

        private void validar_datos_real()
        {
            string correo = txtUsuario.Text.Trim();
            string password = txtContrasena.Text;

            if (string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(password))
            {
                MostrarError("El correo y la contraseña son obligatorios.");
                return;
            }

            try
            {
                // PASO 1: Validar usuario y contraseña (1er viaje a Java)
                List<usuarioDto> usuarios = this.usuarioBO.ObtenerPorCorreoYContra(correo, password);

                if (usuarios == null || usuarios.Count == 0)
                {
                    MostrarError("Correo o contraseña incorrectos.");
                    return;
                }

                usuarioDto usuario = usuarios[0];

                // PASO 2: Obtener el rol del usuario (2do viaje a Java)
                List<rolDto> roles = this.rolBO.ObtenerRolesDelUsuario(usuario.usuarioId);

                if (roles == null || roles.Count == 0)
                {
                    MostrarError("Este usuario existe pero no tiene un rol asignado.");
                    return;
                }

                rolDto rol = roles[0];

                // PASO 3: Guardar en Sesión
                Session["UsuarioId"] = usuario.usuarioId;
                Session["UsuarioNombre"] = usuario.username;
                Session["UsuarioRol"] = rol.nombre;

                // ======================================================
                // ==== LÓGICA DE REDIRECCIÓN MODIFICADA (AQUÍ) ====
                // ======================================================
                switch (rol.nombre.ToUpper())
                {
                    case "VET":
                        Response.Redirect("Veterinario_Inicio.aspx");
                        break;

                    case "CLIENTE":
                        Response.Redirect("Cliente_Inicio.aspx");
                        break;

                    // Si es ADMIN o RECEPCION, va a la misma página
                    case "ADMIN":
                    case "RECEPCION":
                        Response.Redirect("Secretaria_Dashboard.aspx");
                        break;

                    default:
                        MostrarError("Rol no configurado: " + rol.nombre);
                        break;
                }
            }
            catch (Exception ex)
            {
                MostrarError("Error al conectar con el servicio: " + ex.Message);
            }
        }

        private void MostrarError(string mensaje)
        {
            lblError.Text = mensaje;
            lblError.Visible = true;
        }
    }
}