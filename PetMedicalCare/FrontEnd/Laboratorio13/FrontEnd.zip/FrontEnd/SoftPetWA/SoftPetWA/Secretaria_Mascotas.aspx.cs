﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftPetBusiness;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient;

namespace SoftPetWA
{
    public partial class Secretaria_Mascotas : System.Web.UI.Page
    {
        private MascotaBO boMascota = new MascotaBO();
        private PersonaBO boPersona = new PersonaBO();

        [Serializable]
        public class MascotaViewModel
        {
            public int MascotaId { get; set; }
            public string Nombre { get; set; }
            public string Especie { get; set; }
            public string Raza { get; set; }
            public string Sexo { get; set; }
            public string Color { get; set; }
            public bool Activo { get; set; }
            public int PersonaId { get; set; }
            public string NombreDuenio { get; set; }
            public string TelefonoDuenio { get; set; }
        }

        private const int PageSize = 6;

        public int CurrentPage
        {
            get { return (int)(ViewState["CurrentPage"] ?? 1); }
            set { ViewState["CurrentPage"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CurrentPage = 1;
                CargarListasMaestras();
                CargarFiltrosDropDowns();
                EnlazarDatos();
            }
        }

        private void CargarListasMaestras()
        {
            // Solo cargamos personas para tener la lista de dueños en memoria (Hidratación)
            // Ya no cargamos todas las mascotas aquí porque usaremos el buscador
            List<SoftPetBussiness.PersonaClient.personaDto> listaPersonas = boPersona.ListarTodos();
            if (listaPersonas == null) listaPersonas = new List<SoftPetBussiness.PersonaClient.personaDto>();
            ViewState["ListaMaestraPersonas"] = listaPersonas;
        }

        private void CargarFiltrosDropDowns()
        {
            // Filtro Especie (Restringido a Perro y Gato)
            DataTable dtEspecie = new DataTable();
            dtEspecie.Columns.Add("Nombre", typeof(string));
            dtEspecie.Rows.Add("Todas");
            dtEspecie.Rows.Add("Perro");
            dtEspecie.Rows.Add("Gato");

            ddlEspecie.DataSource = dtEspecie;
            ddlEspecie.DataTextField = "Nombre";
            ddlEspecie.DataValueField = "Nombre";
            ddlEspecie.DataBind();

            // Modal Especie (Sin "Todas")
            var dtEspeciesModal = dtEspecie.AsEnumerable()
                                    .Where(r => r.Field<string>("Nombre") != "Todas")
                                    .CopyToDataTable();

            ddlModalEspecie.DataSource = dtEspeciesModal;
            ddlModalEspecie.DataTextField = "Nombre";
            ddlModalEspecie.DataValueField = "Nombre";
            ddlModalEspecie.DataBind();

            // Propietarios
            var listaPersonas = (List<SoftPetBussiness.PersonaClient.personaDto>)ViewState["ListaMaestraPersonas"];
            var clientesActivos = listaPersonas.Where(p => p.activo).OrderBy(p => p.nombre).ToList();

            ddlModalCliente.DataSource = clientesActivos;
            ddlModalCliente.DataTextField = "nombre";
            ddlModalCliente.DataValueField = "personaId";
            ddlModalCliente.DataBind();
            ddlModalCliente.Items.Insert(0, new ListItem("Seleccione un Propietario", "0"));
        }

        // --- LÓGICA DE BÚSQUEDA CON EL BO ---
        private List<MascotaViewModel> ObtenerListaProcesada()
        {
            // 1. Obtener parámetros de los controles
            string nombreMascota = txtNombreMascota.Text.Trim();
            string raza = txtRaza.Text.Trim();
            string nombreDuenio = txtPropietario.Text.Trim();

            // Si seleccionó "Todas", enviamos cadena vacía al servicio
            string especie = ddlEspecie.SelectedValue;
            if (especie == "Todas") especie = "";

            // 2. LLAMADA AL BO DE BÚSQUEDA
            List<mascotaDto> listaResultados = boMascota.ListarPorNombreRazaEspecieNombrepersona(
                nombreMascota, raza, especie, nombreDuenio
            );

            if (listaResultados == null) listaResultados = new List<mascotaDto>();

            // 3. HIDRATACIÓN (Cruzar con la lista de Personas para obtener nombre del dueño)
            var listaPersonas = (List<SoftPetBussiness.PersonaClient.personaDto>)ViewState["ListaMaestraPersonas"];
            // Diccionario para búsqueda rápida O(1)
            var personasDict = listaPersonas.ToDictionary(p => p.personaId);

            var listaViewModel = listaResultados.Select(m =>
            {
                string nombreDuenioReal = "Sin Asignar";
                string telefonoDuenioReal = "-";

                if (m.persona != null && personasDict.ContainsKey(m.persona.personaId))
                {
                    var p = personasDict[m.persona.personaId];
                    nombreDuenioReal = p.nombre;
                    telefonoDuenioReal = p.telefono;
                }

                return new MascotaViewModel
                {
                    MascotaId = m.mascotaId,
                    Nombre = m.nombre,
                    Especie = m.especie,
                    Raza = m.raza,
                    Sexo = m.sexo,
                    Color = m.color,
                    Activo = m.activo,
                    PersonaId = m.persona.personaId,
                    NombreDuenio = nombreDuenioReal,
                    TelefonoDuenio = telefonoDuenioReal
                };
            }).ToList();

            return listaViewModel;
        }

        private void EnlazarDatos()
        {
            // Llama a la búsqueda
            List<MascotaViewModel> listaFiltrada = ObtenerListaProcesada();

            int totalRegistros = listaFiltrada.Count;
            litRegistrosTotales.Text = totalRegistros.ToString();

            int inicio = (CurrentPage - 1) * PageSize + 1;
            int fin = Math.Min(CurrentPage * PageSize, totalRegistros);
            if (fin == 0) inicio = 0;
            litRegistrosActuales.Text = $"{inicio}-{fin}";

            var listaPagina = listaFiltrada.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();

            rptMascotas.DataSource = listaPagina;
            rptMascotas.DataBind();

            GenerarPaginado(totalRegistros);
        }

        private void GenerarPaginado(int totalRegistros)
        {
            if (totalRegistros <= PageSize)
            {
                rptPaginador.DataSource = null;
                rptPaginador.DataBind();
                lnkAnterior.Enabled = false;
                lnkSiguiente.Enabled = false;
                return;
            }

            int totalPages = (int)Math.Ceiling((double)totalRegistros / PageSize);
            lnkAnterior.Enabled = (CurrentPage > 1);
            lnkSiguiente.Enabled = (CurrentPage < totalPages);

            var paginas = new List<object>();
            for (int i = 1; i <= totalPages; i++)
                paginas.Add(new { Pagina = i, EsPaginaActual = (i == CurrentPage) });

            rptPaginador.DataSource = paginas;
            rptPaginador.DataBind();
        }

        protected void btnBuscar_Click(object sender, EventArgs e) { CurrentPage = 1; EnlazarDatos(); }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombreMascota.Text = "";
            txtRaza.Text = "";
            txtPropietario.Text = "";
            ddlEspecie.SelectedIndex = 0;
            CurrentPage = 1;
            EnlazarDatos();
        }

        protected void lnkPaginado_Click(object sender, EventArgs e)
        {
            string command = ((LinkButton)sender).CommandName;
            if (command == "Anterior" && CurrentPage > 1) CurrentPage--;
            else if (command == "Siguiente") CurrentPage++;
            EnlazarDatos();
        }

        protected void rptPaginador_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "IrPagina")
            {
                CurrentPage = Convert.ToInt32(e.CommandArgument);
                EnlazarDatos();
            }
        }

        // --- CRUD ---
        protected void btnGuardarMascota_Click(object sender, EventArgs e)
        {
            litMensaje.Text = "";
            try
            {
                if (string.IsNullOrWhiteSpace(txtModalNombre.Text) || string.IsNullOrWhiteSpace(txtModalRaza.Text))
                {
                    litMensaje.Text = "<div class='alert alert-warning'>El nombre y la raza son obligatorios.</div>";
                    return;
                }

                int mascotaID = Convert.ToInt32(hdMascotaID.Value);
                int personaId = Convert.ToInt32(ddlModalCliente.SelectedValue);
                if (personaId == 0)
                {
                    litMensaje.Text = "<div class='alert alert-warning'>Debe seleccionar un Propietario válido.</div>";
                    return;
                }

                string nombre = txtModalNombre.Text;
                string especie = ddlModalEspecie.SelectedValue;
                string sexo = ddlModalSexo.SelectedValue;
                string raza = txtModalRaza.Text;
                string color = txtModalColor.Text;
                bool activo = Convert.ToBoolean(ddlModalEstado.SelectedValue);
                // Enviar null si está vacía para evitar error de fecha
                string fechaDefuncion = null;

                int resultado = 0;
                if (mascotaID == 0)
                    resultado = boMascota.Insertar(personaId, nombre, especie, sexo, raza, color, fechaDefuncion, activo);
                else
                    resultado = boMascota.Modificar(mascotaID, personaId, nombre, especie, sexo, raza, color, fechaDefuncion, activo);

                if (resultado > 0)
                {
                    litMensaje.Text = "<div class='alert alert-success'>Mascota guardada correctamente.</div>";
                    EnlazarDatos(); // Recargar con filtros actuales
                    ScriptManager.RegisterStartupScript(this, GetType(), "HideModal", "$('#modalMascota').modal('hide');", true);
                }
                else
                {
                    litMensaje.Text = "<div class='alert alert-danger'>Error al guardar en base de datos.</div>";
                }
            }
            catch (Exception ex)
            {
                litMensaje.Text = $"<div class='alert alert-danger'>Error: {ex.Message}</div>";
            }
            updPanelMascotas.Update();
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            litMensaje.Text = "";
            try
            {
                int mascotaID = Convert.ToInt32(hdMascotaIDEliminar.Value);
                int resultado = boMascota.Eliminar(mascotaID);

                if (resultado > 0)
                {
                    litMensaje.Text = "<div class='alert alert-success'>Mascota eliminada correctamente.</div>";
                    EnlazarDatos();
                    ScriptManager.RegisterStartupScript(this, GetType(), "HideDelete", "$('#modalConfirmarEliminar').modal('hide');", true);
                }
                else
                {
                    litMensaje.Text = "<div class='alert alert-danger'>No se pudo eliminar el registro.</div>";
                }
            }
            catch (Exception ex)
            {
                litMensaje.Text = $"<div class='alert alert-danger'>Error: {ex.Message}</div>";
            }
            updPanelMascotas.Update();
        }

        // --- HELPERS VISUALES ---

        protected string GetIniciales(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre)) return "??";
            var partes = nombre.Trim().Split(' ');
            if (partes.Length >= 2) return (partes[0][0].ToString() + partes[1][0].ToString()).ToUpper();
            return partes[0].Substring(0, Math.Min(2, partes[0].Length)).ToUpper();
        }

        protected string GetAvatarColor(string nombre)
        {
            if (string.IsNullOrWhiteSpace(nombre)) return "#6c757d";
            string[] colores = { "#4a6fa5", "#f7a36c", "#904c77", "#5b8c5a", "#b04f4f" };
            return colores[Math.Abs(nombre.GetHashCode()) % colores.Length];
        }

        protected string GetIconoEspecie(string especie)
        {
            if (string.IsNullOrEmpty(especie)) return "fas fa-paw";
            string e = especie.Trim().ToLower();
            if (e == "perro") return "fas fa-dog";
            if (e == "gato") return "fas fa-cat";
            return "fas fa-paw";
        }

        protected void rptMascotas_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var m = (MascotaViewModel)e.Item.DataItem;

                var btnEditar = (LinkButton)e.Item.FindControl("btnEditar");
                var btnEliminar = (LinkButton)e.Item.FindControl("btnEliminar");
                var btnHistorial = (LinkButton)e.Item.FindControl("btnHistorial");

                if (btnEditar != null)
                {
                    btnEditar.Attributes["data-id"] = m.MascotaId.ToString();
                    btnEditar.Attributes["data-nombre"] = m.Nombre;
                    btnEditar.Attributes["data-clienteid"] = m.PersonaId.ToString();
                    btnEditar.Attributes["data-especie"] = m.Especie;
                    btnEditar.Attributes["data-raza"] = m.Raza;
                    btnEditar.Attributes["data-sexo"] = m.Sexo;
                    btnEditar.Attributes["data-color"] = m.Color;
                    btnEditar.Attributes["data-estado"] = m.Activo.ToString().ToLower();
                }
                if (btnEliminar != null)
                {
                    btnEliminar.Attributes["data-id"] = m.MascotaId.ToString();
                    btnEliminar.Attributes["data-nombre"] = m.Nombre;
                }
                if (btnHistorial != null)
                {
                    btnHistorial.Attributes["data-nombre"] = m.Nombre;
                }
            }
        }
    }
}