package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.servicios.ServicioDto;

/**
 *
 * @author User
 */
public interface ServicioDao extends DaoBase<ServicioDto> {

}
