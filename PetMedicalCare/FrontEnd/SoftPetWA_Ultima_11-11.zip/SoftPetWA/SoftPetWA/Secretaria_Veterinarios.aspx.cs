﻿// Nombre del archivo: Secretaria_Veterinarios.aspx.cs (Actualizado)
using SoftPetBusiness;
using SoftPetBussiness.SoftPetVeterinariosWS; // <-- Importar el proxy de WS
using System;
using System.Collections.Generic; // <-- Usar Listas Genéricas
using System.Data;
using System.Drawing; // Para colores de Avatar
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls; // Para Literal

namespace SoftPetWA
{
    public partial class Secretaria_Veterinarios : System.Web.UI.Page
    {
        private VeterinarioBO veterinarioBo;
        // private PersonaBo personaBo; // <-- Necesitarías esto para guardar Personas

        // --- ViewModel Interna para aplanar los DTOs ---
        // El Repeater se enlazará a esta clase, no al DTO anidado.
        private class VeterinarioViewModel
        {
            public int VeterinarioID { get; set; }
            public int PersonaID { get; set; }
            public string Nombre { get; set; }
            public string Email { get; set; }
            public string Iniciales { get; set; }
            public string AvatarColor { get; set; }
            public string TipoDocumento { get; set; }
            public string NumDocumento { get; set; }
            public DateTime FechaContratacion { get; set; }
            public string Especialidad { get; set; }
            public string Telefono { get; set; }
            public string Estado { get; set; }
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            this.veterinarioBo = new VeterinarioBO();
            // this.personaBo = new PersonaBo(); // <-- Inicializarías el BO de Persona aquí
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Ya no usamos ObtenerVeterinariosEjemplo()
                CargarFiltros();
                CargarVeterinarios();
            }
        }

        private void CargarFiltros()
        {
            // Cargar Tipos de Documento
            DataTable dtDoc = new DataTable();
            dtDoc.Columns.Add("Tipo", typeof(string));
            dtDoc.Rows.Add("DNI");
            dtDoc.Rows.Add("CE"); // Carnet de Extranjería
            ddlDocumento.DataSource = dtDoc;
            ddlDocumento.DataTextField = "Tipo";
            ddlDocumento.DataValueField = "Tipo";
            ddlDocumento.DataBind();

            // Cargar Especialidades
            DataTable dtEsp = new DataTable();
            dtEsp.Columns.Add("Nombre", typeof(string));
            dtEsp.Rows.Add("Todos");
            dtEsp.Rows.Add("Medicina General");
            dtEsp.Rows.Add("Cirugía");
            dtEsp.Rows.Add("Dermatología");
            dtEsp.Rows.Add("Animales Exóticos");

            ddlEspecialidad.DataSource = dtEsp;
            ddlEspecialidad.DataTextField = "Nombre";
            ddlEspecialidad.DataValueField = "Nombre";
            ddlEspecialidad.DataBind();

            // Cargar también el DropDownList del Modal
            var dtModalEsp = dtEsp.AsEnumerable().Where(r => r.Field<string>("Nombre") != "Todos").CopyToDataTable();
            ddlModalEspecialidad.DataSource = dtModalEsp;
            ddlModalEspecialidad.DataTextField = "Nombre";
            ddlModalEspecialidad.DataValueField = "Nombre";
            ddlModalEspecialidad.DataBind();
        }

        // --- MÉTODO MODIFICADO ---
        private void CargarVeterinarios()
        {
            IList<veterinarioDto> listaDto;

            // Consultar al BO (SOAP) o usar la caché de la Sesión
            if (Session["VeterinariosData"] == null)
            {
                listaDto = veterinarioBo.ListarTodos();
                Session["VeterinariosData"] = listaDto;
            }
            else
            {
                listaDto = Session["VeterinariosData"] as IList<veterinarioDto>;
            }

            if (listaDto == null)
            {
                listaDto = new List<veterinarioDto>(); // Evitar error si la lista es nula
            }

            // --- Proyección a ViewModel ---
            // Aplanamos el DTO anidado (veterinario.persona.nombre) a un ViewModel plano
            var bindingList = listaDto.Select(v => new VeterinarioViewModel
            {
                VeterinarioID = v.veterinarioId,
                PersonaID = v.persona.personaId,
                Nombre = v.persona.nombre,
                // Asumiendo que el proxy tiene la estructura anidada persona.usuario.email
                Email = v.persona.usuario?.correo ?? "N/A",
                Iniciales = v.persona.nombre.Length >= 2 ? (v.persona.nombre[0].ToString() + v.persona.nombre.Split(' ').Last()[0].ToString()).ToUpper() : "??",
                AvatarColor = GetAvatarColor(v.veterinarioId), // Helper para color
                TipoDocumento = v.persona.tipoDocumento,
                NumDocumento = v.persona.nroDocumento.ToString(),
                FechaContratacion = v.fechaContratacion,
                Especialidad = v.especialidad,
                Telefono = v.persona.telefono,
                // Mapeamos el bool 'activo' del DTO al string 'Estado' de la UI
                Estado = v.activo ? "Activo" : "Inactivo"
            }).ToList();


            // --- Lógica de Filtro (ahora sobre la lista) ---
            var query = bindingList.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                query = query.Where(v => v.Nombre.ToLower().Contains(txtNombre.Text.ToLower()));
            }
            if (!string.IsNullOrWhiteSpace(txtDocumento.Text))
            {
                query = query.Where(v => v.NumDocumento.Contains(txtDocumento.Text));
            }
            if (ddlEspecialidad.SelectedValue != "Todos")
            {
                query = query.Where(v => v.Especialidad == ddlEspecialidad.SelectedValue);
            }
            if (!string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                query = query.Where(v => v.Telefono.Contains(txtTelefono.Text));
            }

            var filteredList = query.ToList();

            rptVeterinarios.DataSource = filteredList;
            rptVeterinarios.DataBind();

            // Actualizar contadores
            litRegistrosTotales.Text = bindingList.Count.ToString();
            litRegistrosActuales.Text = $"{filteredList.Count}";
        }

        // Helper para el color del avatar
        private string GetAvatarColor(int id)
        {
            string[] colors = { "#007bff", "#28a745", "#ffc107", "#dc3545", "#17a2b8", "#6c757d" };
            return colors[id % colors.Length];
        }

        // --- Eventos de Botones (Filtros) ---
        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarVeterinarios();
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtDocumento.Text = "";
            txtTelefono.Text = "";
            ddlDocumento.SelectedIndex = 0;
            ddlEspecialidad.SelectedIndex = 0;
            CargarVeterinarios();
        }

        // --- Eventos de los Modals (Veterinario) ---

        // --- MÉTODO MODIFICADO ---
        protected void btnGuardarVeterinario_Click(object sender, EventArgs e)
        {
            litModalError.Text = ""; // Limpiar errores
            try
            {
                int veterinarioID = Convert.ToInt32(hdVeterinarioID.Value);
                int personaID = Convert.ToInt32(hdPersonaID.Value);

                // Datos comunes
                bool esActivo = ddlModalEstado.SelectedValue == "Activo";
                string fechaString = Convert.ToDateTime(txtModalFechaContratacion.Text).ToString("yyyy-MM-dd");
                string especialidad = ddlModalEspecialidad.SelectedValue;

                // El DTO (VeterinarioDto.java) tiene un Enum 'EstadoVeterinario'
                // El BO (VeterinarioBo.cs) pide un 'string estado'
                // Asumiremos que el string "DISPONIBLE" / "NO_DISPONIBLE" mapea al Enum
                string estadoEnumString = esActivo ? "DISPONIBLE" : "NO_DISPONIBLE";

                if (veterinarioID == 0)
                {
                    // --- CREAR NUEVO VETERINARIO ---
                    // NO PODEMOS INSERTAR. El modal permite crear una Persona,
                    // pero el VeterinarioBo.Insertar() requiere un 'personaId' existente.
                    // Se necesitaría un PersonaBo.Insertar() primero.
                    litModalError.Text = @"
                        <div class='alert alert-danger'>
                            <strong>Función no disponible.</strong><br/>
                            No se puede crear un nuevo Veterinario desde esta interfaz.
                            Se requiere crear una Persona primero, pero no se proporcionó un 'PersonaBo'.
                        </div>";
                }
                else
                {
                    // --- EDITAR VETERINARIO EXISTENTE ---

                    // 1. Modificar los datos del Veterinario (Esto sí funcionará)
                    veterinarioBo.Modificar(veterinarioID, personaID, fechaString, estadoEnumString, especialidad, esActivo);

                    // 2. Modificar los datos de la Persona (Esto NO funcionará)
                    // Para guardar Nombre, Email, Teléfono, etc., necesitaríamos:
                    // personaBo.Modificar(personaID, txtModalNombre.Text, ...);

                    litModalError.Text = @"
                        <div class='alert alert-warning'>
                            <strong>Aviso:</strong> Se guardaron los datos del veterinario (Fecha, Especialidad, Estado).<br/>
                            Los datos de la persona (Nombre, Email, Teléfono) no se pueden modificar desde aquí.
                        </div>";
                }

                // Recargar la data
                Session["VeterinariosData"] = null; // Limpiar caché
                CargarVeterinarios();
                updPanelVeterinarios.Update();
            }
            catch (Exception ex)
            {
                // Manejo básico de errores
                litModalError.Text = $"<div class='alert alert-danger'>Error: {ex.Message}</div>";
            }

            // Actualizar el panel del modal para mostrar el mensaje
            updModalVeterinario.Update();
        }

        // --- MÉTODO MODIFICADO ---
        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                int veterinarioID = Convert.ToInt32(hdVeterinarioIDEliminar.Value);

                // Llamada al BO SOAP
                veterinarioBo.Eliminar(veterinarioID);

                // Recargar la data
                Session["VeterinariosData"] = null; // Limpiar caché
                CargarVeterinarios();
                updPanelVeterinarios.Update();
            }
            catch (Exception ex)
            {
                // Manejo de error
                Console.Write(ex.Message);
                // (En una app real, mostrarías un mensaje al usuario)
            }
        }
    }
}