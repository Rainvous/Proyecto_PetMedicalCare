﻿// Nombre del archivo: Secretaria_ExpedienteDetalle.aspx.cs (NUEVA PÁGINA)
using System;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftPetWA
{
    public partial class Secretaria_ExpedienteDetalle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["id"] == null)
                {
                    Response.Redirect("Secretaria_Expedientes.aspx");
                    return;
                }

                int mascotaID = Convert.ToInt32(Request.QueryString["id"]);
                hdMascotaID.Value = mascotaID.ToString();

                // Cargar datos de prueba (simulando BD)
                CargarDatosSesionSiNoExisten();

                // Cargar la página
                CargarDatosMascota(mascotaID);
                CargarHistorialMedico(mascotaID);
            }
        }

        #region "Carga de Datos de Página"

        private void CargarDatosMascota(int mascotaID)
        {
            DataTable dtLista = Session["ExpedientesListaData"] as DataTable;
            if (dtLista == null) return;

            DataRow mascotaRow = dtLista.AsEnumerable().FirstOrDefault(r => r.Field<int>("MascotaID") == mascotaID);

            if (mascotaRow != null)
            {
                // Cargar Info de Mascota
                string avatarUrl = mascotaRow.Field<string>("Especie") == "Perro" ? "Images/Avatars/dog-avatar.png" : "Images/Avatars/cat-avatar.png";
                imgAvatarMascota.ImageUrl = avatarUrl; // Asegúrate de tener estas imágenes
                lblMascotaNombre.Text = mascotaRow.Field<string>("MascotaNombre");
                litNombreMascotaTitulo.Text = mascotaRow.Field<string>("MascotaNombre");
                lblMascotaRaza.Text = mascotaRow.Field<string>("EspecieRaza");
                lblCodigo.Text = $"M-{mascotaID:D6}";
                lblEdad.Text = mascotaRow.Field<string>("Edad");
                lblSexo.Text = mascotaRow.Field<string>("Sexo");
                lblColor.Text = mascotaRow.Field<string>("Color");
                lblPesoActual.Text = mascotaRow.Field<string>("Peso");
                lblEstado.Text = mascotaRow.Field<string>("Estado");
                lblEstado.CssClass = mascotaRow.Field<string>("Estado") == "Activo" ? "badge bg-success" : "badge bg-danger";

                // Datos del propietario
                lblPropietarioNombre.Text = mascotaRow.Field<string>("PropietarioNombre");
                lblPropietarioDNI.Text = "DNI: " + mascotaRow.Field<string>("Documento");
                lblPropietarioTelefono.Text = mascotaRow.Field<string>("Telefono");
                lblPropietarioEmail.Text = mascotaRow.Field<string>("Email");
            }
            else
            {
                // Si no se encuentra la mascota, redirigir
                Response.Redirect("Secretaria_Expedientes.aspx");
            }
        }

        private void CargarHistorialMedico(int mascotaID)
        {
            DataTable dtHistorial = Session["HistorialData"] as DataTable;
            if (dtHistorial == null) return;

            var query = dtHistorial.AsEnumerable()
                        .Where(r => r.Field<int>("MascotaID") == mascotaID)
                        .OrderByDescending(r => r.Field<DateTime>("Fecha"));

            DataTable dtFiltrado = dtHistorial.Clone();
            if (query.Any())
            {
                dtFiltrado = query.CopyToDataTable();
            }

            rptHistorialMedico.DataSource = dtFiltrado;
            rptHistorialMedico.DataBind();
        }

        #endregion

        #region "Lógica de Modals (Nueva Consulta, Ver/Editar)"

        protected void btnNuevaConsulta_Click(object sender, EventArgs e)
        {
            litModalConsultaNombreMascota.Text = lblMascotaNombre.Text;
            hdHistorialID.Value = "0"; // Es uno nuevo

            // Cargar Dropdowns
            CargarDropdownsModal(ddlModalConsultaVet, ddlModalConsultaServicio);

            // Limpiar campos
            txtModalConsultaMotivo.Text = "";
            txtModalConsultaDiagnostico.Text = "";
            txtModalConsultaPeso.Text = lblPesoActual.Text; // Tomar el peso actual
            txtModalConsultaTemp.Text = "";
            txtModalConsultaFrec.Text = "";

            // Actualizar y mostrar el modal
            updModalNuevaConsulta.Update();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showModalNuevaConsulta", "$('#modalNuevaConsulta').modal('show');", true);
        }

        protected void btnGuardarConsulta_Click(object sender, EventArgs e)
        {
            DataTable dtHistorial = Session["HistorialData"] as DataTable;
            if (dtHistorial == null) return;

            try
            {
                int mascotaID = Convert.ToInt32(hdMascotaID.Value);
                int newHistorialID = dtHistorial.Rows.Count > 0 ? dtHistorial.AsEnumerable().Max(row => row.Field<int>("HistorialID")) + 1 : 1;
                DateTime fechaConsulta = DateTime.Now;

                // Añadir la nueva consulta al historial
                dtHistorial.Rows.Add(
                    newHistorialID,
                    mascotaID,
                    "Consulta", // Tipo
                    fechaConsulta, // Fecha
                    fechaConsulta.ToString("dd 'de' MMMM, yyyy - hh:mm tt", new CultureInfo("es-ES")), // FechaHora
                    ddlModalConsultaServicio.SelectedItem.Text, // Titulo
                    ddlModalConsultaVet.SelectedItem.Text, // Doctor
                    txtModalConsultaDiagnostico.Text, // Diagnostico
                    txtModalConsultaMotivo.Text, // Motivo
                    "Tratamiento A", "Indicación A", // Receta 1 (Ejemplo)
                    null, null, // Receta 2 (null)
                    null, null, // Vacunación (null)
                    txtModalConsultaPeso.Text,
                    txtModalConsultaTemp.Text,
                    txtModalConsultaFrec.Text
                );

                Session["HistorialData"] = dtHistorial;

                // Refrescar el historial en la página
                CargarHistorialMedico(mascotaID);
                updPanelDetalle.Update();

                // Ocultar el modal
                ScriptManager.RegisterStartupScript(this, this.GetType(), "hideModalNuevaConsulta", "$('#modalNuevaConsulta').modal('hide');", true);
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }

        protected void rptHistorialMedico_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Imprimir")
            {
                // Lógica para imprimir
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertImprimir", "alert('Función de Imprimir no implementada.');", true);
                return;
            }

            int historialID = Convert.ToInt32(e.CommandArgument);
            hdHistorialID.Value = historialID.ToString(); // Guardar ID de historial

            DataTable dtHistorial = Session["HistorialData"] as DataTable;
            if (dtHistorial == null) return;

            DataRow historialRow = dtHistorial.AsEnumerable().FirstOrDefault(r => r.Field<int>("HistorialID") == historialID);
            if (historialRow == null) return;

            // Cargar Dropdowns
            CargarDropdownsModal(ddlModalVerVet, ddlModalVerServicio);

            // Cargar datos en el modal "Ver/Editar"
            try { ddlModalVerVet.SelectedValue = ddlModalVerVet.Items.FindByText(historialRow.Field<string>("Doctor")).Value; } catch { }
            try { ddlModalVerServicio.SelectedValue = ddlModalVerServicio.Items.FindByText(historialRow.Field<string>("Titulo")).Value; } catch { }

            txtModalVerMotivo.Text = historialRow.Field<string>("Motivo");
            txtModalVerDiagnostico.Text = historialRow.Field<string>("Diagnostico");
            txtModalVerPeso.Text = historialRow.Field<string>("Peso");
            txtModalVerTemp.Text = historialRow.Field<string>("Temperatura");
            txtModalVerFrec.Text = historialRow.Field<string>("Frecuencia");

            bool isReadOnly = (e.CommandName == "Ver");

            // Configurar modo (Ver o Editar)
            txtModalVerMotivo.ReadOnly = isReadOnly;
            txtModalVerDiagnostico.ReadOnly = isReadOnly;
            txtModalVerPeso.ReadOnly = isReadOnly;
            txtModalVerTemp.ReadOnly = isReadOnly;
            txtModalVerFrec.ReadOnly = isReadOnly;
            ddlModalVerVet.Enabled = !isReadOnly;
            ddlModalVerServicio.Enabled = !isReadOnly;
            btnGuardarEdicionConsulta.Visible = !isReadOnly;

            //if (isReadOnly)
            //    modalVerConsultaLabel.Text = "Detalle de Consulta";
            //else
            //    modalVerConsultaLabel.Text = "Editar Consulta";

            // Actualizar y mostrar modal
            updModalVerConsulta.Update();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "showModalVerConsulta", "$('#modalVerConsulta').modal('show');", true);
        }

        protected void btnGuardarEdicionConsulta_Click(object sender, EventArgs e)
        {
            DataTable dtHistorial = Session["HistorialData"] as DataTable;
            if (dtHistorial == null) return;

            try
            {
                int historialID = Convert.ToInt32(hdHistorialID.Value);
                DataRow row = dtHistorial.AsEnumerable().FirstOrDefault(r => r.Field<int>("HistorialID") == historialID);

                if (row != null)
                {
                    // Guardar cambios
                    row["Titulo"] = ddlModalVerServicio.SelectedItem.Text;
                    row["Doctor"] = ddlModalVerVet.SelectedItem.Text;
                    row["Diagnostico"] = txtModalVerDiagnostico.Text;
                    row["Motivo"] = txtModalVerMotivo.Text;
                    row["Peso"] = txtModalVerPeso.Text;
                    row["Temperatura"] = txtModalVerTemp.Text;
                    row["Frecuencia"] = txtModalVerFrec.Text;
                }

                Session["HistorialData"] = dtHistorial;

                // Refrescar el historial en la página
                CargarHistorialMedico(Convert.ToInt32(hdMascotaID.Value));
                updPanelDetalle.Update();

                // Ocultar el modal
                ScriptManager.RegisterStartupScript(this, this.GetType(), "hideModalVerConsulta", "$('#modalVerConsulta').modal('hide');", true);
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }

        #endregion

        #region "Datos de Prueba (Simulación BD)"

        // Carga los datos de prueba a la Sesión si no existen
        private void CargarDatosSesionSiNoExisten()
        {
            if (Session["ExpedientesListaData"] == null)
            {
                Session["ExpedientesListaData"] = ObtenerExpedientesListaEjemplo();
            }
            if (Session["HistorialData"] == null)
            {
                Session["HistorialData"] = ObtenerHistorialEjemploCompleto();
            }
            if (Session["VeterinariosData"] == null)
            {
                Session["VeterinariosData"] = ObtenerVeterinariosParaDropdown();
            }
            if (Session["ServiciosData"] == null)
            {
                Session["ServiciosData"] = ObtenerServiciosParaDropdown();
            }
        }

        private DataTable ObtenerExpedientesListaEjemplo()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MascotaID", typeof(int));
            dt.Columns.Add("MascotaNombre", typeof(string));
            dt.Columns.Add("Especie", typeof(string));
            dt.Columns.Add("EspecieRaza", typeof(string));
            dt.Columns.Add("AvatarCss", typeof(string));
            dt.Columns.Add("AvatarIcon", typeof(string));
            dt.Columns.Add("PropietarioNombre", typeof(string));
            dt.Columns.Add("Documento", typeof(string));
            dt.Columns.Add("Telefono", typeof(string));
            dt.Columns.Add("Email", typeof(string));
            dt.Columns.Add("UltimaVisita", typeof(DateTime));
            dt.Columns.Add("Edad", typeof(string));
            dt.Columns.Add("Sexo", typeof(string));
            dt.Columns.Add("Color", typeof(string));
            dt.Columns.Add("Peso", typeof(string));
            dt.Columns.Add("Estado", typeof(string));

            dt.Rows.Add(1, "Max", "Perro", "Golden Retriever", "avatar-perro", "fas fa-dog", "María González Pérez", "72458963", "987 654 321", "maria.gonzalez@email.com", new DateTime(2024, 10, 6), "3 años", "Macho", "Dorado", "32.5 kg", "Activo");
            dt.Rows.Add(2, "Luna", "Gato", "Siamés", "avatar-gato", "fas fa-cat", "Carlos Pérez Torres", "45789632", "956 321 478", "carlos.perez@email.com", new DateTime(2024, 9, 15), "2 años", "Hembra", "Blanco", "4.5 kg", "Activo");
            dt.Rows.Add(3, "Rocky", "Perro", "Bulldog", "avatar-perro", "fas fa-dog", "Ana Martínez López", "65478932", "912 345 678", "ana.martinez@email.com", new DateTime(2024, 10, 1), "5 años", "Macho", "Marrón", "28.0 kg", "Activo");

            return dt;
        }

        private DataTable ObtenerHistorialEjemploCompleto()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("HistorialID", typeof(int));
            dt.Columns.Add("MascotaID", typeof(int));
            dt.Columns.Add("Tipo", typeof(string));
            dt.Columns.Add("Fecha", typeof(DateTime));
            dt.Columns.Add("FechaHora", typeof(string));
            dt.Columns.Add("Titulo", typeof(string));
            dt.Columns.Add("Doctor", typeof(string));
            dt.Columns.Add("Diagnostico", typeof(string));
            dt.Columns.Add("Motivo", typeof(string));
            dt.Columns.Add("RecetaTitulo1", typeof(string));
            dt.Columns.Add("RecetaIndicacion1", typeof(string));
            dt.Columns.Add("RecetaTitulo2", typeof(string));
            dt.Columns.Add("RecetaIndicacion2", typeof(string));
            dt.Columns.Add("Procedimiento", typeof(string));
            dt.Columns.Add("Observaciones", typeof(string));
            dt.Columns.Add("Peso", typeof(string));
            dt.Columns.Add("Temperatura", typeof(string));
            dt.Columns.Add("Frecuencia", typeof(string));

            dt.Rows.Add(1, 1, "Consulta", new DateTime(2024, 10, 6, 8, 0, 0), "6 de Octubre, 2024 - 08:00 AM", "Consulta General", "Dr. García López", "Dermatitis alérgica leve", "Motivo: Control de rutina y revisión de piel.\nObservaciones: Paciente presenta enrojecimiento leve en zona abdominal.", "Cetirizina 10mg", "1 tableta cada 12 horas por 7 días", "Crema Hidrocortisona 1%", "Aplicar 2 veces al día en zona afectada", null, null, "32.5 kg", "38.5°C", "90 lpm");
            dt.Rows.Add(2, 1, "Vacunacion", new DateTime(2024, 9, 15, 10, 30, 0), "15 de Septiembre, 2024 - 10:30 AM", "Vacunación", "Dra. Martínez Ruiz", null, null, null, null, null, null, "Vacuna Antirrábica - Refuerzo Anual", "Paciente en buen estado general.", "31.8 kg", "38.2°C", "Normal");
            dt.Rows.Add(3, 2, "Vacunacion", new DateTime(2024, 9, 15, 11, 0, 0), "15 de Septiembre, 2024 - 11:00 AM", "Vacunación", "Dra. Martínez Ruiz", null, null, null, null, null, null, "Triple Felina - Refuerzo", "Sin complicaciones.", "4.5 kg", "38.8°C", "Normal");

            return dt;
        }

        private void CargarDropdownsModal(DropDownList ddlVet, DropDownList ddlServ)
        {
            ddlVet.DataSource = Session["VeterinariosData"];
            ddlVet.DataTextField = "Nombre";
            ddlVet.DataValueField = "VeterinarioID";
            ddlVet.DataBind();
            ddlVet.Items.Insert(0, new ListItem("-- Seleccione Veterinario --", "0"));

            ddlServ.DataSource = Session["ServiciosData"];
            ddlServ.DataTextField = "Nombre";
            ddlServ.DataValueField = "ServicioID";
            ddlServ.DataBind();
            ddlServ.Items.Insert(0, new ListItem("-- Seleccione Servicio --", "0"));
        }

        private DataTable ObtenerVeterinariosParaDropdown()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("VeterinarioID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Rows.Add(1, "Dr. García López");
            dt.Rows.Add(2, "Dra. Martínez Ruiz");
            return dt;
        }
        private DataTable ObtenerServiciosParaDropdown()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ServicioID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Rows.Add(1, "Consulta General");
            dt.Rows.Add(2, "Vacunación");
            dt.Rows.Add(3, "Control Postoperatorio");
            return dt;
        }

        #endregion
    }
}