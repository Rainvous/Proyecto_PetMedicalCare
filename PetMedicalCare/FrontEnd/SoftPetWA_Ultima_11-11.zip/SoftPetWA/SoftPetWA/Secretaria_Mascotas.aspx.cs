﻿// Nombre del archivo: Secretaria_Mascotas.aspx.cs (Actualizado)
using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoftPetWA
{
    public partial class Secretaria_Mascotas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Usamos Session para simular la persistencia de datos
                Session["ClientesData"] = ObtenerClientesEjemplo();
                Session["MascotasData"] = ObtenerMascotasEjemplo();

                CargarFiltros();
                CargarMascotas();
            }
        }

        private void CargarFiltros()
        {
            // Cargar Especies (ejemplo)
            DataTable dtEspecie = new DataTable();
            dtEspecie.Columns.Add("Nombre", typeof(string));
            dtEspecie.Rows.Add("Todas");
            dtEspecie.Rows.Add("Perro");
            dtEspecie.Rows.Add("Gato");
            dtEspecie.Rows.Add("Conejo");

            ddlEspecie.DataSource = dtEspecie;
            ddlEspecie.DataTextField = "Nombre";
            ddlEspecie.DataValueField = "Nombre";
            ddlEspecie.DataBind();

            // Cargar Dropdowns del Modal
            var dtEspeciesModal = dtEspecie.AsEnumerable().Where(r => r.Field<string>("Nombre") != "Todas").CopyToDataTable();
            ddlModalEspecie.DataSource = dtEspeciesModal;
            ddlModalEspecie.DataTextField = "Nombre";
            ddlModalEspecie.DataValueField = "Nombre";
            ddlModalEspecie.DataBind();

            ddlModalCliente.DataSource = Session["ClientesData"] as DataTable;
            ddlModalCliente.DataTextField = "Nombre";
            ddlModalCliente.DataValueField = "ClienteID";
            ddlModalCliente.DataBind();
        }

        private void CargarMascotas()
        {
            DataTable dtMascotas = Session["MascotasData"] as DataTable;
            DataTable dtClientes = Session["ClientesData"] as DataTable;

            if (dtMascotas == null || dtClientes == null) return;

            // Hacemos un "JOIN" en memoria usando LINQ para combinar los datos
            var mascotasQuery = from m in dtMascotas.AsEnumerable()
                                join c in dtClientes.AsEnumerable()
                                on m.Field<int>("ClienteID") equals c.Field<int>("ClienteID")
                                select new
                                {
                                    MascotaID = m.Field<int>("MascotaID"),
                                    NombreMascota = m.Field<string>("Nombre"),
                                    Especie = m.Field<string>("Especie"),
                                    Raza = m.Field<string>("Raza"),
                                    EspecieRaza = $"{m.Field<string>("Especie")} • {m.Field<string>("Raza")}",
                                    Sexo = m.Field<string>("Sexo"),
                                    Color = m.Field<string>("Color"),
                                    Estado = m.Field<string>("Estado"),
                                    CssEstado = m.Field<string>("Estado") == "Activo" ? "bg-success" : "bg-danger",
                                    ClienteID = c.Field<int>("ClienteID"),
                                    PropietarioNombre = c.Field<string>("Nombre"),
                                    PropietarioTelefono = c.Field<string>("Telefono"),
                                    PropietarioIniciales = c.Field<string>("Iniciales"),
                                    PropietarioAvatarColor = c.Field<string>("AvatarColor")
                                };

            // Aquí se aplicarían los filtros de búsqueda
            // ... (lógica de filtros omitida por brevedad) ...

            var listaMascotas = mascotasQuery.ToList();

            rptMascotas.DataSource = listaMascotas;
            rptMascotas.DataBind();

            // Actualizar contadores
            litRegistrosTotales.Text = listaMascotas.Count.ToString();
            litRegistrosActuales.Text = $"1-{listaMascotas.Count}";
        }

        private DataTable ObtenerMascotasEjemplo()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MascotaID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Columns.Add("Especie", typeof(string));
            dt.Columns.Add("Raza", typeof(string));
            dt.Columns.Add("Sexo", typeof(string));
            dt.Columns.Add("Color", typeof(string));
            dt.Columns.Add("Estado", typeof(string));
            dt.Columns.Add("ClienteID", typeof(int)); // Foreign Key

            dt.Rows.Add(1, "MAX", "Perro", "Labrador", "Macho", "Dorado", "Activo", 1);
            dt.Rows.Add(2, "LUNA", "Gato", "Persa", "Hembra", "Blanco", "Activo", 2);
            dt.Rows.Add(3, "ROCKY", "Perro", "Bulldog", "Macho", "Blanco/Marrón", "Activo", 3);
            dt.Rows.Add(4, "PELUSA", "Conejo", "Cabeza de León", "Hembra", "Gris", "Activo", 1);

            return dt;
        }

        private DataTable ObtenerClientesEjemplo()
        {
            // Esta función simula la tabla de Clientes
            DataTable dt = new DataTable();
            dt.Columns.Add("ClienteID", typeof(int));
            dt.Columns.Add("Nombre", typeof(string));
            dt.Columns.Add("Telefono", typeof(string));
            dt.Columns.Add("Iniciales", typeof(string));
            dt.Columns.Add("AvatarColor", typeof(string));

            dt.Rows.Add(1, "María González", "987 654 321", "MG", "#4a6fa5");
            dt.Rows.Add(2, "Carlos Pérez", "956 321 478", "CP", "#f7a36c");
            dt.Rows.Add(3, "Ana Martínez", "912 345 678", "AM", "#904c77");

            return dt;
        }

        // --- Eventos de Botones (Filtros) ---

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarMascotas(); // La lógica de filtro iría dentro de CargarMascotas
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombreMascota.Text = "";
            txtRaza.Text = "";
            txtPropietario.Text = "";
            ddlEspecie.SelectedIndex = 0;
            CargarMascotas();
        }

        // --- Eventos de los Modals (CRUD) ---

        protected void btnGuardarMascota_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["MascotasData"] as DataTable;
            if (dt == null) return;

            try
            {
                int mascotaID = Convert.ToInt32(hdMascotaID.Value);

                if (mascotaID == 0)
                {
                    // --- CREAR NUEVA MASCOTA ---
                    int newID = dt.Rows.Count > 0 ? dt.AsEnumerable().Max(row => row.Field<int>("MascotaID")) + 1 : 1;

                    dt.Rows.Add(
                        newID,
                        txtModalNombre.Text,
                        ddlModalEspecie.SelectedValue,
                        txtModalRaza.Text,
                        ddlModalSexo.SelectedValue,
                        txtModalColor.Text,
                        ddlModalEstado.SelectedValue,
                        Convert.ToInt32(ddlModalCliente.SelectedValue)
                    );
                }
                else
                {
                    // --- EDITAR MASCOTA EXISTENTE ---
                    DataRow row = dt.AsEnumerable().FirstOrDefault(r => r.Field<int>("MascotaID") == mascotaID);
                    if (row != null)
                    {
                        row["Nombre"] = txtModalNombre.Text;
                        row["Especie"] = ddlModalEspecie.SelectedValue;
                        row["Raza"] = txtModalRaza.Text;
                        row["Sexo"] = ddlModalSexo.SelectedValue;
                        row["Color"] = txtModalColor.Text;
                        row["Estado"] = ddlModalEstado.SelectedValue;
                        row["ClienteID"] = Convert.ToInt32(ddlModalCliente.SelectedValue);
                    }
                }

                Session["MascotasData"] = dt;
                CargarMascotas();
                updPanelMascotas.Update(); // Actualiza el repeater
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message); // Manejo de error simple
            }
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["MascotasData"] as DataTable;
            if (dt == null) return;

            try
            {
                int mascotaID = Convert.ToInt32(hdMascotaIDEliminar.Value);
                DataRow row = dt.AsEnumerable().FirstOrDefault(r => r.Field<int>("MascotaID") == mascotaID);

                if (row != null)
                {
                    dt.Rows.Remove(row);
                }

                Session["MascotasData"] = dt;
                CargarMascotas();
                updPanelMascotas.Update(); // Actualiza el repeater
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message); // Manejo de error simple
            }
        }
    }
}