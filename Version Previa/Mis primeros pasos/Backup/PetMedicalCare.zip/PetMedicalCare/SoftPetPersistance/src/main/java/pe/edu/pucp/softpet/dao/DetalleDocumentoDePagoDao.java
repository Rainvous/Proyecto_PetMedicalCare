package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.facturacion.DetalleDocumentoPagoDto;

/**
 *
 * @author marti
 */
public interface DetalleDocumentoDePagoDao extends DaoBase<DetalleDocumentoPagoDto> {
    
}
