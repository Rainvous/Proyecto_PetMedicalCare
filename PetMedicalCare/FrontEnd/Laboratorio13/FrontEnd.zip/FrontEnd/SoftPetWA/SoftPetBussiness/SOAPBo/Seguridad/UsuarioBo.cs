﻿using SoftPetBussiness.UsuarioClient;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class UsuarioBO
    {
        private UsuariosClient clienteSOAP;

        public UsuarioBO()
        {
            this.clienteSOAP = new UsuariosClient();
        }

        // Insertar usuario
        public int Insertar(string username, string password, string correo, bool activo)
        {
            return this.clienteSOAP.insertar(username, password, correo, activo);
        }

        // Modificar usuario
        public int Modificar(int usuarioId, string username, string password, string correo, bool activo)
        {
            return this.clienteSOAP.modificar(usuarioId, username, password, correo, activo);
        }

        // Eliminar usuario
        public int Eliminar(int usuarioId)
        {
            return this.clienteSOAP.eliminar(usuarioId);
        }

        // Obtener usuario por ID
        public usuarioDto ObtenerPorId(int usuarioId)
        {
            return this.clienteSOAP.obtenerPorId(usuarioId);
        }

        // Listar todos los usuarios
        public List<usuarioDto> ListarTodos()
        {
            return this.clienteSOAP.listarTodos().ToList<usuarioDto>();
        }

        // Insertar usando DTO
        public int Insertar(usuarioDto usuario)
        {
            return this.clienteSOAP.insertar(
                usuario.username,
                usuario.password,
                usuario.correo,
                usuario.activo
            );
        }

        // Modificar usando DTO
        public int Modificar(usuarioDto usuario)
        {

            return this.clienteSOAP.modificar(
                usuario.usuarioId,
                usuario.username,
                usuario.password,
                usuario.correo,
                usuario.activo
            );
        }
        public List<usuarioDto> ObtenerPorCorreoYContra(string correo, string contra)
        {
            // 1. Llama al servicio SOAP
            var respuestaSOAP = this.clienteSOAP.ObtenerPorCorreoYContra(correo, contra);

            // 2. Comprueba si la respuesta es nula
            if (respuestaSOAP == null)
            {
                // Si es nula, devuelve una LISTA VACÍA nueva
                return new List<usuarioDto>();
            }
            else
            {
                // Si no es nula, la convierte a lista
                return respuestaSOAP.ToList<usuarioDto>();
            }
        }
    }
}
