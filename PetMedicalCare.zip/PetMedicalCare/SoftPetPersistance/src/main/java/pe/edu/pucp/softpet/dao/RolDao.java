package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.usuarios.RolDto;

public interface RolDao extends DaoBase<RolDto> {
    
}
