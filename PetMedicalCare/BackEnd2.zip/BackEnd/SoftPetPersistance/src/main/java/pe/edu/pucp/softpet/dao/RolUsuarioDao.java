package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.usuarios.RolUsuarioDto;

public interface RolUsuarioDao extends DaoBase<RolUsuarioDto> {

}
