//package pe.edu.pucp.softpet.dao;
//
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;
//
//public class DetalleRecetaDaoTest {
//
////    public DetalleRecetaDaoTest() {
////    }
////
////    @Test
////    public void testSomeMethod() {
////        // TODO review the generated test code and remove the default call to fail.
////        fail("The test case is a prototype.");
////    }
//}
