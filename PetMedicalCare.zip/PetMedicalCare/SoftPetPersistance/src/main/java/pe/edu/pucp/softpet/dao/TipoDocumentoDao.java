package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.facturacion.TipoDocumentoDto;

/**
 *
 * @author marti
 */
public interface TipoDocumentoDao extends DaoBase<TipoDocumentoDto> {
    
}
