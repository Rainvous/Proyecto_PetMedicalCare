package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.productos.TipoProductoDto;

public interface TipoProductoDao extends DaoBase<TipoProductoDto> {

}
