package pe.edu.pucp.softpet.dto.util.enums;

public enum EstadoCita {
    PROGRAMADA,
    ATENDIDA,
    CANCELADA
}
