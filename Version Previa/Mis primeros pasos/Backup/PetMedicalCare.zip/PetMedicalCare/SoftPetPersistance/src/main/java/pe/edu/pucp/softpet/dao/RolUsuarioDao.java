package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.usuarios.RolUsuarioDto;

/**
 *
 * @author marti
 */
public interface RolUsuarioDao extends DaoBase<RolUsuarioDto> {
    
}
