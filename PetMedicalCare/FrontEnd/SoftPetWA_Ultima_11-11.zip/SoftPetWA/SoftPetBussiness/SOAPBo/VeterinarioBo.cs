﻿using SoftPetBussiness.SoftPetVeterinariosWS;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class VeterinarioBO
    {
        private VeterinariosClient clienteSOAP;

        public VeterinarioBO()
        {
            this.clienteSOAP = new VeterinariosClient();
        }

        // Insertar veterinario
        public int Insertar(int personaId, string fechaContratacion, string estado, string especialidad, bool activo)
        {
            return this.clienteSOAP.insertar_veterinario(personaId, fechaContratacion, estado, especialidad, activo);
        }

        // Modificar veterinario
        public int Modificar(int veterinarioId, int personaId, string fechaContratacion, string estado, string especialidad, bool activo)
        {
            return this.clienteSOAP.modificar_veterinario(veterinarioId, personaId, fechaContratacion, estado, especialidad, activo);
        }

        // Eliminar veterinario
        public int Eliminar(int veterinarioId)
        {
            return this.clienteSOAP.eliminar_veterinario(veterinarioId);
        }

        // Obtener veterinario por ID
        public veterinarioDto ObtenerPorId(int veterinarioId)
        {
            return this.clienteSOAP.obtenerPorId_veterinario(veterinarioId);
        }

        // Listar todos los veterinarios
        public List<veterinarioDto> ListarTodos()
        {
            return this.clienteSOAP.listar_veterinarios().ToList<veterinarioDto>();
        }

        // Insertar veterinario usando DTO
        public int Insertar(veterinarioDto veterinario)
        {
            return this.clienteSOAP.insertar_veterinario(
                veterinario.persona.personaId,
                veterinario.fechaContratacion.ToString(),
                veterinario.estado.ToString(),
                veterinario.especialidad,
                veterinario.activo
            );
        }

        // Modificar veterinario usando DTO
        public int Modificar(veterinarioDto veterinario)
        {
            return this.clienteSOAP.modificar_veterinario(
                veterinario.veterinarioId,
                veterinario.persona.personaId,
                veterinario.fechaContratacion.ToString(),
                veterinario.estado.ToString(),
                veterinario.especialidad,
                veterinario.activo
            );
        }
    }
}
