package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.recetas.DetalleRecetaDto;

/**
 *
 * @author marti
 */
public interface DetalleRecetaDao extends DaoBase<DetalleRecetaDto> {

}
