package pe.edu.pucp.softpet.bo;

import java.sql.Date;
import java.util.ArrayList;
import pe.edu.pucp.softpet.dao.MascotaDao;
import pe.edu.pucp.softpet.daoImp.MascotaDaoImpl;
import pe.edu.pucp.softpet.daoImp.PersonaDaoImpl;
import pe.edu.pucp.softpet.dto.mascotas.MascotaDto;
import pe.edu.pucp.softpet.dto.personas.PersonaDto;

public class MascotaBo {
    
    private final MascotaDaoImpl mascotaDao;

    public MascotaBo() {
        this.mascotaDao = new MascotaDaoImpl();
    }
    
    public Integer insertar(int personaId, String nombre, String especie, 
            String sexo, String raza, String color, String fechaDefuncion,
            boolean activo) {

        MascotaDto mascota = new MascotaDto();

        mascota.setPersona(new PersonaDaoImpl().obtenerPorId(personaId));
        mascota.setNombre(nombre);
        mascota.setEspecie(especie);
        mascota.setSexo(sexo);
        mascota.setRaza(raza);
        mascota.setColor(color);
        if(fechaDefuncion != null)mascota.setFechaDefuncion(Date.valueOf(fechaDefuncion));
        mascota.setActivo(activo);

        return this.mascotaDao.insertar(mascota);
    }

    public Integer modificar(int mascotaId, int personaId, String nombre, String especie, 
            String sexo, String raza, String color, String fechaDefuncion,
            boolean activo) {

        MascotaDto mascota = new MascotaDto();

        mascota.setMascotaId(mascotaId);
        mascota.setPersona(new PersonaDaoImpl().obtenerPorId(personaId));
        mascota.setNombre(nombre);
        mascota.setEspecie(especie);
        mascota.setSexo(sexo);
        mascota.setRaza(raza);
        mascota.setColor(color);
        mascota.setFechaDefuncion(Date.valueOf(fechaDefuncion));
        mascota.setActivo(activo);

        return this.mascotaDao.insertar(mascota);
    }

    public Integer eliminar(int mascotaId) {
        MascotaDto mascota = new MascotaDto();
        mascota.setMascotaId(mascotaId);
        return this.mascotaDao.eliminar(mascota);
    }

    public MascotaDto obtenerPorId(int mascotaId) {
        return this.mascotaDao.obtenerPorId(mascotaId);
    }

    public ArrayList<MascotaDto> listarTodos() {
        return this.mascotaDao.listarTodos();
    }
    
    public ArrayList<MascotaDto> ListasBusquedaAvanzada(String nombreMascota,
            String raza,String especie ,String nombreDeLaPersona){
        MascotaDto mascota = new MascotaDto();
        PersonaDto persona = new PersonaDto();
        mascota.setNombre(nombreMascota == null ? "" : nombreMascota);
        mascota.setRaza(raza == null ? "" : nombreMascota);
        mascota.setEspecie(especie== null ? "" : nombreMascota );
        persona.setNombre(nombreDeLaPersona== null ? "" : nombreMascota);
        mascota.setPersona(persona);
        
        return (ArrayList<MascotaDto>)mascotaDao.ListasBusquedaAvanzada(mascota);
    }
}
