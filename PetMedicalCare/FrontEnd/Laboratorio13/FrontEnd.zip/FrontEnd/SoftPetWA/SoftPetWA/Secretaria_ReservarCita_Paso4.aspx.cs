﻿// Nombre del archivo: Secretaria_ReservarCita_Paso4.aspx.cs (VERSIÓN CORREGIDA)
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI; // (NUEVO) Necesario para ScriptManager
using System.Web.UI.WebControls;

// Imports para los BOs
using SoftPetBusiness;
using SoftPetBussiness.CitaAtencionClient;
using SoftPetBussiness.DetalleServicioClient;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient;
using SoftPetBussiness.ServicioClient;
using SoftPetBussiness.VeterinarioClient;

// Alias para DTOs
using personaDto = SoftPetBussiness.PersonaClient.personaDto;
using mascotaDto = SoftPetBussiness.MascotaClient.mascotaDto;
using veterinarioDto = SoftPetBussiness.VeterinarioClient.veterinarioDto;
using servicioDto = SoftPetBussiness.ServicioClient.servicioDto;

namespace SoftPetWA
{
    public partial class Secretaria_ReservarCita_Paso4 : System.Web.UI.Page
    {
        // Instancias de los BOs
        private PersonaBO boPersona = new PersonaBO();
        private MascotaBO boMascota = new MascotaBO();
        private VeterinarioBO boVeterinario = new VeterinarioBO();
        private ServicioBO boServicio = new ServicioBO();
        private CitaAtencionBO boCitaAtencion = new CitaAtencionBO();
        private DetalleServicioBO boDetalleServicio = new DetalleServicioBO();

        // *** (MÉTODO PAGE_LOAD CORREGIDO) ***
        protected void Page_Load(object sender, EventArgs e)
        {
            // 1. Validar la sesión en CADA carga de página (PostBack o no)
            if (Session["FechaHoraInicio_Reserva"] == null ||
                Session["VeterinarioID_Reserva"] == null ||
                Session["ServiciosID_Reserva"] == null ||
                Session["MascotaID_Reserva"] == null ||
                Session["ClienteID_Reserva"] == null)
            {
                // Si falta algún dato clave, no podemos estar aquí.
                Response.Redirect("Secretaria_ReservarCita_Paso1.aspx");
                return;
            }

            // 2. Cargar el resumen en CADA carga de página.
            // Esto es crucial para que 'Session["MontoTotal_Reserva"]' exista
            // cuando se presione el botón "Confirmar" (que es un PostBack).
            CargarResumenConBOs();
        }

        // *** (MÉTODO ACTUALIZADO DE LA RESPUESTA ANTERIOR) ***
        private void CargarResumenConBOs()
        {
            CultureInfo culture = new CultureInfo("es-PE");

            try
            {
                // Obtener todos los IDs de la Sesión
                int clienteId = Convert.ToInt32(Session["ClienteID_Reserva"]);
                int mascotaId = Convert.ToInt32(Session["MascotaID_Reserva"]);
                int vetId = Convert.ToInt32(Session["VeterinarioID_Reserva"]);
                var serviciosIds = (List<int>)Session["ServiciosID_Reserva"];
                DateTime fechaHoraInicio = (DateTime)Session["FechaHoraInicio_Reserva"];

                // 1. Mostrar Cliente
                personaDto cliente = boPersona.ObtenerPorId(clienteId);
                lblClienteSeleccionado.Text = (cliente != null) ? cliente.nombre : "N/A";

                // 2. Mostrar Mascota
                mascotaDto mascota = boMascota.ObtenerPorId(mascotaId);
                lblMascotaSeleccionada.Text = (mascota != null) ? mascota.nombre : "N/A";

                // 3. Mostrar Veterinario
                veterinarioDto vet = boVeterinario.ObtenerPorId(vetId);
                if (vet != null)
                {
                    personaDto personaVet = boPersona.ObtenerPorId(vet.persona.personaId);
                    lblVeterinarioSeleccionado.Text = (personaVet != null) ? personaVet.nombre : "N/A";
                }

                // 4. Mostrar Fecha y Hora
                lblFechaSeleccionada.Text = fechaHoraInicio.ToString("dddd, dd 'de' MMMM yyyy", culture);
                lblHoraSeleccionada.Text = fechaHoraInicio.ToString("hh:mm tt", CultureInfo.InvariantCulture);

                // 5. Mostrar Servicios y Calcular Total
                double montoTotal = 0.0;
                List<object> serviciosVM = new List<object>();

                foreach (int servicioId in serviciosIds)
                {
                    servicioDto srv = boServicio.ObtenerPorId(servicioId);
                    if (srv != null)
                    {
                        serviciosVM.Add(new
                        {
                            NombrePrecio = $"{srv.nombre} ({srv.costo.ToString("C", culture)})"
                        });
                        montoTotal += srv.costo;
                    }
                }

                rptServiciosSeleccionados.DataSource = serviciosVM;
                rptServiciosSeleccionados.DataBind();

                // 6. Mostrar Total
                lblTotalAPagar.Text = montoTotal.ToString("C", culture);

                // 7. Guardar el total en sesión para usarlo al confirmar
                Session["MontoTotal_Reserva"] = montoTotal;
            }
            catch (Exception ex)
            {
                Response.Redirect("Secretaria_AgendaCitas.aspx");
            }
        }

        // *** (TU MÉTODO DE CLIC, AHORA FUNCIONAL) ***
        // *** (MÉTODO DE CLIC CORREGIDO CON SCRIPT MÁS ROBUSTO) ***
        // *** (MÉTODO DE CLIC CORREGIDO CON $(document).ready()) ***
        protected void btnConfirmarReserva_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Recolectar todos los datos de la Sesión
                int vetId = Convert.ToInt32(Session["VeterinarioID_Reserva"]);
                int mascotaId = Convert.ToInt32(Session["MascotaID_Reserva"]);
                var serviciosIds = (List<int>)Session["ServiciosID_Reserva"];
                DateTime fechaHoraInicio = (DateTime)Session["FechaHoraInicio_Reserva"];
                double montoTotal = Convert.ToDouble(Session["MontoTotal_Reserva"]);
                string notas = txtNotas.Text;

                // 2. Definir parámetros para la Cita
                DateTime fechaHoraFin = fechaHoraInicio.AddHours(1);
                double pesoMascota = 0.0;
                string estadoCita = "PROGRAMADA";
                bool activo = true;

                string fechaHoraInicioStr = fechaHoraInicio.ToString("yyyy-MM-dd HH:mm:ss");
                string fechaHoraFinStr = fechaHoraFin.ToString("yyyy-MM-dd HH:mm:ss");

                // 3. --- INSERTAR CITA PRINCIPAL ---
                int nuevaCitaId = boCitaAtencion.Insertar(
                    vetId,
                    mascotaId,
                    fechaHoraInicioStr,
                    fechaHoraFinStr,
                    pesoMascota,
                    montoTotal,
                    estadoCita,
                    notas,
                    activo
                );

                // 4. --- INSERTAR DETALLE DE SERVICIOS ---
                if (nuevaCitaId > 0)
                {
                    foreach (int servicioId in serviciosIds)
                    {
                        servicioDto srv = boServicio.ObtenerPorId(servicioId);
                        if (srv != null)
                        {
                            boDetalleServicio.Insertar(
                                nuevaCitaId,
                                servicioId,
                                srv.descripcion,
                                srv.costo,
                                activo
                            );
                        }
                    }
                }
                else
                {
                    throw new Exception("No se pudo crear la cita principal.");
                }

                // 5. Limpiar la Sesión de reserva
                Session.Remove("ClienteID_Reserva");
                Session.Remove("MascotaID_Reserva");
                Session.Remove("ServiciosID_Reserva");
                Session.Remove("VeterinarioID_Reserva");
                Session.Remove("Fecha_Reserva");
                Session.Remove("Hora_Reserva");
                Session.Remove("FechaHoraInicio_Reserva");
                Session.Remove("MontoTotal_Reserva");

                // 6. *** ¡LA FORMA MÁS ROBUSTA! ***
                // Envolvemos la llamada al modal en un $(document).ready()
                // para asegurar que JQuery y Bootstrap estén cargados.
                string script = "$(document).ready(function () { " +
                                "  $('#modalExito').modal('show'); " +
                                "});";

                // Usamos ScriptManager (como en tu ejemplo) para inyectar el script
                ScriptManager.RegisterStartupScript(
                    this,
                    this.GetType(),
                    "mostrarModalExito",
                    script,
                    true // <-- El 'true' envuelve el script en etiquetas <script>
                );
            }
            catch (Exception ex)
            {
                lblTotalAPagar.Text = "Error al guardar: " + ex.Message;
                btnConfirmarReserva.Enabled = false;
            }
        }

        protected void btnAnterior_Click(object sender, EventArgs e)
        {
            Response.Redirect("Secretaria_ReservarCita_Paso3.aspx");
        }
    }
}