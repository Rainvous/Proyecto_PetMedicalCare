package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.personas.PersonaDto;

public interface PersonaDao extends DaoBase<PersonaDto> {
    
}
