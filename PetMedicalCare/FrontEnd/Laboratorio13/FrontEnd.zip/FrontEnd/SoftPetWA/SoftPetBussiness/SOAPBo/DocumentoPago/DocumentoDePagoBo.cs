﻿using SoftPetBussiness.DetalleDocumentoDePagoClient;
using SoftPetBussiness.DocumentoDePagoClient; // Ajusta al namespace de tu Service Reference
using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class DocumentoDePagoBO
    {
        private DocumentosDePagoClient clienteSOAP;

        public DocumentoDePagoBO()
        {
            this.clienteSOAP = new DocumentosDePagoClient();
        }
        /*
         *  documentoPagoDto doc = new documentoPagoDto();
            doc.activo = activo;
            doc.estado = estado;
            doc.fechaEmision = fechaEmision;  //recomiendo NO usar este que es formato date 
            doc.igvTotal = igvTotal;
            doc.metodoDePagoId = metodoDePagoId;
            doc.numero = numero;
            doc.personaId = personaId;
            doc.serie = serie;
            doc.subtotal = subtotal;
            doc.total = total;
            doc.igvTotal = igvTotal;
            doc.tipoDocumento = tipoDocumento;
         * 
         * 
         * 
         * 
         * 
         * 
         */

        // ===================================================
        //  INSERTAR (MISMA FIRMA QUE EL SERVICIO EN JAVA)
        //  Java:
        //  insertar_Documento_De_Pago(int metodoDePagoId, int personaId,
        //                              String tipoDocumento, String serie,
        //                              String numero, String fechaEmision,
        //                              String estado, double subtotal,
        //                              double igvTotal, double total, boolean activo)
        // ===================================================
        public int Insertar(
            int metodoDePagoId,
            int personaId,
            string tipoDocumento,
            string serie,
            string numero,
            string fechaEmision, // Formato de fecha 2025-11-30 ; yyyy-MM-dd
            string estado,
            double subtotal,
            double igvTotal,
            double total,
            bool activo)
        {
            return this.clienteSOAP.insertar_Documento_De_Pago(
                metodoDePagoId,
                personaId,
                tipoDocumento,
                serie,
                numero,
                fechaEmision,
                estado,
                subtotal,
                igvTotal,
                total,
                activo
            );



        }

        // ===================================================
        //  MODIFICAR (MISMA FIRMA QUE EL SERVICIO EN JAVA)
        //  Java:
        //  modificar_Documento_De_Pago(int documentoPagoId, int metodoDePagoId,
        //                                int personaId, String tipoDocumento, String serie,
        //                                String numero, String fechaEmision, String estado,
        //                                double subtotal, double igvTotal, double total, boolean activo)
        // ===================================================
        public int Modificar(
            int documentoPagoId,
            int metodoDePagoId,
            int personaId,
            string tipoDocumento,
            string serie,
            string numero,
            string fechaEmision,
            string estado,
            double subtotal,
            double igvTotal,
            double total,
            bool activo)
        {
            return this.clienteSOAP.modificar_Documento_De_Pago(
                documentoPagoId,
                metodoDePagoId,
                personaId,
                tipoDocumento,
                serie,
                numero,
                fechaEmision,
                estado,
                subtotal,
                igvTotal,
                total,
                activo
            );
        }

        // =========================
        //        ELIMINAR
        // =========================
        public int Eliminar(int documentoPagoId)
        {
            return this.clienteSOAP.eliminar_Documento_De_Pago(documentoPagoId);
        }

        // =========================
        //      OBTENER POR ID
        // =========================
        public SoftPetBussiness.DocumentoDePagoClient.documentoPagoDto ObtenerPorId(int documentoPagoId)
        {
            return this.clienteSOAP.obtener_por_id(documentoPagoId);
        }

        // =========================
        //       LISTAR TODOS
        // =========================
        public List<SoftPetBussiness.DocumentoDePagoClient.documentoPagoDto> ListarTodos()
        {
            return this.clienteSOAP
                .listar_todos()
                .ToList<SoftPetBussiness.DocumentoDePagoClient.documentoPagoDto>();
        }
    }
}
