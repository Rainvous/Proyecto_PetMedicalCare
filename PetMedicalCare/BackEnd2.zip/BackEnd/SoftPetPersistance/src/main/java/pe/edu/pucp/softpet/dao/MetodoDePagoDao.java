package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.facturacion.MetodoDePagoDto;

public interface MetodoDePagoDao extends DaoBase<MetodoDePagoDto> {

}
