package pe.edu.pucp.softpet.model;

/**
 *
 * @author snipe
 */
public enum TipoSexo {
    MASCULINO, FEMENINO
}
