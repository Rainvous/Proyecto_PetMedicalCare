﻿using SoftPetBussiness.PersonaClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class PersonaBO
    {
        private PersonasClient clienteSOAP;

        public PersonaBO()
        {
            this.clienteSOAP = new PersonasClient();
        }

        // Insertar persona (parámetros sueltos)
        public int Insertar(int usuarioId, string nombre, string direccion, string telefono,
                            string sexo, int nroDocumento, int ruc, string tipoDocumento, bool activo)
        {
            return this.clienteSOAP.insertar_persona(
                usuarioId, nombre, direccion, telefono, sexo, nroDocumento, ruc, tipoDocumento, activo
            );
        }

        // Modificar persona (parámetros sueltos)
        public int Modificar(int personaId, int usuarioId, string nombre, string direccion, string telefono,
                             string sexo, int nroDocumento, int ruc, string tipoDocumento, bool activo)
        {
            return this.clienteSOAP.modificar_persona(
                personaId, usuarioId, nombre, direccion, telefono, sexo, nroDocumento, ruc, tipoDocumento, activo
            );
        }

        // Eliminar persona
        public int Eliminar(int personaId)
        {
            return this.clienteSOAP.eliminar_persona(personaId);
        }

        // Obtener persona por ID
        public personaDto ObtenerPorId(int personaId)
        {
            return this.clienteSOAP.obtenerPorId_persona(personaId);
        }

        // Listar todas las personas
        public List<personaDto> ListarTodos()
        {
            return this.clienteSOAP.listar_personas().ToList<personaDto>();
        }

        // Insertar persona usando DTO
        public int Insertar(personaDto persona)
        {
            return this.clienteSOAP.insertar_persona(
                persona.usuario.usuarioId,
                persona.nombre,
                persona.direccion,
                persona.telefono,
                persona.sexo.ToString(),          // si en el proxy es enum, usa persona.sexo.ToString()
                persona.nroDocumento,
                persona.ruc,
                persona.tipoDocumento,
                persona.activo
            );
        }

        // Modificar persona usando DTO
        public int Modificar(personaDto persona)
        {
            return this.clienteSOAP.modificar_persona(
                persona.personaId,
                persona.usuario.usuarioId,
                persona.nombre,
                persona.direccion,
                persona.telefono,
                persona.sexo.ToString(),          // si en el proxy es enum, usa persona.sexo.ToString()
                persona.nroDocumento,
                persona.ruc,
                persona.tipoDocumento,
                persona.activo
            );
        }

        public List<personaDto> ListarPersonasActivas()
        {
            return this.clienteSOAP.listar_personas_activas().ToList<personaDto>();
        }
        public List<personaDto> ListarPorNombreNroDocumentoRucTelefono(
            string nombre, string nroDocumento, string ruc, string telefono, bool activo)
        {

            return this.clienteSOAP.ListasBusquedaAvanzada(nombre,nroDocumento,ruc,telefono, activo).ToList<personaDto>();
        }

        public List<personaDto> ListarSoloClientes()
        {
            return this.clienteSOAP.ListasBusquedaAvanzadaParaCliente().ToList<personaDto>();
        }

    }
}
