﻿using SoftPetBussiness.ProductoClient;
using SoftPetBussiness.ServicioClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class ProductoBO
    {
        private ProductosClient clienteSOAP;

        public ProductoBO()
        {
            this.clienteSOAP = new ProductosClient();
        }

        // Insertar producto
        public int Insertar(int tipoProductoId, string nombre, string presentacion, double precioUnitario, int stock, bool activo)
        {
            return this.clienteSOAP.insertar_productos(tipoProductoId, nombre, presentacion, precioUnitario, stock, activo);
        }

        // Modificar producto
        public int Modificar(int productoId, int tipoProductoId, string nombre, string presentacion, double precioUnitario, int stock, bool activo)
        {
            return this.clienteSOAP.modificar_productos(productoId, tipoProductoId, nombre, presentacion, precioUnitario, stock, activo);
        }

        // Eliminar producto
        public int Eliminar(int productoId)
        {
            return this.clienteSOAP.eliminar_productos(productoId);
        }

        // Obtener producto por ID
        public productoDto ObtenerPorId(int productoId)
        {
            return this.clienteSOAP.obtener_por_id(productoId);
        }

        // Listar todos los productos
        public List<productoDto> ListarTodos()
        {
            return this.clienteSOAP.listar_todos().ToList<productoDto>();
        }

        // Insertar producto usando DTO
        public int Insertar(productoDto producto)
        {
            return this.clienteSOAP.insertar_productos(
                producto.tipoProducto.tipoProductoId,
                producto.nombre,
                producto.presentacion,
                producto.precioUnitario,
                producto.stock,
                producto.activo
            );
        }

        // Modificar producto usando DTO
        public int Modificar(productoDto producto)
        {
            return this.clienteSOAP.modificar_productos(
                producto.productoId,
                producto.tipoProducto.tipoProductoId,
                producto.nombre,
                producto.presentacion,
                producto.precioUnitario,
                producto.stock,
                producto.activo
            );
        }
        public List<productoDto> ListarActivos()
        {
            return this.clienteSOAP.listar_productos_activos().ToList<productoDto>();
        }

        public List<productoDto> ListarPorTipo(String nombreTipo)
        {
            return this.clienteSOAP.listar_productos_por_tipo(nombreTipo).ToList<productoDto>();
        }

        // Método para Búsqueda Avanzada (Nombre, Rango Precio, Estado)
        // Método para Búsqueda Avanzada (Nombre, Rango Precio, Estado)
        public List<productoDto> ListarBusquedaAvanzada(string nombre, string rango, string activo)
        {
            // Mapeo de valores nulos a vacíos para evitar errores en el WS
            nombre = nombre ?? "";
            rango = rango ?? "";
            activo = activo ?? "";

            // 1. Llamamos al servicio y guardamos la respuesta en una variable
            var respuesta = this.clienteSOAP.ListasBusquedaProductosAvanzada(nombre, rango, activo);

            // 2. FIX: Verificamos si es nulo antes de usar ToList()
            if (respuesta == null)
            {
                return new List<productoDto>(); // Retornamos lista vacía para que la grilla simplemente se vacíe
            }

            return respuesta.ToList<productoDto>();
        }
    }

}
