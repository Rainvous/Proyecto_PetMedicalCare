﻿using SoftPetBusiness;
using SoftPetBussiness.RecetaMedicaClient;
using SoftPetBussiness.CitaAtencionClient;
using SoftPetBussiness.MascotaClient;
using SoftPetBussiness.PersonaClient; // Necesario para el nombre del dueño
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using citaAtencionDto = SoftPetBussiness.CitaAtencionClient.citaAtencionDto;
using mascotaDto = SoftPetBussiness.MascotaClient.mascotaDto;

namespace SoftPetWA
{
    public partial class Veterinario_Recetas : System.Web.UI.Page
    {
        private RecetaMedicaBO boReceta = new RecetaMedicaBO();
        private CitaAtencionBO boCita = new CitaAtencionBO();
        private MascotaBO boMascota = new MascotaBO();
        private PersonaBO boPersona = new PersonaBO();

        // Paginación
        private const int PageSize = 5;
        public int CurrentPage
        {
            get { return (int)(ViewState["CurrentPage"] ?? 1); }
            set { ViewState["CurrentPage"] = value; }
        }

        // ViewModel: Representación plana de los datos para la grilla
        private class RecetaViewModel
        {
            public int RecetaID { get; set; }
            public string FechaEmision { get; set; }
            public string MascotaNombre { get; set; }
            public string PropietarioNombre { get; set; }
            public string DiagnosticoResumen { get; set; }
            public string EstadoTexto { get; set; }
            public string EstadoCss { get; set; }
            public DateTime FechaFiltro { get; set; }
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            // Inicialización de BOs ya hecha arriba
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CurrentPage = 1;
                CargarCombos();
                CargarRecetas();
            }
        }

        private void CargarCombos()
        {
            // Cargar Citas para el DropDown de "Nueva Receta"
            List<citaAtencionDto> citas = boCita.ListarTodos();
            // Filtramos idealmente citas recientes o del día, aquí traemos todas para demo

            // Necesitamos hidratar los nombres de las mascotas para el dropdown también
            List<mascotaDto> mascotas = boMascota.ListarTodos();
            var dicMascotas = mascotas.ToDictionary(m => m.mascotaId, m => m.nombre);

            var citasDisplay = citas.Select(c => new
            {
                Id = c.citaId,
                // Intentamos obtener el nombre de la mascota del diccionario
                Mascota = (c.mascota != null && dicMascotas.ContainsKey(c.mascota.mascotaId))
                          ? dicMascotas[c.mascota.mascotaId] : "Mascota ID " + c.mascota.mascotaId,
                Fecha = c.fechaRegistroStr
            }).OrderByDescending(x => x.Fecha).ToList();

            ddlModalCita.DataSource = citasDisplay.Select(x => new {
                Id = x.Id,
                Texto = $"{x.Fecha} - {x.Mascota}"
            });
            ddlModalCita.DataTextField = "Texto";
            ddlModalCita.DataValueField = "Id";
            ddlModalCita.DataBind();
            ddlModalCita.Items.Insert(0, new ListItem("-- Seleccione Cita --", "0"));
        }

        private void CargarRecetas()
        {
            // 1. TRAER TODOS LOS DATOS NECESARIOS (Estrategia de Hidratación en Memoria)
            List<recetaMedicaDto> listaRecetas = boReceta.ListarTodos();
            List<citaAtencionDto> listaCitas = boCita.ListarTodos();
            List<mascotaDto> listaMascotas = boMascota.ListarTodos();
            List<SoftPetBussiness.PersonaClient.personaDto> listaPersonas = boPersona.ListarTodos();

            if (listaRecetas == null) listaRecetas = new List<recetaMedicaDto>();

            // Diccionarios para búsqueda rápida O(1)
            var dicCitas = listaCitas?.ToDictionary(c => c.citaId) ?? new Dictionary<int, citaAtencionDto>();
            var dicMascotas = listaMascotas?.ToDictionary(m => m.mascotaId) ?? new Dictionary<int, mascotaDto>();
            var dicPersonas = listaPersonas?.ToDictionary(p => p.personaId) ?? new Dictionary<int, SoftPetBussiness.PersonaClient.personaDto>();

            var listaVM = new List<RecetaViewModel>();

            // 2. CONSTRUIR VIEWMODEL CRUZANDO DATOS
            foreach (var r in listaRecetas)
            {
                string nomMascota = "---";
                string nomProp = "---";

                // Paso 1: Obtener Cita
                if (r.cita != null && dicCitas.ContainsKey(r.cita.citaId))
                {
                    var citaReal = dicCitas[r.cita.citaId];

                    // Paso 2: Obtener Mascota desde la Cita
                    if (citaReal.mascota != null && dicMascotas.ContainsKey(citaReal.mascota.mascotaId))
                    {
                        var mascotaReal = dicMascotas[citaReal.mascota.mascotaId];
                        nomMascota = mascotaReal.nombre;

                        // Paso 3: Obtener Propietario desde la Mascota
                        if (mascotaReal.persona != null && dicPersonas.ContainsKey(mascotaReal.persona.personaId))
                        {
                            var personaReal = dicPersonas[mascotaReal.persona.personaId];
                            nomProp = personaReal.nombre;
                        }
                    }
                }

                // Lógica de Estado Visual
                bool vigente = (r.vigenciaHasta != null && r.vigenciaHasta >= DateTime.Now && r.activo);
                string estadoTexto = vigente ? "Vigente" : "Vencida";
                string estadoCss = vigente ? "badge rounded-pill bg-success-soft text-success" : "badge rounded-pill bg-danger-soft text-danger";

                // Resumen Diagnóstico
                string diag = r.diagnostico ?? "";
                if (diag.Length > 50) diag = diag.Substring(0, 47) + "...";

                listaVM.Add(new RecetaViewModel
                {
                    RecetaID = r.recetaMedicaId,
                    FechaEmision = r.fechaEmision.ToString("dd/MM/yyyy"),
                    FechaFiltro = r.fechaEmision,
                    MascotaNombre = nomMascota,
                    PropietarioNombre = nomProp,
                    DiagnosticoResumen = diag,
                    EstadoTexto = estadoTexto,
                    EstadoCss = estadoCss
                });
            }

            // 3. FILTROS
            var query = listaVM.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(txtMascota.Text))
                query = query.Where(x => x.MascotaNombre.ToLower().Contains(txtMascota.Text.Trim().ToLower()));

            if (!string.IsNullOrWhiteSpace(txtPropietario.Text))
                query = query.Where(x => x.PropietarioNombre.ToLower().Contains(txtPropietario.Text.Trim().ToLower()));

            if (!string.IsNullOrWhiteSpace(txtFechaDesde.Text) && DateTime.TryParse(txtFechaDesde.Text, out DateTime fIni))
                query = query.Where(x => x.FechaFiltro >= fIni);

            if (!string.IsNullOrWhiteSpace(txtFechaHasta.Text) && DateTime.TryParse(txtFechaHasta.Text, out DateTime fFin))
                query = query.Where(x => x.FechaFiltro <= fFin);

            var listaFiltrada = query.OrderByDescending(x => x.FechaFiltro).ToList();

            // 4. PAGINACIÓN
            int total = listaFiltrada.Count;
            litRegistrosTotales.Text = total.ToString();

            int inicio = (CurrentPage - 1) * PageSize;
            int fin = Math.Min(inicio + PageSize, total);
            litRegistrosActuales.Text = total == 0 ? "0" : $"{inicio + 1}-{fin}";

            rptRecetas.DataSource = listaFiltrada.Skip(inicio).Take(PageSize).ToList();
            rptRecetas.DataBind();

            GenerarPaginado(total);
        }

        private void GenerarPaginado(int totalRegistros)
        {
            int totalPages = (int)Math.Ceiling((double)totalRegistros / PageSize);
            lnkAnterior.Enabled = (CurrentPage > 1);
            lnkSiguiente.Enabled = (CurrentPage < totalPages);

            lnkAnterior.CssClass = lnkAnterior.Enabled ? "page-link" : "page-link disabled";
            lnkSiguiente.CssClass = lnkSiguiente.Enabled ? "page-link" : "page-link disabled";

            var paginas = new List<object>();
            if (totalPages > 1)
                for (int i = 1; i <= totalPages; i++) paginas.Add(new { Pagina = i, EsPaginaActual = (i == CurrentPage) });

            rptPaginador.DataSource = paginas;
            rptPaginador.DataBind();
        }

        // --- EVENTOS ---
        protected void btnBuscar_Click(object sender, EventArgs e) { CurrentPage = 1; CargarRecetas(); }
        protected void btnLimpiar_Click(object sender, EventArgs e) { txtMascota.Text = ""; txtPropietario.Text = ""; txtFechaDesde.Text = ""; txtFechaHasta.Text = ""; CurrentPage = 1; CargarRecetas(); }
        protected void lnkPaginado_Click(object sender, EventArgs e) { string cmd = ((LinkButton)sender).CommandName; if (cmd == "Anterior" && CurrentPage > 1) CurrentPage--; else if (cmd == "Siguiente") CurrentPage++; CargarRecetas(); }
        protected void rptPaginador_ItemCommand(object source, RepeaterCommandEventArgs e) { if (e.CommandName == "IrPagina") { CurrentPage = Convert.ToInt32(e.CommandArgument); CargarRecetas(); } }

        protected void btnNuevaReceta_Click(object sender, EventArgs e)
        {
            hdRecetaID.Value = "0";
            ddlModalCita.SelectedIndex = 0;
            txtModalDiagnostico.Text = "";
            txtModalObservaciones.Text = "";
            txtModalFechaEmision.Text = DateTime.Today.ToString("yyyy-MM-dd");
            txtModalVigencia.Text = DateTime.Today.AddDays(7).ToString("yyyy-MM-dd");
            ddlModalEstado.SelectedValue = "true";

            SetModalReadOnly(false);
            updModalReceta.Update();
            ScriptManager.RegisterStartupScript(this, GetType(), "ShowNew", "$('#modalRecetaLabel').text('Registrar Nueva Receta'); $('#modalReceta').modal('show');", true);
        }

        protected void rptRecetas_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int idReceta = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "Ver" || e.CommandName == "Editar")
            {
                var receta = boReceta.ObtenerPorId(idReceta);
                if (receta != null)
                {
                    hdRecetaID.Value = receta.recetaMedicaId.ToString();

                    try { ddlModalCita.SelectedValue = receta.cita.citaId.ToString(); } catch { }

                    txtModalDiagnostico.Text = receta.diagnostico;
                    txtModalObservaciones.Text = receta.observaciones;
                    txtModalFechaEmision.Text = receta.fechaEmision.ToString("yyyy-MM-dd");
                    txtModalVigencia.Text = receta.vigenciaHasta.ToString("yyyy-MM-dd");
                    ddlModalEstado.SelectedValue = receta.activo.ToString().ToLower();

                    bool esVer = (e.CommandName == "Ver");
                    SetModalReadOnly(esVer);

                    updModalReceta.Update();
                    string titulo = esVer ? "Detalle de Receta" : "Modificar Receta";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ShowModal", $"$('#modalRecetaLabel').text('{titulo}'); $('#modalReceta').modal('show');", true);
                }
            }
            // Imprimir puede quedar pendiente o usar lógica similar a Ver
        }

        protected void btnGuardarReceta_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(hdRecetaID.Value);
                int citaId = Convert.ToInt32(ddlModalCita.SelectedValue);
                if (citaId == 0) return;

                string diag = txtModalDiagnostico.Text;
                string obs = txtModalObservaciones.Text;
                string fEmision = txtModalFechaEmision.Text;
                string fVigencia = txtModalVigencia.Text;
                bool activo = bool.Parse(ddlModalEstado.SelectedValue);

                if (id == 0)
                    boReceta.Insertar(citaId, fEmision, fVigencia, diag, obs, activo);
                else
                    boReceta.Modificar(id, citaId, fEmision, fVigencia, diag, obs, activo);

                CargarRecetas();
                updPanelRecetas.Update();
                ScriptManager.RegisterStartupScript(this, GetType(), "HideModal", "$('#modalReceta').modal('hide');", true);
            }
            catch { }
        }

        private void SetModalReadOnly(bool readOnly)
        {
            ddlModalCita.Enabled = !readOnly;
            txtModalDiagnostico.ReadOnly = readOnly;
            txtModalObservaciones.ReadOnly = readOnly;
            txtModalFechaEmision.ReadOnly = readOnly;
            txtModalVigencia.ReadOnly = readOnly;
            ddlModalEstado.Enabled = !readOnly;
            btnGuardarReceta.Visible = !readOnly;
        }
    }
}