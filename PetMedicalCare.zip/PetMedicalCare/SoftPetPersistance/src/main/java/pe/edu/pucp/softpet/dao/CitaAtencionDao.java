package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.citas.CitaAtencionDto;

/**
 *
 * @author marti
 */
public interface CitaAtencionDao extends DaoBase<CitaAtencionDto> {
    
}
