﻿using SoftPetBusiness;
using SoftPetBussiness.VeterinarioClient;
using SoftPetBussiness.PersonaClient;
using SoftPetBussiness.UsuarioClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using usuarioDto = SoftPetBussiness.UsuarioClient.usuarioDto;
using personaDto = SoftPetBussiness.PersonaClient.personaDto;

namespace SoftPetWA
{
    public partial class Secretaria_Veterinarios : System.Web.UI.Page
    {
        private VeterinarioBO veterinarioBo;
        private PersonaBO personaBo;
        private UsuarioBO usuarioBo;
        private RolUsuarioBO rolUsuarioBo;

        private const int ID_ROL_VETERINARIO = 2;
        private const int PageSize = 7;

        public int CurrentPage
        {
            get { return (int)(ViewState["CurrentPage"] ?? 1); }
            set { ViewState["CurrentPage"] = value; }
        }

        private class VeterinarioViewModel
        {
            public int VeterinarioID { get; set; }
            public int PersonaID { get; set; }
            public string Nombre { get; set; }
            public string Email { get; set; }
            public string Iniciales { get; set; }
            public string AvatarColor { get; set; }
            public string TipoDocumento { get; set; }
            public string NumDocumento { get; set; }
            public DateTime FechaContratacion { get; set; }
            public string Especialidad { get; set; }
            public string Telefono { get; set; }
            public string Estado { get; set; }
            public string RUC { get; set; }
            public string Direccion { get; set; }
            public string Sexo { get; set; }
        }

        protected void Page_Init(object sender, EventArgs e)
        {
            this.veterinarioBo = new VeterinarioBO();
            this.personaBo = new PersonaBO();
            this.usuarioBo = new UsuarioBO();
            this.rolUsuarioBo = new RolUsuarioBO();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CurrentPage = 1;
                CargarFiltros();
                CargarVeterinarios(null, null, null, null);
            }
        }

        private void CargarFiltros()
        {
            DataTable dtDoc = new DataTable();
            dtDoc.Columns.Add("Tipo", typeof(string));
            dtDoc.Rows.Add("DNI"); dtDoc.Rows.Add("CE");
            ddlDocumento.DataSource = dtDoc; ddlDocumento.DataTextField = "Tipo"; ddlDocumento.DataValueField = "Tipo"; ddlDocumento.DataBind();
            ddlModalTipoDoc.DataSource = dtDoc; ddlModalTipoDoc.DataTextField = "Tipo"; ddlModalTipoDoc.DataValueField = "Tipo"; ddlModalTipoDoc.DataBind();

            DataTable dtEsp = new DataTable();
            dtEsp.Columns.Add("Nombre", typeof(string));
            dtEsp.Rows.Add("Todos"); dtEsp.Rows.Add("Medicina General"); dtEsp.Rows.Add("Cirugía"); dtEsp.Rows.Add("Dermatología"); dtEsp.Rows.Add("Animales Exóticos");
            ddlEspecialidad.DataSource = dtEsp; ddlEspecialidad.DataTextField = "Nombre"; ddlEspecialidad.DataValueField = "Nombre"; ddlEspecialidad.DataBind();

            var dtModalEsp = dtEsp.AsEnumerable().Where(r => r.Field<string>("Nombre") != "Todos").CopyToDataTable();
            ddlModalEspecialidad.DataSource = dtModalEsp; ddlModalEspecialidad.DataTextField = "Nombre"; ddlModalEspecialidad.DataValueField = "Nombre"; ddlModalEspecialidad.DataBind();
        }

        // =================================================================
        // MÉTODO DE CARGA OPTIMIZADO (Usa SP en BD)
        // =================================================================
        private void CargarVeterinarios(string nombre, string numDoc, string especialidad, string telefono)
        {
            // 1. LLAMADA AL BACKEND (La búsqueda real sucede aquí)
            IList<veterinarioDto> listaVets = veterinarioBo.ListarBusquedaAvanzada(nombre, numDoc, especialidad, telefono);

            if (listaVets == null) listaVets = new List<veterinarioDto>();

            // 2. Listas auxiliares para hidratar (Nombres y Emails)
            // Como el DTO del search puede venir incompleto (solo IDs), cruzamos con los maestros en memoria
            IList<personaDto> listaPersonas = personaBo.ListarTodos();
            IList<usuarioDto> listaUsuarios = usuarioBo.ListarTodos();
            if (listaPersonas == null) listaPersonas = new List<personaDto>();
            if (listaUsuarios == null) listaUsuarios = new List<usuarioDto>();

            var dicPersonas = listaPersonas.ToDictionary(p => p.personaId);
            var dicUsuarios = listaUsuarios.ToDictionary(u => u.usuarioId);

            // 3. Mapeo a ViewModel
            var bindingList = listaVets.Select(v =>
            {
                personaDto personaReal = null;
                usuarioDto usuarioReal = null;

                // Buscamos la persona completa
                if (v.persona != null && dicPersonas.ContainsKey(v.persona.personaId))
                {
                    personaReal = dicPersonas[v.persona.personaId];
                    // Buscamos el usuario completo
                    if (personaReal.usuario != null && dicUsuarios.ContainsKey(personaReal.usuario.usuarioId))
                    {
                        usuarioReal = dicUsuarios[personaReal.usuario.usuarioId];
                    }
                }

                string nombreShow = (personaReal != null) ? personaReal.nombre : "Desc.";

                return new VeterinarioViewModel
                {
                    VeterinarioID = v.veterinarioId,
                    PersonaID = v.persona.personaId,
                    Nombre = nombreShow,
                    Email = (usuarioReal != null) ? usuarioReal.correo : "Sin Email",
                    Iniciales = ObternerIniciales(nombreShow),
                    AvatarColor = GetAvatarColor(v.veterinarioId),
                    TipoDocumento = (personaReal != null) ? personaReal.tipoDocumento : "",
                    NumDocumento = (personaReal != null) ? personaReal.nroDocumento.ToString() : "",
                    FechaContratacion = v.fechaContratacion,
                    Especialidad = v.especialidad,
                    Telefono = (personaReal != null) ? personaReal.telefono : "",
                    Estado = v.activo ? "Activo" : "Inactivo",
                    RUC = (personaReal != null && personaReal.ruc != 0) ? personaReal.ruc.ToString() : "",
                    Direccion = (personaReal != null) ? personaReal.direccion : "",
                    Sexo = (personaReal != null) ? personaReal.sexo.ToString() : "O"
                };
            }).ToList();

            // NOTA: Ya no hacemos filtrado con .Where() aquí porque la BD ya nos dio los resultados filtrados

            // 4. Paginación
            int totalRegistros = bindingList.Count;
            int inicio = (CurrentPage - 1) * PageSize + 1;
            int fin = Math.Min(CurrentPage * PageSize, totalRegistros);
            if (fin == 0) inicio = 0;

            litRegistrosActuales.Text = $"{inicio}-{fin}";
            litRegistrosTotales.Text = totalRegistros.ToString();

            rptVeterinarios.DataSource = bindingList.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();
            rptVeterinarios.DataBind();

            GenerarPaginado(totalRegistros);
        }

        private void GenerarPaginado(int totalRegistros)
        {
            int totalPages = (int)Math.Ceiling((double)totalRegistros / PageSize);
            lnkAnterior.Enabled = (CurrentPage > 1);
            lnkSiguiente.Enabled = (CurrentPage < totalPages);
            lnkAnterior.CssClass = lnkAnterior.Enabled ? "page-link" : "page-link disabled";
            lnkSiguiente.CssClass = lnkSiguiente.Enabled ? "page-link" : "page-link disabled";

            var paginas = new List<object>();
            if (totalPages > 1) for (int i = 1; i <= totalPages; i++) paginas.Add(new { Pagina = i, EsPaginaActual = (i == CurrentPage) });
            rptPaginador.DataSource = paginas; rptPaginador.DataBind();
        }

        // --- Eventos UI ---
        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            CurrentPage = 1;
            CargarVeterinarios(txtNombre.Text, txtDocumento.Text, ddlEspecialidad.SelectedValue, txtTelefono.Text);
        }
        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Text = ""; txtDocumento.Text = ""; txtTelefono.Text = "";
            ddlDocumento.SelectedIndex = 0; ddlEspecialidad.SelectedIndex = 0;
            CurrentPage = 1;
            CargarVeterinarios(null, null, null, null);
        }
        protected void lnkPaginado_Click(object sender, EventArgs e) { string cmd = ((LinkButton)sender).CommandName; if (cmd == "Anterior" && CurrentPage > 1) CurrentPage--; else if (cmd == "Siguiente") CurrentPage++; CargarVeterinarios(txtNombre.Text, txtDocumento.Text, ddlEspecialidad.SelectedValue, txtTelefono.Text); }
        protected void rptPaginador_ItemCommand(object source, RepeaterCommandEventArgs e) { if (e.CommandName == "IrPagina") { CurrentPage = Convert.ToInt32(e.CommandArgument); CargarVeterinarios(txtNombre.Text, txtDocumento.Text, ddlEspecialidad.SelectedValue, txtTelefono.Text); } }

        // ... (El resto de métodos: Helpers, btnNuevo, btnGuardar, ItemCommand se mantienen IGUALES) ...
        private string ObternerIniciales(string nombre) { if (string.IsNullOrEmpty(nombre)) return "??"; var partes = nombre.Trim().Split(' '); if (partes.Length == 1 && partes[0].Length > 0) return partes[0].Substring(0, Math.Min(2, partes[0].Length)).ToUpper(); if (partes.Length > 1) return (partes[0][0].ToString() + partes.Last()[0].ToString()).ToUpper(); return "??"; }
        private string GetAvatarColor(int id) { string[] colors = { "#007bff", "#28a745", "#ffc107", "#dc3545", "#17a2b8", "#6c757d" }; return colors[Math.Abs(id) % colors.Length]; }

        protected void btnNuevoVeterinario_Click(object sender, EventArgs e)
        {
            hdVeterinarioID.Value = "0"; hdPersonaID.Value = "0"; hdTempUsuarioID.Value = "0";
            txtModalNombre.Text = ""; txtModalEmail.Text = ""; txtModalUsuario.Text = ""; txtModalTelefono.Text = "";
            ddlModalTipoDoc.SelectedValue = "DNI"; txtModalNumDoc.Text = ""; txtModalRUC.Text = ""; txtModalDireccion.Text = "";
            ddlModalSexo.SelectedValue = "O"; txtModalRol.Text = "Veterinario";
            txtModalFechaContratacion.Text = DateTime.Today.ToString("yyyy-MM-dd");
            ddlModalEspecialidad.SelectedIndex = 0; ddlModalEstado.SelectedValue = "Activo"; ddlModalEstadoLaboral.SelectedValue = "ACTIVO";
            txtModalPassword.Attributes.Remove("value"); txtModalPassword.Text = ""; litModalError.Text = "";
            SetModalReadOnly(false); updModalVeterinario.Update();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowModalNuevo", "$('#modalVeterinarioLabel').text('Registrar Nuevo Veterinario'); $('#modalVeterinario').modal('show');", true);
        }

        protected void btnGuardarVeterinario_Click(object sender, EventArgs e)
        {
            // ... (Código idéntico a la versión transaccional anterior) ...
            litModalError.Text = ""; int idUsuarioCreado = 0; int idRolUsuarioCreado = 0; int idPersonaCreada = 0;
            try
            {
                if (string.IsNullOrWhiteSpace(txtModalNombre.Text) || string.IsNullOrWhiteSpace(txtModalEmail.Text) || string.IsNullOrWhiteSpace(txtModalUsuario.Text) || string.IsNullOrWhiteSpace(txtModalNumDoc.Text)) { litModalError.Text = "<div class='alert alert-danger'>Campos obligatorios vacíos.</div>"; updModalVeterinario.Update(); return; }
                int nroDocumento; if (!int.TryParse(txtModalNumDoc.Text, out nroDocumento)) { litModalError.Text = "<div class='alert alert-danger'>DNI numérico inválido.</div>"; updModalVeterinario.Update(); return; }
                int ruc = 0; if (!string.IsNullOrWhiteSpace(txtModalRUC.Text)) int.TryParse(txtModalRUC.Text, out ruc);

                int veterinarioID = Convert.ToInt32(hdVeterinarioID.Value); int personaID = Convert.ToInt32(hdPersonaID.Value);
                string nombre = txtModalNombre.Text; string email = txtModalEmail.Text; string usuario = txtModalUsuario.Text;
                string telefono = txtModalTelefono.Text; string tipoDoc = ddlModalTipoDoc.SelectedValue; string direccion = txtModalDireccion.Text;
                string sexo = ddlModalSexo.SelectedValue; string passInput = txtModalPassword.Text;
                bool esActivo = ddlModalEstado.SelectedValue == "Activo";
                string fechaString = Convert.ToDateTime(txtModalFechaContratacion.Text).ToString("yyyy-MM-dd");
                string especialidad = ddlModalEspecialidad.SelectedValue;
                string estadoEnum = ddlModalEstadoLaboral.SelectedValue.ToUpper();

                if (veterinarioID == 0)
                {
                    if (string.IsNullOrWhiteSpace(passInput)) { litModalError.Text = "<div class='alert alert-danger'>Contraseña obligatoria.</div>"; updModalVeterinario.Update(); return; }
                    idUsuarioCreado = usuarioBo.Insertar(usuario, passInput, email, esActivo);
                    if (idUsuarioCreado <= 0) { litModalError.Text = "<div class='alert alert-danger'>Error al crear Usuario.</div>"; updModalVeterinario.Update(); return; }
                    idRolUsuarioCreado = rolUsuarioBo.Insertar(ID_ROL_VETERINARIO, idUsuarioCreado, true); // ID 2
                    if (idRolUsuarioCreado <= 0) { usuarioBo.Eliminar(idUsuarioCreado); litModalError.Text = "<div class='alert alert-danger'>Error al asignar Rol.</div>"; updModalVeterinario.Update(); return; }
                    idPersonaCreada = personaBo.Insertar(idUsuarioCreado, nombre, direccion, telefono, sexo, nroDocumento, ruc, tipoDoc, esActivo);
                    if (idPersonaCreada <= 0) { rolUsuarioBo.Eliminar(idRolUsuarioCreado); usuarioBo.Eliminar(idUsuarioCreado); litModalError.Text = "<div class='alert alert-danger'>Error al crear Persona.</div>"; updModalVeterinario.Update(); return; }
                    int newVetID = veterinarioBo.Insertar(idPersonaCreada, fechaString, estadoEnum, especialidad, esActivo);
                    if (newVetID > 0) { litModalError.Text = "<div class='alert alert-success'>Veterinario creado.</div>"; Response.Redirect("Secretaria_Veterinarios.aspx"); }
                    else { personaBo.Eliminar(idPersonaCreada); rolUsuarioBo.Eliminar(idRolUsuarioCreado); usuarioBo.Eliminar(idUsuarioCreado); litModalError.Text = "<div class='alert alert-danger'>Error al crear Veterinario.</div>"; updModalVeterinario.Update(); }
                }
                else
                {
                    personaDto perAntigua = personaBo.ObtenerPorId(personaID); int usuarioID = perAntigua.usuario.usuarioId; usuarioDto usuAntiguo = usuarioBo.ObtenerPorId(usuarioID);
                    string finalPass = usuAntiguo.password; if (!string.IsNullOrEmpty(passInput) && passInput != "**********") finalPass = passInput;
                    usuarioBo.Modificar(usuarioID, usuario, finalPass, email, esActivo); personaBo.Modificar(personaID, usuarioID, nombre, direccion, telefono, sexo, nroDocumento, ruc, tipoDoc, esActivo);
                    veterinarioBo.Modificar(veterinarioID, personaID, fechaString, estadoEnum, especialidad, esActivo);
                    litModalError.Text = "<div class='alert alert-success'>Modificado correctamente.</div>"; Response.Redirect("Secretaria_Veterinarios.aspx");
                }
            }
            catch (Exception ex) { if (idPersonaCreada > 0) personaBo.Eliminar(idPersonaCreada); if (idRolUsuarioCreado > 0) rolUsuarioBo.Eliminar(idRolUsuarioCreado); if (idUsuarioCreado > 0) usuarioBo.Eliminar(idUsuarioCreado); litModalError.Text = $"<div class='alert alert-danger'>Error: {ex.Message}</div>"; updModalVeterinario.Update(); }
        }

        protected void btnConfirmarEliminar_Click(object sender, EventArgs e)
        {
            try { int veterinarioID = Convert.ToInt32(hdVeterinarioIDEliminar.Value); veterinarioDto vet = veterinarioBo.ObtenerPorId(veterinarioID); if (vet != null) { veterinarioBo.Eliminar(veterinarioID); personaBo.Eliminar(vet.persona.personaId); CargarVeterinarios(null, null, null, null); updPanelVeterinarios.Update(); } } catch (Exception ex) { ScriptManager.RegisterStartupScript(this, this.GetType(), "Error", $"alert('{ex.Message}');", true); }
        }

        protected void rptVeterinarios_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int veterinarioID = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "Ver" || e.CommandName == "Editar")
            {
                try
                {
                    veterinarioDto vet = veterinarioBo.ObtenerPorId(veterinarioID);
                    if (vet != null)
                    {
                        personaDto per = personaBo.ObtenerPorId(vet.persona.personaId);
                        usuarioDto usu = usuarioBo.ObtenerPorId(per.usuario.usuarioId);
                        hdVeterinarioID.Value = vet.veterinarioId.ToString(); hdPersonaID.Value = vet.persona.personaId.ToString();
                        txtModalNombre.Text = per.nombre; txtModalEmail.Text = (usu != null) ? usu.correo : ""; txtModalUsuario.Text = (usu != null) ? usu.username : ""; txtModalRol.Text = "Veterinario"; txtModalTelefono.Text = per.telefono;
                        ddlModalTipoDoc.SelectedValue = per.tipoDocumento; txtModalNumDoc.Text = per.nroDocumento.ToString(); txtModalRUC.Text = (per.ruc != 0) ? per.ruc.ToString() : ""; txtModalDireccion.Text = per.direccion;
                        ddlModalSexo.SelectedValue = per.sexo.ToString(); txtModalPassword.Attributes.Add("value", "**********"); txtModalPassword.Text = "**********";
                        txtModalFechaContratacion.Text = vet.fechaContratacion.ToString("yyyy-MM-dd"); ddlModalEspecialidad.SelectedValue = vet.especialidad; ddlModalEstado.SelectedValue = vet.activo ? "Activo" : "Inactivo";
                        try { if (vet.estado != null) ddlModalEstadoLaboral.SelectedValue = vet.estado.ToString(); } catch { }
                        litModalError.Text = ""; bool esSoloLectura = (e.CommandName == "Ver"); SetModalReadOnly(esSoloLectura); updModalVeterinario.Update();
                        string titulo = esSoloLectura ? "Ver Detalles del Veterinario" : "Modificar Veterinario"; ScriptManager.RegisterStartupScript(this, this.GetType(), "ShowModalVet", $"$('#modalVeterinarioLabel').text('{titulo}'); $('#modalVeterinario').modal('show');", true);
                    }
                }
                catch (Exception ex) { litModalError.Text = $"<div class='alert alert-danger'>Error: {ex.Message}</div>"; updModalVeterinario.Update(); }
            }
        }

        private void SetModalReadOnly(bool readOnly)
        {
            txtModalNombre.ReadOnly = readOnly; txtModalEmail.ReadOnly = readOnly; txtModalUsuario.ReadOnly = readOnly; txtModalTelefono.ReadOnly = readOnly; ddlModalTipoDoc.Enabled = !readOnly; txtModalNumDoc.ReadOnly = readOnly; txtModalRUC.ReadOnly = readOnly; txtModalDireccion.ReadOnly = readOnly; ddlModalSexo.Enabled = !readOnly; txtModalPassword.ReadOnly = readOnly; txtModalRol.ReadOnly = true; txtModalFechaContratacion.ReadOnly = readOnly; ddlModalEspecialidad.Enabled = !readOnly; ddlModalEstado.Enabled = !readOnly; ddlModalEstadoLaboral.Enabled = !readOnly; btnGuardarVeterinario.Visible = !readOnly;
        }
    }
}