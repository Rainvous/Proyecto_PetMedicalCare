package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.personas.HorarioLaboralDto;

public interface HorarioLaboralDao extends DaoBase<HorarioLaboralDto> {

}