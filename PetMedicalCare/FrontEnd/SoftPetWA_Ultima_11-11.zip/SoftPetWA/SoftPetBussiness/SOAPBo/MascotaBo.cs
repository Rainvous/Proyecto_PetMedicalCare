﻿using SoftPetBussiness.SoftPetMascotasWS;
using System.Collections.Generic;
using System.Linq;


namespace SoftPetBusiness
{
    public class MascotaBO
    {
        private MascotasClient clienteSOAP;

        public MascotaBO()
        {
            this.clienteSOAP = new MascotasClient();
        }

        // Insertar mascota (parámetros sueltos)
        public int Insertar(int personaId, string nombre, string especie, string sexo,
                            string raza, string color, string fechaDefuncion, bool activo)
        {
            return this.clienteSOAP.insertar_mascota(
                personaId, nombre, especie, sexo, raza, color, fechaDefuncion, activo
            );
        }

        // Modificar mascota (parámetros sueltos)
        public int Modificar(int mascotaId, int personaId, string nombre, string especie, string sexo,
                             string raza, string color, string fechaDefuncion, bool activo)
        {
            return this.clienteSOAP.modificar_mascota(
                mascotaId, personaId, nombre, especie, sexo, raza, color, fechaDefuncion, activo
            );
        }

        // Eliminar mascota
        public int Eliminar(int mascotaId)
        {
            return this.clienteSOAP.eliminar_mascota(mascotaId);
        }

        // Obtener mascota por ID
        public mascotaDto ObtenerPorId(int mascotaId)
        {
            return this.clienteSOAP.obtenerPorId_mascota(mascotaId);
        }

        // Listar todas las mascotas
        public List<mascotaDto> ListarTodos()
        {
            return this.clienteSOAP.listar_mascotas().ToList<mascotaDto>();
        }

        // Insertar mascota usando DTO
        public int Insertar(mascotaDto mascota)
        {
            return this.clienteSOAP.insertar_mascota(
                mascota.persona.personaId,
                mascota.nombre,
                mascota.especie,
                mascota.sexo,
                mascota.raza,
                mascota.color,
                // Si en el proxy fechaDefuncion es DateTime?, usar mascota.fechaDefuncion?.ToString("yyyy-MM-dd")
                mascota.fechaDefuncion.ToString(),
                mascota.activo
            );
        }

        // Modificar mascota usando DTO
        public int Modificar(mascotaDto mascota)
        {
            return this.clienteSOAP.modificar_mascota(
                mascota.mascotaId,
                mascota.persona.personaId,
                mascota.nombre,
                mascota.especie,
                mascota.sexo,
                mascota.raza,
                mascota.color,
                mascota.fechaDefuncion.ToString(),
                mascota.activo
            );
        }
    }
}
