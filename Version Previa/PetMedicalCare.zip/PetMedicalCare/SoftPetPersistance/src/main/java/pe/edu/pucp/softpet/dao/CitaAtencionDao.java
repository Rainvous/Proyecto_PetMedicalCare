package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.citas.CitaAtencionDto;

public interface CitaAtencionDao extends DaoBase<CitaAtencionDto> {
    
}
