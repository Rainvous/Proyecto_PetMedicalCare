﻿using SoftPetBussiness.RecetaMedicaClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class RecetaMedicaBO
    {
        private RecetasMedicaClient clienteSOAP;

        public RecetaMedicaBO()
        {
            this.clienteSOAP = new RecetasMedicaClient();
        }

        public int Insertar(int citaId, string fechaEmision, string vigenciaHasta, string diagnostico, string observaciones, bool activo)
        {
            return this.clienteSOAP.insertar_receta(citaId, fechaEmision, vigenciaHasta, diagnostico, observaciones, activo);
        }

        public int Modificar(int recetaId, int citaId, string fechaEmision, string vigenciaHasta, string diagnostico, string observaciones, bool activo)
        {
            return this.clienteSOAP.modificar_receta(recetaId, citaId, fechaEmision, vigenciaHasta, diagnostico, observaciones, activo);
        }

        // --- AGREGADO: Necesario para el Modal "Ver Detalle" ---
        public recetaMedicaDto ObtenerPorId(int recetaId)
        {
            return this.clienteSOAP.obtener_por_id(recetaId);
        }
        // -------------------------------------------------------

        public recetaMedicaDto ObtenerPorIdCita(int citaId)
        {
            return this.clienteSOAP.obtener_receta_por_cita(citaId);
        }

        public List<recetaMedicaDto> ListarTodos()
        {
            return this.clienteSOAP.listar_todos().ToList<recetaMedicaDto>();
        }
    }
}