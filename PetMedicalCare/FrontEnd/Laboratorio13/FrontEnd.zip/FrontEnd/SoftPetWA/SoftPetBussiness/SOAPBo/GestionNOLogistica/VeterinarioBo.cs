﻿using SoftPetBussiness.ServicioClient;
using SoftPetBussiness.VeterinarioClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SoftPetBusiness
{
    public class VeterinarioBO
    {
        private VeterinariosClient clienteSOAP;

        public VeterinarioBO()
        {
            this.clienteSOAP = new VeterinariosClient();
        }

        // Insertar veterinario (Parámetros sueltos)
        public int Insertar(int personaId, string fechaContratacion, string estado, string especialidad, bool activo)
        {
            return this.clienteSOAP.insertar_veterinario(personaId, fechaContratacion, estado, especialidad, activo);
        }

        // Modificar veterinario (Parámetros sueltos)
        public int Modificar(int veterinarioId, int personaId, string fechaContratacion, string estado, string especialidad, bool activo)
        {
            return this.clienteSOAP.modificar_veterinario(veterinarioId, personaId, fechaContratacion, estado, especialidad, activo);
        }

        // Eliminar veterinario
        public int Eliminar(int veterinarioId)
        {
            return this.clienteSOAP.eliminar_veterinario(veterinarioId);
        }

        // Obtener veterinario por ID
        public veterinarioDto ObtenerPorId(int veterinarioId)
        {
            return this.clienteSOAP.obtenerPorId_veterinario(veterinarioId);
        }

        // Listar todos los veterinarios
        public List<veterinarioDto> ListarTodos()
        {
            return this.clienteSOAP.listar_veterinarios().ToList<veterinarioDto>();
        }

        public List<veterinarioDto> ListarActivos()
        {
            return this.clienteSOAP.listar_veterinarios_activos().ToList<veterinarioDto>();
        }

        // Insertar veterinario usando DTO (FIX: Formato de fecha)
        public int Insertar(veterinarioDto veterinario)
        {
            return this.clienteSOAP.insertar_veterinario(
                veterinario.persona.personaId,
                veterinario.fechaContratacion.ToString("yyyy-MM-dd"), // FIX AQUÍ
                veterinario.estado.ToString(),
                veterinario.especialidad,
                veterinario.activo
            );
        }

        // Modificar veterinario usando DTO (FIX: Formato de fecha)
        public int Modificar(veterinarioDto veterinario)
        {
            return this.clienteSOAP.modificar_veterinario(
                veterinario.veterinarioId,
                veterinario.persona.personaId,
                veterinario.fechaContratacion.ToString("yyyy-MM-dd"), // FIX AQUÍ
                veterinario.estado.ToString(),
                veterinario.especialidad,
                veterinario.activo
            );
        }

        // =================================================================
        // MÉTODO ACTUALIZADO: BÚSQUEDA AVANZADA (Backend)
        // =================================================================
        public List<veterinarioDto> ListarBusquedaAvanzada(string nombre, string documento, string especialidad, string telefono)
        {
            // 1. Limpieza de datos para evitar nulls
            nombre = nombre ?? "";
            documento = documento ?? "";
            telefono = telefono ?? "";
            // Si dice "Todos" en el combo, enviamos vacío para que el SQL ignore el filtro
            especialidad = (especialidad == "Todos") ? "" : (especialidad ?? "");

            // 2. Llamada al Web Service con el orden correcto de Java:
            //    @WebParam(name = "Especialidad")
            //    @WebParam(name = "nombre")
            //    @WebParam(name = "Telefono")
            //    @WebParam(name = "nroDocumento")
            var resultado = this.clienteSOAP.ListasBusquedaAvanzadaVeterinario(especialidad, nombre, telefono, documento);

            if (resultado == null) return new List<veterinarioDto>();

            return resultado.ToList<veterinarioDto>();
        }
    }
}