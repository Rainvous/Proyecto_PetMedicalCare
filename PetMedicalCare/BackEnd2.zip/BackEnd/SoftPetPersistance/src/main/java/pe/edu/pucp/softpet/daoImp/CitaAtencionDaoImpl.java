package pe.edu.pucp.softpet.daoImp;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import pe.edu.pucp.softpet.daoImp.util.Columna;
import pe.edu.pucp.softpet.dto.citas.CitaAtencionDto;
import pe.edu.pucp.softpet.dao.CitaAtencionDao;
import pe.edu.pucp.softpet.dto.util.enums.EstadoCita;

public class CitaAtencionDaoImpl extends DaoBaseImpl implements CitaAtencionDao {

    private CitaAtencionDto citaAtencion;

    public CitaAtencionDaoImpl() {
        super("CITAS_ATENCION");
        this.citaAtencion = null;
        this.retornarLlavePrimaria = true;
        this.usuario = "user_backend";
    }

    @Override
    protected void configurarListaDeColumnas() {
        this.listaColumnas.add(new Columna("CITA_ID", true, true));
        this.listaColumnas.add(new Columna("VETERINARIO_ID", false, false));
        this.listaColumnas.add(new Columna("MASCOTA_ID", false, false));
        this.listaColumnas.add(new Columna("FECHA_REGISTRO", false, false));
        this.listaColumnas.add(new Columna("FECHA_HORA_INICIO", false, false));
        this.listaColumnas.add(new Columna("FECHA_HORA_FIN", false, false));
        this.listaColumnas.add(new Columna("PESO_MASCOTA", false, false));
        this.listaColumnas.add(new Columna("MONTO", false, false));
        this.listaColumnas.add(new Columna("ESTADO_CITA", false, false));
        this.listaColumnas.add(new Columna("OBSERVACION", false, false));
        this.listaColumnas.add(new Columna("ACTIVO", false, false));
    }

    @Override
    protected void incluirValorDeParametrosParaInsercion() throws SQLException {

        this.statement.setInt(1, this.citaAtencion.getVeterinario().getVeterinarioId());
        this.statement.setInt(2, this.citaAtencion.getMascota().getMascotaId());
        this.statement.setDate(3, this.citaAtencion.getFechaRegistro());
        this.statement.setTimestamp(4, this.citaAtencion.getFechaHoraInicio());
        this.statement.setTimestamp(5, this.citaAtencion.getFechaHoraFin());
        this.statement.setDouble(6, this.citaAtencion.getPesoMascota());
        this.statement.setDouble(7, this.citaAtencion.getMonto());
        this.statement.setString(8, this.citaAtencion.getEstado().toString());
        this.statement.setString(9, this.citaAtencion.getObservacion());
        this.statement.setInt(10, this.citaAtencion.getActivo() ? 1 : 0);
    }

//    protected String retornaEstadoCita(String estado) {
//        if (this.citaAtencion.getEstado().equals(EstadoCita.ATENDIDA.toString())) {
//            estado = EstadoCita.ATENDIDA.toString();
//        } else if (this.citaAtencion.getEstado().equals(EstadoCita.CANCELADA.toString())) {
//            estado = EstadoCita.CANCELADA.toString();
//        } else {
//            estado = EstadoCita.PROGRAMADA.toString();
//        }
//        return estado;
//    }
    
    @Override
    protected void incluirValorDeParametrosParaModificacion() throws SQLException {
        this.statement.setInt(1, this.citaAtencion.getVeterinario().getVeterinarioId());
        this.statement.setInt(2, this.citaAtencion.getMascota().getMascotaId());
        this.statement.setDate(3, this.citaAtencion.getFechaRegistro());
       this.statement.setTimestamp(4, this.citaAtencion.getFechaHoraInicio());
        this.statement.setTimestamp(5, this.citaAtencion.getFechaHoraFin());
        this.statement.setDouble(6, this.citaAtencion.getPesoMascota());
        this.statement.setDouble(7, this.citaAtencion.getMonto());
        this.statement.setString(8, this.citaAtencion.getEstado().toString());
        this.statement.setString(9, this.citaAtencion.getObservacion());
        this.statement.setInt(10, this.citaAtencion.getActivo() ? 1 : 0);

        this.statement.setInt(11, this.citaAtencion.getCitaId());
    }

    @Override
    protected void incluirValorDeParametrosParaEliminacion() throws SQLException {
        this.statement.setInt(1, this.citaAtencion.getCitaId());
    }

    @Override
    protected void incluirValorDeParametrosParaObtenerPorId() throws SQLException {
        this.statement.setInt(1, this.citaAtencion.getCitaId());
    }

    @Override
    protected void instanciarObjetoDelResultSet() throws SQLException {
        this.citaAtencion = new CitaAtencionDto();
        this.citaAtencion.setCitaId(this.resultSet.getInt("CITA_ID"));
        this.citaAtencion.setVeterinario(new VeterinarioDaoImpl().
                obtenerPorId(this.resultSet.getInt("VETERINARIO_ID")));
        this.citaAtencion.setMascota(new MascotaDaoImpl().
                obtenerPorId(this.resultSet.getInt("MASCOTA_ID")));
        this.citaAtencion.setFechaRegistro(this.resultSet.getDate("FECHA_REGISTRO"));
        this.citaAtencion.setFechaHoraInicio(this.resultSet.getTimestamp("FECHA_HORA_INICIO"));
        this.citaAtencion.setFechaHoraFin(this.resultSet.getTimestamp("FECHA_HORA_FIN"));
        this.citaAtencion.setPesoMascota(this.resultSet.getDouble("PESO_MASCOTA"));
        this.citaAtencion.setMonto(this.resultSet.getDouble("MONTO"));
        this.citaAtencion.setEstado(EstadoCita.valueOf(this.resultSet.getString("ESTADO_CITA")));
        this.citaAtencion.setObservacion(this.resultSet.getString("OBSERVACION"));
        this.citaAtencion.setActivo(this.resultSet.getInt("ACTIVO") == 1);
    }

    @Override
    protected void limpiarObjetoDelResultSet() {
        this.citaAtencion = null;
    }

    @Override
    protected void agregarObjetoALaLista(List lista) throws SQLException {
        this.instanciarObjetoDelResultSet();
        lista.add(this.citaAtencion);
    }

    @Override
    public Integer insertar(CitaAtencionDto citaAtencion) {
        this.citaAtencion = citaAtencion;
        return super.insertar();
    }

    @Override
    public CitaAtencionDto obtenerPorId(Integer citaAtencionId) {
        this.citaAtencion = new CitaAtencionDto();
        this.citaAtencion.setCitaId(citaAtencionId);
        super.obtenerPorId();
        return this.citaAtencion;
    }

    @Override
    public ArrayList<CitaAtencionDto> listarTodos() {
        return (ArrayList<CitaAtencionDto>) super.listarTodos();
    }

    @Override
    public Integer modificar(CitaAtencionDto citaAtencion) {
        this.citaAtencion = citaAtencion;
        return super.modificar();
    }

    @Override
    public Integer eliminar(CitaAtencionDto citaAtencion) {
        this.citaAtencion = citaAtencion;
        return super.eliminar();
    }
    
    public ArrayList<CitaAtencionDto> ListasBusquedaAvanzada(String fecha){
        String fechaParaSP;

        // 1. Lógica de Java para decidir la fecha
        if (fecha == null || fecha.trim().isEmpty()) {

            // Si la fecha es "" o null, Java obtiene la fecha de hoy
            // (usando la zona horaria de tu máquina, que es la correcta)
            fechaParaSP = LocalDate.now().toString(); // Ej: "2025-11-10"

        } else {
            // Si la fecha SÍ viene, se usa esa.
            fechaParaSP = fecha;
        }

        // 2. Llama al SP
        Map<Integer, Object> parametrosEntrada = new HashMap<>();

        // Aquí siempre pasas una fecha válida ("2025-11-10")
        // ya sea la que escribió el usuario o la que calculó Java.
        parametrosEntrada.put(1, fechaParaSP);
        
        return (ArrayList<CitaAtencionDto>)super.ejecutarProcedimientoLectura("sp_listar_citas_por_fecha", parametrosEntrada);
    }
}
