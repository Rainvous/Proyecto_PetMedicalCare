package pe.edu.pucp.softpet.dao;

import pe.edu.pucp.softpet.dto.recetas.RecetaMedicaDto;

public interface RecetaMedicaDao extends DaoBase<RecetaMedicaDto> {

}
