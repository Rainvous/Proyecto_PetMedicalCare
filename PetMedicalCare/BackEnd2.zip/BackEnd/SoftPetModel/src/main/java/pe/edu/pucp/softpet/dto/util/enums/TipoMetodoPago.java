package pe.edu.pucp.softpet.dto.util.enums;

public enum TipoMetodoPago {
    EFECTIVO,
    TRANSFERENCIA,
    YAPE,
    PLIN
}
